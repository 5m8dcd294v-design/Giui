import telebot
from telebot import types
import requests
import json
import time
import logging
import os
import re
import unicodedata
import html
import threading
import random
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# ==========================================
# ⚙️ الإعدادات
# ==========================================
# ضع توكن BotFather بين علامتي الاقتباس هنا قبل التشغيل.
# لا يوجد توكن فعلي محفوظ في هذه النسخة لأن التوكن لم يُرسل داخل المحادثة.
BOT_TOKEN = "123456789:REPLACE_ME"
BOT_NAME = "حمو"   # اسم البوت — بيتغير من هنا بس
SOLVE_DELAY = float(os.environ.get("SOLVE_DELAY", "0.05"))
# المالك الأساسي ثابت داخل الكود كما طلبت.
OWNER_IDS = (8764500890,)
OWNER_ID = 8764500890


def is_owner(uid):
    try:
        return int(uid) in OWNER_IDS
    except Exception:
        return False


def _scrub_owners(d):
    """بيشيل أي أثر للمالكين من قاعدة البيانات (عشان محدش فيهم يظهر للتاني)."""
    try:
        d["users"] = [u for u in d.get("users", []) if not is_owner(u)]
        for key in ("info", "credits", "banned", "blocked", "trial_used", "vip_until", "refs", "referred"):
            if isinstance(d.get(key), dict):
                for k in [k for k in d[key] if is_owner(k)]:
                    d[key].pop(k, None)
        if isinstance(d.get("referred"), dict):
            for k in [k for k, v in d["referred"].items() if is_owner(v)]:
                d["referred"].pop(k, None)
        st = d.get("settings")
        if isinstance(st, dict) and isinstance(st.get("admins"), list):
            st["admins"] = [a for a in st["admins"] if not is_owner(a)]
        if isinstance(d.get("log"), list):
            d["log"] = [e for e in d["log"] if not (isinstance(e, dict) and e.get("u") is not None and is_owner(e.get("u")))]
        if isinstance(d.get("codes"), dict):
            for c in d["codes"].values():
                if isinstance(c, dict) and c.get("used_by") is not None and is_owner(c.get("used_by")):
                    c["used_by"] = "—"
    except Exception:
        pass
    return d


def _owners_send(text, **kw):
    for _o in OWNER_IDS:
        try:
            bot.send_message(_o, text, **kw)
        except Exception:
            pass


_ALERTED = {}


def _alert_owners_once(key, text, gap=3600):
    """تنبيه للمالكين بس مرة كل ساعة لنفس المشكلة (عشان ما نزعجهمش)."""
    now = time.time()
    if now - _ALERTED.get(key, 0) < gap:
        return
    _ALERTED[key] = now
    _owners_send(text, parse_mode="HTML")


def _conn_fail_text(err):
    return ("❌ <b>تعذّر الاتصال بموقع المنصة حاليًا.</b>\n"
            "ده غالبًا عطل مؤقت في الشبكة أو الموقع — جرّب تاني بعد دقايق.\n"
            f"<code>{html.escape(type(err).__name__)}</code>")
OWNER_USERNAME = "@zzszzb"
OWNER_USERNAME_TG = "zzszzb" # يوزر حسابك للتوجيه للشراء

CHANNEL_USERNAME = "@saifAbdo66"
# تم إلغاء GIF نهائياً لتجنب failed to get HTTP URL content.
WELCOME_GIF = ""

BASE = "https://egy.app.spx-learning-square.com"
SUBJECT = 7
QUREO_BASE = "https://me-tp.qureo.education"
QUREO_PORTAL = "https://me-portal.qureo.education"

from logging.handlers import RotatingFileHandler
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
try:
    _fh = RotatingFileHandler("bot.log", maxBytes=1_000_000, backupCount=2, encoding="utf-8")
    _fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logging.getLogger().addHandler(_fh)
except Exception:
    pass

# ==========================================
# 🌐 اتصال مباشر بدون بروكسي (تيليجرام + Qureo + SPX)
# ==========================================
# أي بروكسي مفروض من متغيرات البيئة بيتتجاهل. لو استضافتك مجبراك على بروكسي
# حط رابطه في متغير البيئة BOT_PROXY (مثال: http://host:port) وهيتستخدم لكل الاتصالات.
BOT_PROXY = (os.environ.get("BOT_PROXY") or "").strip()
for _v in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy"):
    os.environ.pop(_v, None)
os.environ["NO_PROXY"] = "*"
os.environ["no_proxy"] = "*"
from telebot import apihelper
apihelper.proxy = {"http": BOT_PROXY, "https": BOT_PROXY} if BOT_PROXY else None

from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


SITE_PROXY = (os.environ.get("SITE_PROXY") or "").strip()            # بروكسي للمواقع بس (من الاستضافة)
PROXY_POOL_FILE = (os.environ.get("PROXY_POOL_FILE") or "").strip()  # قايمة بروكسيات شغّالة بتحدّثها الاستضافة
_POOL_CACHE = {"mtime": 0, "urls": []}
_LAST_GOOD = {"set": False, "px": None}


def make_session(proxy=None):
    """Session: بيتجاهل بروكسيات النظام، وبيعيد المحاولة تلقائي لو الاتصال فصل. proxy اختياري (للمواقع بس)."""
    s = requests.Session()
    s.trust_env = False
    px = proxy or BOT_PROXY
    s.proxies = {"http": px, "https": px} if px else {}
    n = 1 if proxy else 3                                 # مع بروكسي: بدّل بسرعة بدل ما تستنى
    kw = dict(total=n, connect=n, read=1, status=2, backoff_factor=0.7,
              status_forcelist=(429, 502, 503, 504), raise_on_status=False)
    try:
        retry = Retry(allowed_methods=frozenset(["GET", "HEAD", "OPTIONS"]), **kw)
    except TypeError:                                   # urllib3 قديمة
        retry = Retry(method_whitelist=frozenset(["GET", "HEAD", "OPTIONS"]), **kw)
    ad = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=20)
    s.mount("https://", ad)
    s.mount("http://", ad)
    return s


def _pool_urls():
    """بروكسيات المنصة (الاستضافة بتحدّث الملف لوحدها)، الأسرع أولاً."""
    try:
        if PROXY_POOL_FILE and os.path.exists(PROXY_POOL_FILE):
            mt = os.path.getmtime(PROXY_POOL_FILE)
            if mt != _POOL_CACHE["mtime"]:
                with open(PROXY_POOL_FILE, encoding="utf-8") as f:
                    d = json.load(f)
                _POOL_CACHE["urls"] = [p["url"] for p in d.get("proxies", []) if p.get("url")]
                _POOL_CACHE["mtime"] = mt
    except Exception:
        pass
    return list(_POOL_CACHE["urls"])


def site_proxy_candidates(max_proxies=4):
    """ترتيب محاولات الاتصال بالمواقع (Qureo/SPX). تيليجرام مش بيتأثر. None = اتصال مباشر."""
    if BOT_PROXY:                       # المطور فارض بروكسي → بدون رجوع للمباشر
        return [BOT_PROXY]
    px = []
    if SITE_PROXY:
        px.append(SITE_PROXY)
    top = _pool_urls()[:6]
    random.shuffle(top)
    px += [u for u in top if u not in px]
    px = px[:max_proxies]
    if not px:
        return [None]
    order = px + [None]
    if _LAST_GOOD["set"] and _LAST_GOOD["px"] in order:      # اللي نجح آخر مرة الأول
        order.remove(_LAST_GOOD["px"])
        order.insert(0, _LAST_GOOD["px"])
    return order


def _remember_site_proxy(px):
    _LAST_GOOD["set"] = True
    _LAST_GOOD["px"] = px


_RETRY_STATUS = (403, 407, 429, 500, 502, 503, 504)


bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML")
USERS = {}

# ==========================================
# 💾 حفظ وتحميل المستخدمين والإحصائيات والفرص والحظر
# ==========================================
# يخلّي كل الملفات (max.json وغيره) تتقرا من فولدر البوت مهما كان مكان التشغيل في الاستضافة
try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    os.chdir(BASE_DIR)
except Exception:
    BASE_DIR = os.getcwd()
for _f in ("max.json", "javascript_final_db.json", "study_data.json", "answers_by_level.json"):
    if not os.path.exists(os.path.join(BASE_DIR, _f)):
        print(f"⚠️ ملف ناقص جنب البوت: {_f}  (ارفع فولدر bot كله مش bot.py لوحده)  — المسار: {BASE_DIR}")

USERS_FILE = "users_db.json"

def load_db():
    try:
        if os.path.exists(USERS_FILE):
            with open(USERS_FILE, "r", encoding="utf-8") as f: 
                data = json.load(f)
                if "users" not in data: data["users"] = []
                if "success" not in data: data["success"] = 0
                if "failed" not in data: data["failed"] = 0
                if "credits" not in data: data["credits"] = {}
                if "banned" not in data: data["banned"] = {}
                return data
    except: pass
    return {"users": [], "success": 0, "failed": 0, "credits": {}, "banned": {}}

DB_LOCK = threading.RLock()

def save_db(data):
    try:
        with DB_LOCK:
            _scrub_owners(data)
            tmp = USERS_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, USERS_FILE)
    except: pass

DB = _scrub_owners(load_db())
DB.setdefault("settings", {})
DB["settings"].setdefault("channel", CHANNEL_USERNAME)
if DB["settings"].get("channel_code") != CHANNEL_USERNAME:      # اتغيرت القناة في الكود ← اتطبقها
    DB["settings"]["channel"] = CHANNEL_USERNAME
    DB["settings"]["channel_code"] = CHANNEL_USERNAME
    save_db(DB)
DB["settings"]["force_sub"] = False                 # الاشتراك الإجباري ملغي نهائياً
DB["settings"].setdefault("maintenance", False)     # وضع الصيانة
DB["settings"].setdefault("admins", [])             # أدمنز إضافيين
DB["settings"]["free_trial"] = False                # لا توجد تجربة مجانية
DB["settings"]["free_attempts"] = 0
DB["settings"]["free_chapters"] = 0
DB["settings"].setdefault("native_colors", True)    # الأزرار الملونة الأصلية (style)
DB["settings"].setdefault("buy_text", "")           # فاضية = الرسالة الافتراضية
DB["settings"].setdefault("referral", False)        # نظام الإحالات
DB["settings"].setdefault("referral_reward", 1)     # فرص لكل دعوة
DB["settings"].setdefault("max_running", 25)        # أقصى عمليات حل متزامنة
DB["settings"].setdefault("notify_new", False)      # إشعار المالك بالمستخدم الجديد
DB["settings"].setdefault("auto_backup", True)      # نسخة يومية للمالك
DB["settings"].setdefault("last_backup", 0)
DB.setdefault("info", {})        # اسم/يوزر/انضمام/آخر ظهور
DB.setdefault("blocked", {})     # اللي سابوا البوت
DB.setdefault("trial_used", {})  # كام محاولة مجانية استخدمها كل مستخدم
DB.setdefault("vip_until", {})   # تاريخ انتهاء اشتراك VIP المؤقت
DB.setdefault("codes", {})       # أكواد التفعيل
DB.setdefault("log", [])         # سجل الأحداث
DB.setdefault("refs", {})        # عدد الإحالات لكل مستخدم
DB.setdefault("referred", {})    # مين اتدعى من مين

def is_admin(uid):
    try:
        return is_owner(uid) or int(uid) in [int(x) for x in DB["settings"].get("admins", [])]
    except Exception:
        return False


# ==========================================
# 💎 نظام الاشتراكات والمحاولة المجانية (يتحكم فيه الأدمن من /admin)
# ==========================================
DEFAULT_BUY_TEXT = (
    "⚠️ <b>عذراً يا صديقي!</b>\n\n"
    "لقد استنفدت المحاولة المجانية المتاحة لك.\n"
    "<i>(المحاولة المجانية: حل {chapters} فصول فقط من منصة واحدة)</i>\n\n"
    "💳 <b>متاح شراء الأداة وتفعيل المحاولات فوراً:</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "🐍 بايثون (Qureo): <b>50 ج</b>\n"
    "💰 الثقافة المالية (SPX): <b>50 ج</b>\n"
    "☕ جافا سكريبت (Qureo): <b>50 ج</b>\n\n"
    "🔥 <b>عرض خاص:</b> جافا + الثقافة + بايثون معاً بـ <b>100 ج فقط!</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "👇 اضغط على زر <b>OWNER</b> أدناه للتواصل مع المالك وتفعيل حسابك:"
)

def user_plan(cid):
    """
    بيرجّع (النوع, تفاصيل):
      admin  → أدمن (بدون حدود)
      vip    → اشتراك VIP (التفاصيل = وقت الانتهاء أو None لو دائم)
      paid   → عنده فرص مدفوعة (التفاصيل = العدد)
      none   → مفيش رصيد
    """
    if is_admin(cid):
        return ("admin", None)
    k = str(cid)
    cr = DB["credits"].get(k)
    if cr == "max":
        until = DB["vip_until"].get(k)
        if until and until < time.time():            # اشتراك منتهي
            DB["credits"][k] = 0
            DB["vip_until"].pop(k, None)
            save_db(DB)
            cr = 0
        else:
            return ("vip", until)
    if isinstance(cr, int) and cr > 0:
        return ("paid", cr)
    return ("none", None)


def consume_attempt(cid, plan):
    with DB_LOCK:
        kind = plan[0]
        k = str(cid)
        if kind == "paid":
            cur = DB["credits"].get(k)
            if isinstance(cur, int) and cur > 0:
                DB["credits"][k] = cur - 1
        save_db(DB)
        log_event("solve", cid, kind)


def trial_footer(plan):
    return ""


def plan_text(cid):
    kind, d = user_plan(cid)
    if kind == "admin":
        return "👑 أدمن — بدون حدود"
    if kind == "vip":
        left = ""
        if d:
            days = max(0, int((d - time.time()) // 86400))
            left = f" (باقي {days} يوم)"
        return "💎 اشتراك VIP" + (left if d else " دائم")
    if kind == "paid":
        return f"🎟 رصيدك: {d} فرصة"
    return "🔒 مفيش رصيد — تواصل مع المالك للتفعيل"


def show_buy(cid, message_id=None):
    n = DB["settings"].get("free_chapters", 3)
    text = (DB["settings"].get("buy_text") or DEFAULT_BUY_TEXT).replace("{chapters}", str(n))
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(_b("👨‍💻 OWNER (شراء الأداة)", url=f"https://t.me/{OWNER_USERNAME_TG}", style="success"))
    markup.add(_b("📊 إحصائياتي", "my_stats", style="primary"))
    if message_id:
        try:
            bot.edit_message_caption(caption=text, chat_id=cid, message_id=message_id,
                                     reply_markup=markup, parse_mode="HTML")
            return
        except Exception:
            pass
    try:
        bot.send_message(cid, text, reply_markup=markup, parse_mode="HTML")
    except Exception:
        pass


def _gate_say(cid, call, text):
    try:
        if call:
            bot.answer_callback_query(call.id, text, show_alert=True)
        else:
            bot.send_message(cid, text)
    except Exception:
        pass


def user_gate(cid, call=None):
    """
    البوابة اللي كل زر ورسالة بتعدّي عليها: حظر ← صيانة ← اشتراك القناة.
    الأدمن بيعدّي دايمًا. True = مسموح.
    """
    if is_admin(cid):
        return True
    if DB["banned"].get(str(cid)):
        _gate_say(cid, call, "🚫 أنت محظور من استخدام البوت.")
        return False
    if DB["settings"].get("maintenance"):
        _gate_say(cid, call, "🛠 البوت تحت الصيانة حاليًا، جرب بعد شوية.")
        return False
    return True


# ==========================================
# 🛡️ التحقق من الاشتراك
# ==========================================
def check_subscription(user_id):
    # فحص القناة ملغي نهائياً.
    return True

def send_subscribe_msg(cid):
    channel = DB.get("settings", {}).get("channel", CHANNEL_USERNAME)
    channel_url = "https://t.me/" + channel.lstrip("@")
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(_b("📢 اشترك في القناة", url=channel_url, style="primary"))
    markup.add(_b("تحقق من الاشتراك", "check_sub", style="success"))
    try:
        bot.send_message(cid, "⚠️ <b>عذراً عزيزي،</b>\n\nللاستفادة من البوت، يجب عليك الاشتراك في قناتنا أولاً.\n\n👇 اضغط على اشترك ثم تحقق:", reply_markup=markup, parse_mode="HTML")
    except Exception as e:
        print(f"Error sending subscribe msg: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "check_sub")
def callback_check_sub(call):
    cid = call.message.chat.id
    if check_subscription(cid):
        bot.answer_callback_query(call.id, "✅ تم التحقق بنجاح!")
        bot.delete_message(cid, call.message.message_id)
        cmd_start(call.message)
    else:
        bot.answer_callback_query(call.id, "❌ أنت لم تشترك في القناة بعد!", show_alert=True)

# ==========================================
# 🧹 دوال المطابقة (SPX)
# ==========================================
def canon(t):
    if not t: return ""
    t = html.unescape(str(t))
    t = re.sub(r'\[\[.*?\]\]', '', t)
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', t)).strip()

def norm(t):
    return canon(t).replace(' ', '').replace('"', '').replace("'", '').replace('`', '').lower()

def find_spx_answer(question_text):
    q_clean = canon(question_text)
    if 'levels' in STUDY_DATA:
        for lvl in STUDY_DATA['levels'].values():
            for q in lvl.get('questions', []):
                if canon(q.get('question', '')) == q_clean: return q.get('answer', '')
    for level, qs in ANSWERS_LEVEL.items():
        if isinstance(qs, list):
            for item in qs:
                if isinstance(item, dict) and item.get('answer'):
                    if len(q_clean) > 20 and canon(item['answer'])[:30] in q_clean: return item['answer']
    return None

def match_option(options, answer_text, is_spx=True):
    if not answer_text: return None
    if isinstance(answer_text, int) or (isinstance(answer_text, str) and answer_text.isdigit()):
        answer_id = int(answer_text)
        if any(opt.get('id') == answer_id for opt in options):
            return answer_id
    ans_clean = norm(answer_text)
    for opt in options:
        txt = opt.get('text', '') if is_spx else opt.get('content', '')
        if norm(txt) == ans_clean: return opt['id']
    for opt in options:
        txt = opt.get('text', '') if is_spx else opt.get('content', '')
        opt_clean = norm(txt)
        if ans_clean in opt_clean or opt_clean in ans_clean:
            return opt['id']
    return None

# ==========================================
# 📂 تحميل الملفات
# ==========================================
def load_json(path):
    try:
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f: return json.load(f)
    except Exception: pass
    return {}

STUDY_DATA = load_json("study_data.json")
ANSWERS_LEVEL = load_json("answers_by_level.json")

# ==========================================
# 🤖 محرك SPX (الثقافة المالية)
# ==========================================
class SPXSolver:
    def __init__(self, login_id, password):
        self.login_id = login_id
        self.password = password
        self.last_error = None
        self.last_status = None
        self.token = None
        self._new_session(None)

    def _new_session(self, proxy):
        self.s = make_session(proxy)
        self.s.headers.update({
            "accept": "application/json, text/plain, */*",
            "content-type": "application/json",
            "origin": BASE,
            "referer": f"{BASE}/subjects/{SUBJECT}/curriculum",
            "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 Chrome/139.0.0.0 Mobile Safari/537.36",
        })
        self.token = None

    def _req(self, method, path, **kw):
        url = path if path.startswith("http") else f"{BASE}{path}"
        try: return self.s.request(method, url, timeout=15, **kw)
        except Exception as e:
            self.last_error = e
            return None

    def _get(self, path):
        r = self._req("GET", path)
        if r and r.status_code == 200:
            try: return r.json()
            except: return None
        return None

    def _post(self, path, payload=None): return self._req("POST", path, json=payload or {})
    def _put(self, path, payload=None): return self._req("PUT", path, json=payload or {})

    def login(self):
        """بيجرّب البروكسيات المتاحة (لو في) وبعدها المباشر، وبيقف أول ما الدخول ينجح أو الرد يبقى رفض بيانات."""
        for px in site_proxy_candidates():
            self._new_session(px)
            self.last_error = None
            self.last_status = None
            if self._login_once():
                _remember_site_proxy(px)
                return True
            if self.last_error is None and self.last_status not in _RETRY_STATUS:
                return False                       # الموقع رد وبيانات الدخول مرفوضة — مفيش فايدة من بروكسي تاني
        return False

    def _login_once(self):
        r = self._post("/api/v1/auth/login", {"login_id": self.login_id, "password": self.password})
        self.last_status = r.status_code if r is not None else None
        if not r or r.status_code != 200: return False
        try: body = r.json()
        except: return False
        self.token = body.get("token") or (body.get("data") or {}).get("token")
        if not self.token:
            for c in self.s.cookies:
                if c.name == "learning_token":
                    self.token = c.value
                    break
        if not self.token: return False
        self.s.headers["authorization"] = f"Bearer {self.token}"
        return True

    def find_next(self):
        cur = self._get(f"/api/v1/subjects/{SUBJECT}/curriculum")
        if not cur or 'data' not in cur: return None, 0, 0
        total, completed, next_item = 0, 0, None
        for unit in cur['data']:
            for item in unit.get('items', []):
                total += 1
                if item.get('is_completed'): completed += 1
                elif not next_item: next_item = item
        return ("DONE", completed, total) if not next_item else (next_item, completed, total)

    def solve_chapter(self, chapter_id):
        d = self._get(f"/api/v1/chapters/{chapter_id}/blocks")
        if not d or 'data' not in d: return {"ok": False, "total": 0, "solved": 0}
        blocks = d['data'].get('blocks', [])
        cleared = set(d['data'].get('chapter', {}).get('cleared_block_ids', []))
        questions = [b for b in blocks if b.get('type') == 'question']
        
        solved = 0
        for q in questions:
            if q['id'] in cleared:
                solved += 1; continue
            for opt in q.get('options', []):
                r = self._post(f"/api/v1/chapters/{chapter_id}/answer", {"block_id": q['id'], "selected_option_id": opt['id'], "hint_used": 0})
                if r and r.status_code == 200:
                    try:
                        ans = r.json().get('data', {})
                        if ans.get('is_correct'): solved += 1; break
                        if ans.get('correct_option_id'):
                            self._post(f"/api/v1/chapters/{chapter_id}/answer", {"block_id": q['id'], "selected_option_id": ans['correct_option_id'], "hint_used": 0})
                            solved += 1; break
                    except: pass
        self._post(f"/api/v1/chapters/{chapter_id}/complete")
        return {"ok": True, "solved": solved, "total": len(questions)}

    def solve_review(self, review_id):
        r = self._post(f"/api/v1/reviews/{review_id}/complete")
        return {"ok": r and r.status_code == 200, "solved": 1, "total": 1}

    def solve_test(self, test_id):
        r = self._post(f"/api/v1/tests/{test_id}/start")
        if not r or r.status_code != 200: return {"ok": False, "solved": 0, "total": 0}
        try:
            data = r.json()['data']
            questions_map = data.get('questions', {})
            options_map = data.get('options', {})
            test_questions = data.get('test_questions', [])
        except: return {"ok": False, "solved": 0, "total": 0}
        
        solved = 0
        answers_batch = []
        for tq in test_questions:
            t_id = tq['id']
            q_id = str(tq['question_id'])
            q_text = questions_map.get(q_id, {}).get('question_text', '')
            options = options_map.get(q_id, [])
            if not q_text or not options: continue
            
            ans_text = find_spx_answer(q_text)
            chosen_id = match_option(options, ans_text, True) if ans_text else options[0]['id']
            answers_batch.append((t_id, chosen_id))
            if chosen_id: solved += 1
        
        for t_id, chosen_id in answers_batch:
            self._put(f"/api/v1/tests/{test_id}/questions/{t_id}/answer", {"selected_option_id": chosen_id})
        
        time.sleep(0.5)
        self._post(f"/api/v1/tests/{test_id}/submit")
        time.sleep(1)
        h = self._get(f"/api/v1/tests/{test_id}/history")
        passed, score = False, 0
        if h and 'data' in h:
            for e in h['data']:
                if e.get('status') == 'completed':
                    passed, score = e.get('passed'), e.get('correct_count', 0); break
        return {"ok": passed, "solved": score, "total": len(test_questions)}

# ==========================================
# 🐍 محرك Qureo (بايثون + JavaScript)
# ==========================================
def run_qureo_tool(cid_tg, message_id, STUDENT_ID, PASSWORD, content_id, json_file, platform_name, chapter_limit=None):
    _plan = user_plan(cid_tg)
    _limit = None
    def load_json_tool(p):
        if not os.path.exists(p): return {}
        try:
            with open(p, encoding="utf-8") as f: return json.load(f)
        except: return {}

    max_data = load_json_tool(json_file)
    if not max_data:
        try: bot.edit_message_text(f"❌ ملف {json_file} مش موجود!", cid_tg, message_id)
        except: pass
        return

    try: bot.edit_message_text(f"⏳ جاري تسجيل الدخول لـ {platform_name}...", cid_tg, message_id)
    except: pass

    def _mk_session(px):
        _s = make_session(px)
        _orig_req = _s.request
        def _req_with_timeout(method, url, **kw):
            kw.setdefault("timeout", 60)
            return _orig_req(method, url, **kw)
        _s.request = _req_with_timeout
        _s.headers.update({
            "authority": "me-tp.qureo.education",
            "content-type": "application/json",
            "origin": QUREO_BASE,
            "referer": f"{QUREO_BASE}/",
            "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/139.0.0.0 Safari/537.36"
        })
        _lh = _s.headers.copy()
        _lh["origin"] = QUREO_PORTAL
        _lh["referer"] = f"{QUREO_PORTAL}/"
        return _s, _lh

    r, _ce, token = None, None, None
    s, lh = None, None
    for _px in site_proxy_candidates():      # بروكسيات الاستضافة أولاً (لو متفعّلة) وبعدها المباشر
        s, lh = _mk_session(_px)
        try:
            r = s.post(f"{QUREO_PORTAL}/oauth2/password-login", json={"student_id": STUDENT_ID, "password": PASSWORD}, headers=lh)
            _ce = None
        except requests.exceptions.RequestException as e:
            _ce = e
            continue
        token = s.cookies.get("egy_student_access_token")
        if token:
            _remember_site_proxy(_px)
            break
        if r.status_code not in _RETRY_STATUS:
            break                             # بيانات الدخول مرفوضة — مفيش فايدة من بروكسي تاني
    if r is None and _ce is not None:
        try: bot.edit_message_text(_conn_fail_text(_ce), cid_tg, message_id, parse_mode="HTML")
        except: pass
        log_event("error", cid_tg, f"conn {type(_ce).__name__}")
        _alert_owners_once("conn_qureo", f"⚠️ <b>البوت مش قادر يتصل بـ Qureo</b>\n<code>{html.escape(str(_ce)[:250])}</code>\n"
                                          "الاستضافة بتحجب الموقع؟ فعّل 🌐 بروكسي البوتات من لوحة الاستضافة أو حط BOT_PROXY.")
        return
    
    if not token: 
        try: bot.edit_message_text(_login_fail_text(r.status_code), cid_tg, message_id, parse_mode="HTML")
        except: pass
        _login_fail_report(cid_tg, platform_name, r)
        DB["failed"] += 1
        save_db(DB)
        return
    
    s.headers["authorization"] = f"Bearer {token}"
    s.cookies.set("student_selected_content_id", content_id, domain="me-tp.qureo.education")

    def fix_indentation(code):
        if not code or not isinstance(code, str): return code
        lines = code.split('\n')
        fixed_lines = []
        for line in lines:
            stripped = line.strip()
            if not stripped:
                fixed_lines.append("")
            elif stripped.startswith("//") or stripped.startswith("console.log") or stripped.startswith("let ") or stripped.startswith("if ") or stripped.startswith("for ") or stripped.startswith("function ") or stripped.startswith("while "):
                if not line.startswith("  "):
                    fixed_lines.append("  " + stripped)
                else:
                    fixed_lines.append(line)
            else:
                fixed_lines.append(line)
        return '\n'.join(fixed_lines)

    def check_status(cid):
        s.cookies.set("_cf_s_path", f"/contents/chapter/{cid}", domain="me-tp.qureo.education")
        try:
            res = s.get(f"{QUREO_BASE}/api/study/students/chapters/{cid}")
            if res.status_code == 200:
                data = res.json()
                return data.get('best_correct_count', 0), data.get('completed_at') is not None
        except: pass
        return 0, False

    def solve_lectures(cid):
        s.cookies.set("_cf_s_path", f"/contents/chapter/{cid}", domain="me-tp.qureo.education")
        try:
            r = s.get(f"{QUREO_BASE}/api/study/chapters/{cid}")
            if r.status_code == 200:
                lectures = r.json().get('lectures', [])
                for lec in lectures:
                    s.put(f"{QUREO_BASE}/api/study/students/lectures/{lec['id']}", json={})
                    s.put(f"{QUREO_BASE}/api/study/students/lectures/{lec['id']}/complete", json={})
        except: pass

    def solve_chapter(cid):
        s.cookies.set("_cf_s_path", f"/contents/chapter/{cid}", domain="me-tp.qureo.education")
        
        best, is_completed = check_status(cid)
        if is_completed and best > 0: return True, best, best
        
        try: r = s.get(f"{QUREO_BASE}/api/study/chapters/{cid}/test")
        except: return False, 0, 0
        
        if r.status_code == 403: return False, 0, -1
        if r.status_code != 200: return False, 0, 0
        
        try: qs_data = r.json()
        except: return False, 0, 0
        
        s.put(f"{QUREO_BASE}/api/study/students/chapters/{cid}/test", json={})
        s.put(f"{QUREO_BASE}/api/study/students/chapters/{cid}/test", json={})
        
        solved = 0
        chapter_answers = max_data.get('chapters', {}).get(str(cid), {}).get('answers', {})
        if not chapter_answers:
            chapter_answers = max_data.get('chapters', {}).get(str(cid), {}).get('questions', {})
        
        for i, q in enumerate(qs_data):
            q_info = q['question']
            q_id = str(q_info['id'])
            q_type = q_info['type']
            
            item = chapter_answers.get(q_id, {})
            if isinstance(item, dict): ans = item.get('answer')
            elif isinstance(item, (tuple, list)): ans = item[1]
            else: ans = item
            
            if ans is None:
                if q_type == 'choice' and q.get('choices'):
                    ans = q['choices'][0]['id']
                else:
                    continue
            
            if q_type == 'description' and isinstance(ans, str):
                if content_id == "javascript_ar":
                    ans = fix_indentation(ans)
                
            if q_type == 'description':
                url = f"{QUREO_BASE}/api/study/students/test-questions/{q_id}/answer/description"
                payload = {"answer_code": str(ans)}
            else:
                url = f"{QUREO_BASE}/api/study/students/test-questions/{q_id}/answer/choice"
                payload = {"choice_id": int(ans)}
            
            res = s.put(url, json=payload)
            
            if res.status_code != 200 and q_type == 'choice' and q.get('choices'):
                for ch in q['choices']:
                    res2 = s.put(url, json={"choice_id": int(ch['id'])})
                    if res2.status_code == 200:
                        res = res2
                        break
            
            if res.status_code in (200, 400):
                solved += 1
            else:
                if q_type == 'description': url_rev = f"{QUREO_BASE}/api/study/students/review-questions/{q_id}/answer/description"
                else: url_rev = f"{QUREO_BASE}/api/study/students/review-questions/{q_id}/answer/choice"
                if s.put(url_rev, json=payload).status_code == 200: solved += 1
                
            time.sleep(SOLVE_DELAY)
        
        time.sleep(0.5)
        best, is_completed = check_status(cid)
        if is_completed and best >= len(qs_data): return True, best, len(qs_data)
        return solved == len(qs_data), solved, len(qs_data)

    total_chapters = 54 if content_id == "javascript_ar" else 25
    if chapter_limit is not None:
        total_chapters = min(total_chapters, int(chapter_limit))
    if _limit:
        total_chapters = min(total_chapters, int(_limit))
    start_cid = 90001 if content_id == "javascript_ar" else 511001
    
    activities = ["🚀 بدء..."]
    last_update_time = 0
    fail_count = 0
    
    for chap_idx in range(total_chapters):
        if not USERS.get(cid_tg, {}).get('running'): break
        cid = start_cid + chap_idx
        
        if time.time() - last_update_time > 2:
            percent = int(((chap_idx + 1) / total_chapters) * 100)
            progress_bar = "█" * (percent // 10) + "░" * (10 - (percent // 10))
            status_text = (
                f"⏳ <b>جاري الحل ({platform_name})...</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"👤 كود: <code>{STUDENT_ID}</code>\n"
                f"📊 التقدم: <code>[{progress_bar}] {percent}%</code>\n"
                f"🎯 العنصر: <code>فصل {chap_idx + 1} من {total_chapters}</code>\n"
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"📝 <b>آخر النشاطات:</b>\n"
            )
            for act in activities[-4:]: status_text += f"• {act}\n"
            try: bot.edit_message_text(status_text, cid_tg, message_id)
            except: pass
            last_update_time = time.time()
        
        solve_lectures(cid)
        ok, solved, total = solve_chapter(cid)
        
        if total == -1: 
            activities.append(f"🔒 فصل {chap_idx + 1} (مقفول)")
            fail_count += 1
        elif total == 0: 
            activities.append(f"⚠️ فصل {chap_idx + 1} (خطأ)")
            fail_count += 1
        elif ok: activities.append(f"✅ فصل {chap_idx + 1} (PERFECT)")
        else: 
            activities.append(f"❌ فصل {chap_idx + 1} ({solved}/{total})")
            fail_count += 1

    if fail_count == total_chapters:
        DB["failed"] += 1
    else:
        DB["success"] += 1
    
    # خصم المحاولة (باستثناء الـ VIP والأدمن)
    consume_attempt(cid_tg, _plan)

    save_db(DB)

    final_text = (
        f"🎉 <b>تم إنهاء {platform_name}!</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 كود: <code>{STUDENT_ID}</code>\n"
        f"📸 <b>أرسل صورة النتيجة لـ</b> {OWNER_USERNAME}\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"📝 <b>ملخص النشاط:</b>\n"
    )
    for act in activities[-10:]: final_text += f"• {act}\n"
    final_text += trial_footer(_plan)
    try: bot.edit_message_text(final_text, cid_tg, message_id)
    except: pass

# ==========================================
# 🧠 محرك SPX (الثالثة) - اللفة الرئيسية
# ==========================================
def run_spx_tool(cid_tg, message_id, login_id, password):
    _plan = user_plan(cid_tg)
    _limit = None
    _done_items = 0
    solver = SPXSolver(login_id, password)
    if not solver.login():
        _le = getattr(solver, "last_error", None)
        try:
            if isinstance(_le, requests.exceptions.RequestException):
                bot.edit_message_text(_conn_fail_text(_le), cid_tg, message_id, parse_mode="HTML")
                _alert_owners_once("conn_spx", f"⚠️ <b>البوت مش قادر يتصل بـ SPX</b>\n<code>{html.escape(str(_le)[:250])}</code>", 1800)
            else:
                bot.edit_message_text("❌ فشل الدخول للثقافة المالية!", cid_tg, message_id)
        except: pass
        DB["failed"] += 1
        save_db(DB)
        return

    activities = ["🚀 بدء..."]
    last_update_time = 0
    fail_count = 0

    while USERS.get(cid_tg, {}).get('running'):
        item, completed, total = solver.find_next()
        if item == "DONE" or not item: break
        
        item_title = item.get('title', '')
        itype = item.get('item_type')
        item_id = item.get('id')
        
        if itype == "chapter":
            res = solver.solve_chapter(item_id)
        elif itype == "review":
            solver.solve_review(item_id)
            res = {"solved": 1, "total": 1}
        elif itype == "test":
            res = solver.solve_test(item_id)
        else:
            res = {}
        
        activities.append(f"✅ {item_title[:20]}")
        if not res.get('ok', True): fail_count += 1
        _done_items += 1
        if _limit and _done_items >= int(_limit):
            break
        
        if time.time() - last_update_time > 2:
            percent = int((completed / total) * 100) if total > 0 else 0
            progress_bar = "█" * (percent // 10) + "░" * (10 - (percent // 10))
            
            status_text = (
                f"⏳ <b>جاري حل الثقافة المالية...</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"👤 كود: <code>{login_id}</code>\n"
                f"📊 التقدم: <code>[{progress_bar}] {percent}%</code>\n"
                f"🎯 العنصر: <code>{item_title[:40]}</code>\n"
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"📝 <b>آخر النشاطات:</b>\n"
            )
            for act in activities[-4:]: status_text += f"• {act}\n"
            
            try: bot.edit_message_text(status_text, cid_tg, message_id)
            except: pass
            last_update_time = time.time()

    if fail_count > 0 and completed == 0:
        DB["failed"] += 1
    else:
        DB["success"] += 1
        
    # خصم المحاولة (باستثناء الـ VIP والأدمن)
    consume_attempt(cid_tg, _plan)
        
    save_db(DB)

    final_text = (
        f"🎉 <b>تم إنهاء الثقافة المالية!</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 كود: <code>{login_id}</code>\n"
        f"📸 <b>أرسل صورة النتيجة لـ</b> {OWNER_USERNAME}\n"
    )
    final_text += trial_footer(_plan)
    try: bot.edit_message_text(final_text, cid_tg, message_id)
    except: pass

# ==========================================
# 🎨 الواجهة (الأزرار)
# ==========================================
def get_grade_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(_b("🔵 الصف الأول الثانوي — JavaScript (42 فصل)", "grade_1", style="primary"))
    markup.add(_b("🟢 الصف الثاني الثانوي", "grade_2", style="success"))
    return markup


def get_subject_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(_b("🔵 JavaScript + 🟢 Python", "sel_code", style="primary"))
    markup.add(_b("🟠 الثقافة المالية", "sel_spx", style="danger"))
    markup.add(_b("🟣 الكل — JavaScript + Python + ثقافة", "sel_all", style="success"))
    markup.add(_b("🔙 تغيير الصف", "start_grades"))
    return markup


@bot.message_handler(commands=["start"])
def cmd_start(msg):
    cid = msg.chat.id
    _capture_ref(msg)
    
    # ⭐ التأكد إن الشخص مش محظور
    if DB.get("banned", {}).get(str(cid)):
        try: bot.send_message(cid, "🚫 <b>عذراً، أنت محظور من استخدام البوت.</b>", parse_mode="HTML")
        except: pass
        return
        
    if DB["settings"].get("maintenance") and not is_admin(cid):
        try: bot.send_message(cid, "🛠 <b>البوت تحت الصيانة حاليًا، جرب بعد شوية.</b>", parse_mode="HTML")
        except: pass
        return

    track_user(msg.chat)
    USERS[cid] = {"running": False}
    if cid not in DB["users"] and not is_owner(cid):
        DB["users"].append(cid)
        save_db(DB)
        try: on_new_user(msg)
        except Exception as _e: print("new-user hook:", _e)
    name = msg.from_user.first_name
    
    # ⭐ التحقق لو هو VIP
    user_credit = DB.get("credits", {}).get(str(cid))
    is_vip = (user_credit == "max")
    
    if is_owner(cid):
        title_text = f"👑 أهلاً بك يا مالك البوت، <b>{name}</b> {BOT_NAME} 🏴‍☠️!"
    elif is_vip:
        title_text = f"💎 أهلاً بك يا <b>{name}</b> في بوت {BOT_NAME} 🏴‍☠️!\n(عضو VIP - فرص لا نهائية)"
    else:
        title_text = f"👋 أهلاً بك يا <b>{name}</b> في بوت {BOT_NAME} 🏴‍☠️!"
        
    plan_line = "" if is_owner(cid) else f"\n{plan_text(cid)}"
    full_caption = f"{title_text}{plan_line}\n\nاختر الصف الدراسي أولاً:"
    
    # إرسال رسالة نصية فقط؛ لا يوجد GIF خارجي يمكن أن يفشل.
    try:
        bot.send_message(cid, full_caption, reply_markup=get_grade_keyboard(), parse_mode="HTML")
    except Exception as e:
        print(f"Msg Error: {e}")

# ==========================================
# 👑 أوامر الأونر
# ==========================================
@bot.message_handler(commands=["cmds"])
def cmd_owner_commands(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    text = (
        f"👑 <b>أوامر المالك</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"🎛 <code>/admin</code> - لوحة التحكم الكاملة\n"
        f"📊 <code>/cmd</code> - الإحصائيات\n"
        f"➕ <code>/solve [ID] [العدد]</code> - إضافة فرص\n"
        f"💎 <code>/vip [ID]</code> - تفعيل VIP\n"
        f"❌ <code>/unvip [ID]</code> - إزالة VIP\n"
        f"🔄 <code>/reset [ID]</code> - تصفير الفرص\n"
        f"🚫 <code>/ban [ID]</code> - حظر مستخدم\n"
        f"📢 <code>/broadcast [رسالتك]</code> - إذاعة\n"
    )
    bot.send_message(cid, text, parse_mode="HTML")

@bot.message_handler(commands=["vip"])
def cmd_owner_vip(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    try:
        args = msg.text.replace("/vip", "").strip().split()
        if len(args) < 1:
            bot.reply_to(msg, "⚠️ <b>الاستخدام الصحيح:</b>\n<code>/vip 8549348815</code>", parse_mode="HTML")
            return
        target_id = args[0]
        if is_owner(target_id):
            bot.reply_to(msg, f"💎 تم تفعيل <b>العضوية اللانهائية (VIP)</b> للطالب <code>{target_id}</code>.", parse_mode="HTML")
            return
        if "credits" not in DB: DB["credits"] = {}
        DB["credits"][target_id] = "max"
        DB.setdefault("vip_until", {}).pop(target_id, None)
        save_db(DB)
        bot.reply_to(msg, f"💎 تم تفعيل <b>العضوية اللانهائية (VIP)</b> للطالب <code>{target_id}</code>.", parse_mode="HTML")
    except Exception as e:
        bot.reply_to(msg, f"⚠️ خطأ: {e}")

@bot.message_handler(commands=["unvip"])
def cmd_owner_unvip(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    try:
        args = msg.text.replace("/unvip", "").strip().split()
        if len(args) < 1: return
        target_id = args[0]
        if is_owner(target_id):
            bot.reply_to(msg, f"✅ تم إزالة الـ VIP من الطالب <code>{target_id}</code>.", parse_mode="HTML")
            return
        if "credits" in DB and target_id in DB["credits"]:
            del DB["credits"][target_id]
            save_db(DB)
            bot.reply_to(msg, f"✅ تم إزالة الـ VIP من الطالب <code>{target_id}</code>.", parse_mode="HTML")
        else:
            bot.reply_to(msg, f"⚠️ هذا الطالب ليس VIP بالفعل.")
    except Exception as e:
        bot.reply_to(msg, f"⚠️ خطأ: {e}")

@bot.message_handler(commands=["ban"])
def cmd_owner_ban(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    try:
        args = msg.text.replace("/ban", "").strip().split()
        if len(args) < 1: return
        target_id = args[0]
        if is_owner(target_id):
            bot.reply_to(msg, f"🚫 تم حظر الطالب <code>{target_id}</code> من استخدام البوت.", parse_mode="HTML")
            return
        if "banned" not in DB: DB["banned"] = {}
        DB["banned"][target_id] = True
        save_db(DB)
        bot.reply_to(msg, f"🚫 تم حظر الطالب <code>{target_id}</code> من استخدام البوت.", parse_mode="HTML")
    except Exception as e:
        bot.reply_to(msg, f"⚠️ خطأ: {e}")

@bot.message_handler(commands=["reset"])
def cmd_owner_reset(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    try:
        args = msg.text.replace("/reset", "").strip().split()
        if len(args) < 1: return
        target_id = args[0]
        if is_owner(target_id):
            bot.reply_to(msg, f"🔄 تم تصفير فرص الطالب <code>{target_id}</code>.", parse_mode="HTML")
            return
        if "credits" not in DB: DB["credits"] = {}
        DB["credits"][target_id] = 0
        save_db(DB)
        bot.reply_to(msg, f"🔄 تم تصفير فرص الطالب <code>{target_id}</code>.", parse_mode="HTML")
    except Exception as e:
        bot.reply_to(msg, f"⚠️ خطأ: {e}")

@bot.message_handler(commands=["solve"])
def cmd_owner_add_credit(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    try:
        args = msg.text.replace("/solve", "").strip().split()
        if len(args) < 2:
            bot.reply_to(msg, "⚠️ <b>الاستخدام الصحيح:</b>\n<code>/solve 8549348815 10</code>", parse_mode="HTML")
            return
        target_id = args[0]
        amount = int(args[1])
        if is_owner(target_id):
            bot.reply_to(msg, f"✅ تم إضافة <code>{amount}</code> فرصة للطالب <code>{target_id}</code>.", parse_mode="HTML")
            return
        if "credits" not in DB: DB["credits"] = {}
        if DB["credits"].get(target_id) == "max":
            bot.reply_to(msg, f"⚠️ هذا الطالب VIP بالفعل.")
            return
        if target_id not in DB["credits"]: DB["credits"][target_id] = 0
        DB["credits"][target_id] += amount
        save_db(DB)
        bot.reply_to(msg, f"✅ تم إضافة <code>{amount}</code> فرصة للطالب <code>{target_id}</code>.", parse_mode="HTML")
    except ValueError:
        bot.reply_to(msg, "⚠️ <b>الاستخدام الصحيح:</b>\n<code>/solve 8549348815 10</code>", parse_mode="HTML")

@bot.message_handler(commands=["cmd"])
def cmd_owner_stats(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    db = load_db()
    text = (
        f"👑 <b>لوحة تحكم البوت</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 إجمالي المستخدمين: <code>{len(db.get('users', []))}</code>\n"
        f"✅ عمليات ناجحة: <code>{db.get('success', 0)}</code>\n"
        f"❌ عمليات فاشلة: <code>{db.get('failed', 0)}</code>\n"
    )
    bot.send_message(cid, text, parse_mode="HTML")

@bot.message_handler(commands=["broadcast"])
def cmd_owner_broadcast(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    text_to_send = msg.text.replace("/broadcast", "").strip()
    if not text_to_send:
        bot.reply_to(msg, "⚠️ <b>الاستخدام:</b> <code>/broadcast رسالتك هنا</code>", parse_mode="HTML")
        return
    db = load_db()
    users = db.get("users", [])
    if not users:
        bot.reply_to(msg, "⚠️ مفيش مستخدمين مسجلين.")
        return
    sent_count = 0
    failed_count = 0
    status_msg = bot.reply_to(msg, f"⏳ جاري الإرسال لـ {len(users)} مستخدم...")
    for user_id in users:
        try:
            bot.send_message(user_id, f"📢 <b>رسالة إدارية:</b>\n\n{text_to_send}", parse_mode="HTML")
            sent_count += 1
            time.sleep(0.05)
        except: failed_count += 1
    bot.edit_message_text(
        f"✅ <b>تمت الإذاعة!</b>\n\n📤 تم الإرسال لـ: <code>{sent_count}</code>\n🚫 فشل الإرسال لـ: <code>{failed_count}</code>",
        chat_id=cid, message_id=status_msg.message_id, parse_mode="HTML"
    )

# ==========================================
# 🎛 لوحة الأدمن (Admin Panel)  —  /admin
# ==========================================
import queue
from datetime import datetime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo
    _TZ = ZoneInfo("Africa/Cairo")
except Exception:
    _TZ = timezone(timedelta(hours=2))

AP_PAGE_SIZE = 8          # عدد المستخدمين في الصفحة
AP_BC_WORKERS = 5         # خيوط الإذاعة
AP_BC_DELAY = 0.2         # تأخير كل خيط (≈ 25 رسالة/ثانية)
AP_STATE = {}             # uid -> حالة انتظار إدخال نصي من الأدمن
AP_PENDING = {}           # uid -> رسالة إذاعة منتظرة التأكيد
AP_BC = {"running": False, "stop": False}
AP_ALL_TYPES = ["text", "photo", "video", "document", "audio", "voice",
                "animation", "sticker", "video_note"]


def _esc(s):
    return html.escape(str(s or ""))


def _ts(t):
    if not t:
        return "—"
    return datetime.fromtimestamp(t, _TZ).strftime("%Y-%m-%d %H:%M")


_STYLE_EMOJI = {"success": "🟢", "danger": "🔴", "primary": "🔵"}


class _StyledBtn(types.InlineKeyboardButton):
    """زر إنلاين بيبعت حقل style (أخضر/أحمر/أزرق) لتيليجرام مباشرة،
    من غير ما نعتمد على إصدار المكتبة."""
    def __init__(self, *args, _style=None, **kwargs):
        super().__init__(*args, **kwargs)
        self._style = _style

    def to_dict(self):
        d = super().to_dict()
        if self._style:
            d["style"] = self._style
        return d

    def to_dic(self):                      # نسخ telebot القديمة
        return self.to_dict()

    def to_json(self):
        import json as _json
        return _json.dumps(self.to_dict())


def _b(text, data=None, url=None, style=None):
    """زر ملون: style = success (أخضر) / danger (أحمر) / primary (أزرق).
    الوضع الأصلي (الافتراضي): بيبعت style لتيليجرام. لو الأدمن قفله من الإعدادات
    بنحط إيموجي ملون في النص بدل كده."""
    native = bool(DB["settings"].get("native_colors", True))
    if style and not native:
        text = f"{_STYLE_EMOJI.get(style, '')} {text}".strip()
    kw = {"text": text}
    if url:
        kw["url"] = url
    else:
        kw["callback_data"] = data
    if style and native:
        return _StyledBtn(_style=style, **kw)
    return types.InlineKeyboardButton(**kw)


def _kb(*rows):
    k = types.InlineKeyboardMarkup()
    for r in rows:
        k.row(*r)
    return k


def _show(chat, mid, text, kb=None):
    try:
        bot.edit_message_text(text, chat, mid, reply_markup=kb,
                              parse_mode="HTML", disable_web_page_preview=True)
    except Exception as e:
        if "message is not modified" not in str(e):
            raise


def _del(chat, mid):
    try:
        bot.delete_message(chat, mid)
    except Exception:
        pass


def _back(to="adm:home"):
    return [_b("🔙 رجوع", to)]


def _credit_label(c, until=None):
    if c == "max":
        return "💎 VIP " + (f"حتى {_ts(until)}" if until else "(دائم)")
    if c is None:
        return "لا يوجد رصيد"
    return f"{c} فرصة"


# ---------------- تتبع المستخدمين ----------------
_last_save = [0]


def track_user(chat):
    """بيسجل الاسم واليوزر ووقت الانضمام/آخر ظهور. chat = message.chat."""
    if is_owner(getattr(chat, "id", 0)):
        return
    try:
        k = str(chat.id)
        now = int(time.time())
        info = DB["info"].get(k) or {"joined": now}
        info.update(name=getattr(chat, "first_name", "") or "",
                    username=getattr(chat, "username", "") or "",
                    last_seen=now)
        DB["info"][k] = info
        DB["blocked"].pop(k, None)
        if now - _last_save[0] > 30:        # حفظ كل 30 ثانية بحد أقصى
            _last_save[0] = now
            save_db(DB)
    except Exception:
        pass


# ---------------- الصفحات ----------------
def ap_home_kb(uid):
    rows = [
        [_b("📊 الإحصائيات", "adm:stats"), _b("👥 المستخدمين", "adm:users:a:0")],
        [_b("📢 إذاعة", "adm:bc", style="primary"), _b("⚙️ الإعدادات", "adm:set")],
    ]
    last = [_b("💾 نسخة احتياطية", "adm:backup")]
    if is_owner(uid):
        last.insert(0, _b("🛡 الأدمنز", "adm:admins"))
    rows.append(last)
    rows.append([_b("إغلاق", "adm:close", style="danger")])
    return _kb(*rows)


def ap_home_text():
    st = DB["settings"]
    return (f"🎛 <b>لوحة التحكم</b>\n\n"
            f"👥 المستخدمين: <b>{len(DB['users'])}</b>\n"
            f"📢 الاشتراك الإجباري: {'🟢' if st.get('force_sub', True) else '🔴'}   "
            f"🛠 الصيانة: {'🟢' if st.get('maintenance') else '🔴'}\n"
            f"🕐 {datetime.now(_TZ).strftime('%Y-%m-%d %H:%M')}\n\nاختار قسم:")


def ap_stats():
    now = int(time.time())
    users = DB["users"]
    credits = DB["credits"]
    vip = sum(1 for v in credits.values() if v == "max")
    with_chances = sum(1 for v in credits.values() if isinstance(v, int) and v > 0)
    banned = sum(1 for v in DB["banned"].values() if v)
    infos = DB["info"].values()
    act24 = sum(1 for i in infos if now - i.get("last_seen", 0) < 86400)
    act7 = sum(1 for i in infos if now - i.get("last_seen", 0) < 7 * 86400)
    n_today = sum(1 for i in infos if i.get("joined", 0) >= int(
        datetime.now(_TZ).replace(hour=0, minute=0, second=0, microsecond=0).timestamp()))
    running = sum(1 for u in USERS.values() if u.get("running"))
    ok, bad = DB.get("success", 0), DB.get("failed", 0)
    rate = (ok * 100 // (ok + bad)) if (ok + bad) else 0
    text = (
        "📊 <b>الإحصائيات</b>\n\n"
        f"👥 إجمالي المستخدمين: <b>{len(users)}</b>\n"
        f"🟢 نشطين آخر 24 ساعة: <b>{act24}</b>\n"
        f"🔥 نشطين آخر 7 أيام: <b>{act7}</b>\n"
        f"🆕 جداد النهاردة: <b>{n_today}</b>\n"
        f"🚪 سابوا البوت: <b>{len(DB['blocked'])}</b>\n"
        f"🚫 محظورين: <b>{banned}</b>\n\n"
        f"💎 VIP: <b>{vip}</b>\n"
        f"🎟 معاهم فرص: <b>{with_chances}</b>\n"
        f"✅ عمليات ناجحة: <b>{ok}</b>\n"
        f"❌ عمليات فاشلة: <b>{bad}</b>\n"
        f"📈 نسبة النجاح: <b>{rate}%</b>\n"
        f"⚡ جلسات شغالة دلوقتي: <b>{running}</b>\n\n"
        "<i>النشطين والجداد بيتحسبوا من وقت تفعيل اللوحة.</i>"
    )
    return text, _kb([_b("🔄 تحديث", "adm:stats")], _back())


def _ap_filter_ids(flt):
    ids = [u for u in reversed(DB["users"]) if not is_owner(u)]
    if flt == "v":
        ids = [u for u in ids if DB["credits"].get(str(u)) == "max"]
    elif flt == "b":
        ids = [u for u in ids if DB["banned"].get(str(u))]
    return ids


def _ap_ubtn(uid, flt, page):
    k = str(uid)
    icon = "🚫" if DB["banned"].get(k) else ("💎" if DB["credits"].get(k) == "max" else "🟢")
    info = DB["info"].get(k, {})
    name = (info.get("name") or info.get("username") or "بدون اسم")[:18]
    return [_b(f"{icon} {name} • {uid}", f"adm:user:{uid}:{flt}:{page}")]


def ap_users(flt, page):
    ids = _ap_filter_ids(flt)
    total = len(ids)
    pages = max(1, -(-total // AP_PAGE_SIZE))
    page = max(0, min(page, pages - 1))
    chunk = ids[page * AP_PAGE_SIZE:(page + 1) * AP_PAGE_SIZE]
    title = {"a": "👥 المستخدمين", "v": "💎 الـ VIP", "b": "🚫 المحظورين"}[flt]
    text = f"{title}\nالإجمالي: <b>{total}</b> • صفحة {page + 1}/{pages}"
    if not chunk:
        text += "\n\nمفيش نتائج."
    keys = [_ap_ubtn(u, flt, page) for u in chunk]
    nav = []
    if page > 0:
        nav.append(_b("⬅️ السابق", f"adm:users:{flt}:{page - 1}"))
    nav.append(_b(f"{page + 1}/{pages}", "adm:noop"))
    if page < pages - 1:
        nav.append(_b("التالي ➡️", f"adm:users:{flt}:{page + 1}"))
    keys.append(nav)
    keys.append([_b("👥 الكل", "adm:users:a:0"), _b("💎 VIP", "adm:users:v:0"),
                 _b("🚫 محظورين", "adm:users:b:0")])
    keys.append([_b("🔎 بحث", "adm:search")])
    keys.append(_back())
    return text, _kb(*keys)


def ap_user_card(uid, flt="a", page=0):
    k = str(uid)
    if int(uid) not in DB["users"] and k not in DB["info"]:
        return "❌ المستخدم مش موجود.", _kb(_back(f"adm:users:{flt}:{page}"))
    info = DB["info"].get(k, {})
    cr = DB["credits"].get(k)
    banned = bool(DB["banned"].get(k))
    status = "🚫 محظور" if banned else ("🚪 سابق البوت" if k in DB["blocked"] else "🟢 نشط")
    uname = f"@{_esc(info.get('username'))}" if info.get("username") else "—"
    text = (
        "👤 <b>بيانات المستخدم</b>\n\n"
        f"🆔 ID: <code>{uid}</code>\n"
        f"📛 الاسم: {_esc(info.get('name')) or '—'}\n"
        f"🔗 اليوزر: {uname}\n"
        f"📅 انضم: {_ts(info.get('joined'))}\n"
        f"🕐 آخر ظهور: {_ts(info.get('last_seen'))}\n"
        f"🎟 الرصيد: <b>{_credit_label(cr, DB['vip_until'].get(k))}</b>\n"
        f"الحالة: {status}"
    )
    tail = f":{flt}:{page}"
    if cr == "max":
        vip_row = [_b("إلغاء VIP", f"adm:unvip:{uid}{tail}", style="danger"),
                   _b("تجديد 30 يوم", f"adm:vip:{uid}:30{tail}", style="success")]
    else:
        vip_row = [_b("VIP دائم", f"adm:vip:{uid}:0{tail}", style="success"),
                   _b("30 يوم", f"adm:vip:{uid}:30{tail}", style="primary"),
                   _b("7 أيام", f"adm:vip:{uid}:7{tail}", style="primary")]
    ban_btn = (_b("فك الحظر", f"adm:unban:{uid}{tail}", style="success") if banned
               else _b("حظر المستخدم", f"adm:ban:{uid}{tail}", style="danger"))
    return text, _kb(
        vip_row,
        [_b("+1 فرصة", f"adm:cr:{uid}:1{tail}", style="success"),
         _b("+5", f"adm:cr:{uid}:5{tail}", style="success"),
         _b("+10", f"adm:cr:{uid}:10{tail}", style="success")],
        [_b("تصفير", f"adm:reset:{uid}{tail}", style="danger")],
        [ban_btn],
        [_b("✉️ مراسلة", f"adm:dm:{uid}"), _b("🔗 فتح الحساب", url=f"tg://user?id={uid}")],
        _back(f"adm:users:{flt}:{page}"))


def ap_settings():
    st = DB["settings"]
    on = lambda v: "🟢 شغال" if v else "🔴 مقفول"
    sty = lambda v: "success" if v else "danger"
    text = (
        "⚙️ <b>الإعدادات</b>\n\n"
        f"📢 قناة الاشتراك: <code>{_esc(st.get('channel'))}</code>\n"
        f"📢 الاشتراك الإجباري (على كل الأزرار): {on(st.get('force_sub', True))}\n"
        f"🛠 وضع الصيانة: {on(st.get('maintenance'))}\n\n"
        f"🎨 الأزرار الملونة الأصلية: {on(st.get('native_colors', True))}\n\n"
        "<i>أي تغيير بيتطبق فورًا بدون إعادة تشغيل.</i>"
    )
    return text, _kb(
        [_b("الاشتراك الإجباري", "adm:tog:force_sub", style=sty(st.get("force_sub", True))),
         _b("الصيانة", "adm:tog:maintenance", style="danger" if st.get("maintenance") else "success")],
        [_b("✏️ تغيير القناة", "adm:chan"), _b("✏️ رسالة الشراء", "adm:ask_buy")],
        [_b("الأزرار الملونة الأصلية", "adm:tog:native_colors", style=sty(st.get("native_colors", True)))],
        _back())


def ap_admins(viewer=None):
    adm = [a for a in DB["settings"].get("admins", []) if not is_owner(a)]
    text = f"🛡 <b>الأدمنز</b>\n\n👑 المالك: <code>{viewer if viewer is not None else OWNER_ID}</code>\n"
    text += "\n".join(f"• <code>{a}</code>" for a in adm) or "مفيش أدمنز تانيين."
    keys = [[_b(f"حذف {a}", f"adm:adm_del:{a}", style="danger")] for a in adm]
    keys.append([_b("إضافة أدمن", "adm:adm_add", style="success")])
    keys.append(_back())
    return text, _kb(*keys)


# ---------------- الإذاعة ----------------
def _bc_targets(mode):
    out = []
    for uid in DB["users"]:
        k = str(uid)
        if is_owner(uid) or DB["banned"].get(k) or k in DB["blocked"]:
            continue
        cr = DB["credits"].get(k)
        if mode == "vip" and cr != "max":
            continue
        if mode == "free" and cr == "max":
            continue
        out.append(uid)
    return out


def _bc_bar(done, total):
    n = int(10 * done / total) if total else 10
    return "█" * n + "░" * (10 - n)


def _bc_text(final=False):
    done = AP_BC["sent"] + AP_BC["failed"] + AP_BC["blocked"]
    if final:
        head = "⏹ <b>الإذاعة اتوقفت</b>" if AP_BC["stop"] else "✅ <b>خلصت الإذاعة</b>"
    else:
        head = "📢 <b>الإذاعة شغالة...</b>"
    el = max(1, int(time.time() - AP_BC["t0"]))
    return (f"{head}\n\n{_bc_bar(done, AP_BC['total'])} {done}/{AP_BC['total']}\n\n"
            f"✅ وصلت: <b>{AP_BC['sent']}</b>\n🚪 سابوا البوت: <b>{AP_BC['blocked']}</b>\n"
            f"⚠️ فشلت: <b>{AP_BC['failed']}</b>\n⏱ {el} ثانية")


def _bc_send_one(uid, src_chat, src_msg):
    for _ in range(3):
        try:
            bot.copy_message(uid, src_chat, src_msg)
            return "ok"
        except telebot.apihelper.ApiTelegramException as e:
            desc = (e.description or "").lower()
            if e.error_code == 429:
                wait = 5
                try:
                    wait = e.result_json.get("parameters", {}).get("retry_after", 5)
                except Exception:
                    pass
                time.sleep(wait + 1)
                continue
            if e.error_code == 403 or "chat not found" in desc or "deactivated" in desc:
                DB["blocked"][str(uid)] = 1
                return "blocked"
            return "fail"
        except Exception:
            time.sleep(1)
    return "fail"


def ap_run_broadcast(chat, panel, src_chat, src_msg, mode):
    ids = _bc_targets(mode)
    AP_BC.update(running=True, stop=False, total=len(ids), sent=0, failed=0,
                 blocked=0, t0=time.time())
    lock = threading.Lock()
    qu = queue.Queue()
    for i in ids:
        qu.put(i)

    def worker():
        while not AP_BC["stop"]:
            try:
                uid = qu.get_nowait()
            except queue.Empty:
                break
            res = _bc_send_one(uid, src_chat, src_msg)
            with lock:
                AP_BC[{"ok": "sent", "blocked": "blocked"}.get(res, "failed")] += 1
            time.sleep(AP_BC_DELAY)

    threads = [threading.Thread(target=worker, daemon=True) for _ in range(AP_BC_WORKERS)]
    for t in threads:
        t.start()
    stop_kb = _kb([_b("إيقاف", "adm:bc_stop", style="danger")])
    while any(t.is_alive() for t in threads):
        time.sleep(3)
        try:
            _show(chat, panel, _bc_text(), stop_kb)
        except Exception:
            pass
    AP_BC["running"] = False
    save_db(DB)
    try:
        _show(chat, panel, _bc_text(final=True), _kb(_back()))
    except Exception:
        pass


# ---------------- الأوامر ----------------
@bot.message_handler(commands=["admin"], chat_types=["private"])
def ap_cmd_admin(m):
    if not is_admin(m.from_user.id):
        return
    AP_STATE.pop(m.from_user.id, None)
    bot.send_message(m.chat.id, ap_home_text(), reply_markup=ap_home_kb(m.from_user.id))


@bot.message_handler(commands=["cancel"], chat_types=["private"])
def ap_cmd_cancel(m):
    if AP_STATE.pop(m.from_user.id, None):
        bot.send_message(m.chat.id, "تم الإلغاء ✅")


def _ap_ask(uid, chat, mid, action, text, data=None, back="adm:home"):
    AP_STATE[uid] = {"a": action, "chat": chat, "msg": mid, "d": data}
    _show(chat, mid, text + "\n\n<i>ابعتلي دلوقتي 👇</i>", _kb(_back(back)))


# ---------------- الأزرار ----------------
@bot.callback_query_handler(func=lambda c: c.data.startswith("adm:"))
def ap_callback(c):
    uid = c.from_user.id
    if not is_admin(uid):
        return bot.answer_callback_query(c.id, "⛔ مش مسموحلك", show_alert=True)
    p = c.data.split(":")[1:]
    act, a = p[0], p[1:]
    chat, mid = c.message.chat.id, c.message.message_id
    AP_STATE.pop(uid, None)
    answer, alert = "", False
    if act in AP_EXTRA:
        return ap_extra_cb(c, act, a, uid, chat, mid)

    try:
        with DB_LOCK:
            if act in ("vip", "unvip", "cr", "reset", "ban", "unban"):
                target = a[0]
                tail = a[2:] if act in ("cr", "vip") else a[1:]
                flt, page = tail[0], int(tail[1])
                if act == "vip":
                    days = int(a[1])
                    DB["credits"][target] = "max"
                    if days > 0:
                        DB["vip_until"][target] = int(time.time()) + days * 86400
                    else:
                        DB["vip_until"].pop(target, None)
                    answer = "💎 تم تفعيل VIP " + (f"{days} يوم" if days else "دائم")
                elif act == "unvip":
                    DB["credits"][target] = 0
                    DB["vip_until"].pop(target, None)
                    answer = "تم إلغاء VIP"
                elif act == "reset":
                    DB["credits"][target] = 0
                    answer = "🔄 تم تصفير الفرص"
                elif act == "cr":
                    cur = DB["credits"].get(target)
                    if cur == "max":
                        answer = "الطالب VIP بالفعل"
                    else:
                        DB["credits"][target] = (cur if isinstance(cur, int) else 0) + int(a[1])
                        answer = f"✅ تمت إضافة {a[1]} فرصة"
                elif act == "ban":
                    if is_admin(int(target)):
                        answer, alert = "مينفعش تحظر أدمن", True
                    else:
                        DB["banned"][target] = True
                        answer = "🚫 تم الحظر"
                else:
                    DB["banned"].pop(target, None)
                    answer = "✅ تم فك الحظر"
                save_db(DB)
                log_event("admin", uid, f"{act} {target}")
                _show(chat, mid, *ap_user_card(int(target), flt, page))
            elif act == "tog":
                if a[0] in ("force_sub", "maintenance", "native_colors"):
                    cur = DB["settings"].get(a[0], a[0] in ("force_sub", "native_colors"))
                    DB["settings"][a[0]] = not cur
                    save_db(DB)
                _show(chat, mid, *ap_settings())
            elif act == "num":
                key, d = a[0], int(a[1])
                _show(chat, mid, *ap_settings())
            elif act == "adm_del":
                if not is_owner(uid):
                    answer, alert = "⛔ للمالك فقط", True
                else:
                    DB["settings"]["admins"] = [x for x in DB["settings"].get("admins", [])
                                                if str(x) != a[0]]
                    save_db(DB)
                    _show(chat, mid, *ap_admins(uid))

        if act == "noop":
            pass
        elif act == "home":
            _show(chat, mid, ap_home_text(), ap_home_kb(uid))
        elif act == "close":
            _del(chat, mid)
        elif act == "stats":
            _show(chat, mid, *ap_stats())
        elif act == "users":
            _show(chat, mid, *ap_users(a[0], int(a[1])))
        elif act == "user":
            _show(chat, mid, *ap_user_card(int(a[0]), a[1], int(a[2])))
        elif act == "search":
            _ap_ask(uid, chat, mid, "search", "🔎 ابعت ID أو يوزرنيم أو جزء من الاسم:",
                    back="adm:users:a:0")
        elif act == "dm":
            _ap_ask(uid, chat, mid, "dm",
                    f"✉️ ابعت الرسالة اللي هتتبعت للمستخدم <code>{a[0]}</code>:",
                    data=int(a[0]), back=f"adm:user:{a[0]}:a:0")
        elif act == "bc":
            if AP_BC["running"]:
                _show(chat, mid, _bc_text(), _kb([_b("إيقاف", "adm:bc_stop", style="danger")]))
            else:
                _ap_ask(uid, chat, mid, "broadcast",
                        "📢 <b>إذاعة</b>\nابعت الرسالة اللي عايز تذيعها (نص/صورة/فيديو/ملف...):")
        elif act == "bc_go":
            pend = AP_PENDING.pop(uid, None)
            if not pend:
                answer = "مفيش رسالة جاهزة"
                _show(chat, mid, ap_home_text(), ap_home_kb(uid))
            elif AP_BC["running"]:
                answer = "في إذاعة شغالة بالفعل"
            else:
                threading.Thread(target=ap_run_broadcast,
                                 args=(chat, mid, pend["chat"], pend["msg"], a[0]),
                                 daemon=True).start()
                answer = "بدأت الإذاعة 🚀"
        elif act == "bc_stop":
            AP_BC["stop"] = True
            answer = "جاري الإيقاف..."
        elif act == "bc_cancel":
            AP_PENDING.pop(uid, None)
            _show(chat, mid, ap_home_text(), ap_home_kb(uid))
        elif act == "set":
            _show(chat, mid, *ap_settings())
        elif act == "ask_buy":
            _ap_ask(uid, chat, mid, "buy",
                    "✏️ ابعت نص <b>رسالة الشراء</b> الجديدة (HTML مسموح).\n"
                    "تقدر تكتب <code>{chapters}</code> وهيتبدل بعدد فصول المحاولة المجانية.",
                    back="adm:set")
        elif act == "chan":
            _ap_ask(uid, chat, mid, "chan",
                    "📺 ابعت يوزر القناة الجديدة (<code>@channel</code>) أو الـ ID (<code>-100...</code>).\n"
                    "لازم البوت يكون أدمن فيها.", back="adm:set")
        elif act in ("admins", "adm_add"):
            if not is_owner(uid):
                answer, alert = "⛔ للمالك فقط", True
            elif act == "admins":
                _show(chat, mid, *ap_admins(uid))
            else:
                _ap_ask(uid, chat, mid, "adm_add", "🛡 ابعت ID الأدمن الجديد:", back="adm:admins")
        elif act == "backup":
            with DB_LOCK:
                save_db(DB)
                tmp = f"backup_{int(time.time())}.json"
                with open(USERS_FILE, "rb") as src, open(tmp, "wb") as dst:
                    dst.write(src.read())
            with open(tmp, "rb") as f:
                bot.send_document(chat, f, caption="💾 نسخة احتياطية " + _ts(int(time.time())))
            os.remove(tmp)
            answer = "اتبعتت ✅"
    except Exception as e:
        answer, alert = "⚠️ حصل خطأ: " + str(e)[:150], True
    try:
        bot.answer_callback_query(c.id, answer, show_alert=alert)
    except Exception:
        pass


# ---------------- استقبال الإدخال النصي من الأدمن ----------------
_AP_TEXT_ACTIONS = ("search", "chan", "adm_add", "buy")


@bot.message_handler(
    func=lambda m: m.chat.type == "private" and m.from_user.id in AP_STATE and is_admin(m.from_user.id),
    content_types=AP_ALL_TYPES)
def ap_on_state(m):
    uid = m.from_user.id
    st = AP_STATE.pop(uid)
    a, chat, mid = st["a"], st["chat"], st["msg"]
    if a in _AP_TEXT_ACTIONS and not m.text:
        AP_STATE[uid] = st
        return bot.reply_to(m, "⚠️ ابعت نص بس.")
    if a not in ("broadcast", "dm"):          # الإذاعة والمراسلة محتاجين الرسالة الأصلية للنسخ
        _del(m.chat.id, m.message_id)
    t = (m.text or "").strip()

    try:
        if a == "broadcast":
            AP_PENDING[uid] = {"chat": m.chat.id, "msg": m.message_id}
            n_all, n_vip, n_free = (len(_bc_targets(x)) for x in ("all", "vip", "free"))
            _show(chat, mid, "📢 <b>تأكيد الإذاعة</b>\nالرسالة اللي فوق هي اللي هتتبعت. اختار الجمهور:",
                  _kb([_b(f"للكل ({n_all})", "adm:bc_go:all", style="success")],
                      [_b(f"VIP بس ({n_vip})", "adm:bc_go:vip", style="primary"),
                       _b(f"غير VIP ({n_free})", "adm:bc_go:free", style="primary")],
                      [_b("إلغاء", "adm:bc_cancel", style="danger")]))
        elif a == "dm":
            try:
                bot.copy_message(st["d"], m.chat.id, m.message_id)
                res = "✅ الرسالة اتبعتت.\n\n"
            except Exception as e:
                res = "⚠️ فشل الإرسال: " + _esc(str(e)[:100]) + "\n\n"
            text, kb = ap_user_card(st["d"])
            _show(chat, mid, res + text, kb)
        elif a == "search":
            rows = []
            if t.lstrip("-").isdigit():
                if int(t) in DB["users"] or t in DB["info"]:
                    rows = [int(t)]
            else:
                needle = t.lstrip("@").lower()
                for k, i in DB["info"].items():
                    if needle in (i.get("username") or "").lower() or needle in (i.get("name") or "").lower():
                        rows.append(int(k))
                        if len(rows) >= 8:
                            break
            if len(rows) == 1:
                _show(chat, mid, *ap_user_card(rows[0]))
            elif rows:
                keys = [_ap_ubtn(u, "a", 0) for u in rows] + [_back("adm:users:a:0")]
                _show(chat, mid, f"🔎 نتائج البحث ({len(rows)}):", _kb(*keys))
            else:
                _show(chat, mid, "❌ مفيش نتائج.", _kb([_b("🔎 بحث تاني", "adm:search")],
                                                      _back("adm:users:a:0")))
        elif a == "chan":
            ref = t if t.startswith("@") or t.lstrip("-").isdigit() else "@" + t
            bot.get_chat(ref)                       # يتأكد إن القناة موجودة والبوت شايفها
            with DB_LOCK:
                DB["settings"]["channel"] = ref
                SUB_CACHE.clear()
                save_db(DB)
            _show(chat, mid, *ap_settings())
        elif a == "buy":
            with DB_LOCK:
                DB["settings"]["buy_text"] = getattr(m, "html_text", None) or t
                save_db(DB)
            _show(chat, mid, "✅ تم حفظ رسالة الشراء. دي المعاينة:\n\n" +
                  DB["settings"]["buy_text"].replace("{chapters}", str(DB["settings"].get("free_chapters", 3))),
                  _kb(_back("adm:set")))
        elif a == "adm_add":
            if t.isdigit():
                with DB_LOCK:
                    adm = DB["settings"].setdefault("admins", [])
                    if int(t) not in adm and not is_owner(int(t)):
                        adm.append(int(t))
                    save_db(DB)
            _show(chat, mid, *ap_admins(uid))
    except Exception as e:
        _show(chat, mid, "⚠️ حصل خطأ: " + _esc(str(e)[:200]), _kb(_back()))


@bot.message_handler(commands=["colors"], chat_types=["private"])
def ap_cmd_colors(m):
    if not is_owner(m.from_user.id):
        return
    arg = (m.text or "").split()[1:2]
    if not arg or arg[0] not in ("on", "off"):
        cur = "شغالة" if DB["settings"].get("native_colors", True) else "مقفولة"
        return bot.send_message(m.chat.id, f"🎨 الألوان الأصلية حاليًا: {cur}\nاستخدم: /colors on أو /colors off")
    DB["settings"]["native_colors"] = (arg[0] == "on")
    save_db(DB)
    bot.send_message(m.chat.id, "🎨 الألوان الأصلية: " + ("✅ اتفعلت" if arg[0] == "on" else "⛔ اتقفلت (إيموجي ملون بدلها)"))


# ===== EXTRAS APPLIED =====
# ==========================================
# 🚀 إضافات: أكواد التفعيل • الإحالات • فحص النظام • السجل • العروض • نسخ تلقائي
# ==========================================
import csv
import secrets
import sys

CB_MIN_GAP = 0.6                 # أقل وقت بين ضغطتين لنفس المستخدم (ثانية) — ضد السبام
_LAST_CB = {}
PENDING_REF = {}                 # cid -> id اللي دعاه (لحد ما يشترك ويكمل)
_REDEEM_FAILS = {}
_LOGIN_REPORTED = {}
_BOT_USER = [None]


def _s(key, default=None):
    return DB["settings"].get(key, default)


def log_event(kind, uid=None, text=""):
    """سجل أحداث (آخر 300 حدث) بيظهر في لوحة الأدمن ← 📜 السجل."""
    try:
        if uid is not None and is_owner(uid):
            return
        lg = DB["log"]
        lg.append({"t": int(time.time()), "k": kind, "u": uid, "x": str(text)[:120]})
        if len(lg) > 300:
            del lg[:len(lg) - 300]
    except Exception:
        pass


def _bot_username():
    if not _BOT_USER[0]:
        try:
            _BOT_USER[0] = bot.get_me().username
        except Exception:
            _BOT_USER[0] = ""
    return _BOT_USER[0]


# ---------------- أكواد التفعيل ----------------
CODE_TYPES = [
    ("c1", "فرصة", "credits", 1),
    ("c5", "5 فرص", "credits", 5),
    ("c10", "10 فرص", "credits", 10),
    ("v7", "VIP 7 أيام", "vip", 7),
    ("v30", "VIP 30 يوم", "vip", 30),
]


def _code_label(c):
    return f"{c['value']} فرصة" if c["type"] == "credits" else f"VIP {c['value']} يوم"


def redeem_code(uid, raw):
    """بيرجّع (نجح؟, رسالة HTML)."""
    if is_owner(uid):
        return False, "👑 أنت مالك — حسابك بدون حدود ومش محتاج كود."
    k = str(uid)
    now = time.time()
    fails = [t for t in _REDEEM_FAILS.get(uid, []) if now - t < 600]
    if len(fails) >= 5:
        return False, "⛔ محاولات غلط كتير. جرّب بعد 10 دقايق."
    code = re.sub(r"\s+", "", raw or "").upper()
    with DB_LOCK:
        c = DB["codes"].get(code)
        max_uses = max(1, int(c.get("max_uses", 1))) if isinstance(c, dict) else 1
        used_list = c.get("used_by_list", []) if isinstance(c, dict) else []
        if not c or (max_uses == 1 and c.get("used_by")) or (max_uses > 1 and len(used_list) >= max_uses):
            fails.append(now)
            _REDEEM_FAILS[uid] = fails
            return False, "❌ الكود غلط أو مستخدم قبل كده."
        if max_uses > 1 and uid in used_list:
            return False, "❌ استخدمت الكود ده قبل كده."
        cr = DB["credits"].get(k)
        if c["type"] == "credits":
            if cr == "max":
                return False, "💎 أنت VIP بالفعل — الكود لسه متاح ومحصلش خصم."
            DB["credits"][k] = (cr if isinstance(cr, int) else 0) + int(c["value"])
            msg = f"✅ اتفعّل الكود! اتضاف لك <b>{c['value']}</b> فرصة."
        else:
            days = int(c["value"])
            until = DB["vip_until"].get(k)
            if cr == "max" and not until:
                return False, "💎 اشتراكك VIP دائم بالفعل."
            base = max(now, until or 0) if cr == "max" else now
            DB["credits"][k] = "max"
            DB["vip_until"][k] = int(base + days * 86400)
            msg = f"✅ اتفعّل الكود! اشتراك VIP لمدة <b>{days}</b> يوم."
        if max_uses > 1:
            c.setdefault("used_by_list", []).append(uid)
            c["uses"] = len(c["used_by_list"])
        else:
            c["used_by"] = uid
        c["used_at"] = int(now)
        save_db(DB)
    _REDEEM_FAILS.pop(uid, None)
    log_event("redeem", uid, f"{code} → {_code_label(c)}")
    return True, msg


@bot.message_handler(commands=["id"], chat_types=["private"])
def cmd_id(m):
    bot.send_message(m.chat.id, f"🆔 الـ ID بتاعك: <code>{m.from_user.id}</code>", parse_mode="HTML")


@bot.message_handler(commands=["help"], chat_types=["private"])
def cmd_help(m):
    txt = (f"ℹ️ <b>مساعدة {BOT_NAME}</b>\n\n"
           "• /start — القائمة الرئيسية واختيار المادة\n"
           "• /redeem — تفعيل كود\n"
           "• /id — معرفة الـ ID بتاعك\n\n"
           f"للشراء أو الدعم: {OWNER_USERNAME}")
    if is_admin(m.from_user.id):
        txt += "\n\n🎛 /admin — لوحة التحكم • /cmds — أوامر المالك • /ping — فحص سريع"
    bot.send_message(m.chat.id, txt, parse_mode="HTML")


@bot.message_handler(commands=["ping"], chat_types=["private"])
def cmd_ping(m):
    if is_admin(m.from_user.id):
        bot.send_message(m.chat.id, "🏓 pong — البوت شغال")


@bot.message_handler(commands=["redeem"], chat_types=["private"])
def cmd_redeem(m):
    cid = m.chat.id
    if not user_gate(cid):
        return
    parts = (m.text or "").split(maxsplit=1)
    if len(parts) < 2:
        USERS.setdefault(cid, {"running": False})["await_code"] = True
        return bot.send_message(cid, "🎟 ابعت كود التفعيل دلوقتي:")
    _ok, text = redeem_code(cid, parts[1])
    bot.send_message(cid, text, parse_mode="HTML")


@bot.message_handler(commands=["code"], chat_types=["private"])
def cmd_code(m):
    """ينشئ كود VIP مباشر: /code 1d 1 أو /code 30d 10."""
    if not is_owner(m.from_user.id):
        return
    parts = (m.text or "").split()
    if len(parts) != 3:
        bot.send_message(m.chat.id, "الصيغة الصحيحة: /code 1d 1\nمثال: /code 7d 10")
        return
    match = re.fullmatch(r"(\d+)(?:d|day|days)", parts[1].lower())
    try:
        days, uses = (int(match.group(1)) if match else 0), int(parts[2])
    except (AttributeError, ValueError):
        days, uses = 0, 0
    if days < 1 or days > 3650 or uses < 1 or uses > 100000:
        bot.send_message(m.chat.id, "المدة لازم تكون مثل 1d أو 30d، وعدد الاستخدامات رقم أكبر من صفر.")
        return
    while True:
        code = secrets.token_urlsafe(7).replace("-", "").replace("_", "").upper()
        if code not in DB["codes"]:
            break
    DB["codes"][code] = {
        "type": "vip", "value": days, "created_at": int(time.time()),
        "created_by": int(m.from_user.id), "max_uses": uses, "uses": 0,
        "used_by_list": [], "used_by": None,
    }
    save_db(DB)
    bot.send_message(m.chat.id, f"✅ تم إنشاء كود اشتراك VIP\n\n🔑 <code>{code}</code>\n⏳ المدة: {days} يوم\n👥 الاستخدامات: {uses}", parse_mode="HTML")


@bot.message_handler(
    func=lambda m: m.chat.type == "private" and USERS.get(m.chat.id, {}).get("await_code"),
    content_types=["text"])
def on_code_input(m):
    cid = m.chat.id
    USERS[cid].pop("await_code", None)
    if not user_gate(cid):
        return
    _ok, text = redeem_code(cid, m.text)
    bot.send_message(cid, text, parse_mode="HTML")


# ---------------- الإحالات + إشعار الانضمام ----------------
def _capture_ref(msg):
    try:
        parts = (msg.text or "").split()
        if len(parts) > 1 and parts[1].startswith("ref_") and parts[1][4:].isdigit():
            PENDING_REF[msg.chat.id] = int(parts[1][4:])
    except Exception:
        pass


def on_new_user(msg):
    cid = msg.chat.id
    name = msg.chat.first_name or ""
    log_event("join", cid, name)
    if _s("notify_new"):
        try:
            uname = f"@{_esc(msg.chat.username)}" if getattr(msg.chat, "username", None) else "—"
            _owners_send(f"🆕 مستخدم جديد: <b>{_esc(name)}</b> {uname}\n"
                                       f"🆔 <code>{cid}</code> • الإجمالي: <b>{len(DB['users'])}</b>",
                             parse_mode="HTML")
        except Exception:
            pass
    ref = PENDING_REF.pop(cid, None)
    if (ref and _s("referral") and ref != cid and ref in DB["users"]
            and str(cid) not in DB["referred"]):
        reward = int(_s("referral_reward", 1))
        with DB_LOCK:
            DB["referred"][str(cid)] = ref
            DB["refs"][str(ref)] = DB["refs"].get(str(ref), 0) + 1
            cr = DB["credits"].get(str(ref))
            if reward > 0 and cr != "max" and not is_admin(ref):
                DB["credits"][str(ref)] = (cr if isinstance(cr, int) else 0) + reward
            save_db(DB)
        log_event("referral", ref, f"دعا {cid}")
        try:
            extra = f" واتضاف لك <b>{reward}</b> فرصة 🎁" if reward > 0 else ""
            bot.send_message(ref, f"🎉 صديقك <b>{_esc(name)}</b> انضم عن طريق رابطك{extra}", parse_mode="HTML")
        except Exception:
            pass


def invite_text(cid):
    reward = int(_s("referral_reward", 1))
    link = f"https://t.me/{_bot_username()}?start=ref_{cid}"
    n = DB["refs"].get(str(cid), 0)
    return (f"🎁 <b>ادعُ صديق</b>\n\nلكل صديق ينضم من رابطك "
            f"هتاخد <b>{reward}</b> فرصة.\n\n🔗 رابطك:\n<code>{link}</code>\n\n"
            f"👥 دعوت لحد دلوقتي: <b>{n}</b>")


def account_card(cid):
    k = str(cid)
    return (f"👤 <b>حسابي</b>\n\n🆔 <code>{cid}</code>\n{plan_text(cid)}\n"
            f"👥 أصدقاء دعيتهم: <b>{DB['refs'].get(k, 0)}</b>")


def get_main_keyboard(chat_id):
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(_b("🔵 الصف الأول الثانوي — JavaScript (42 فصل)", "grade_1", style="primary"))
    markup.add(_b("🟢 الصف الثاني الثانوي", "grade_2", style="success"))
    markup.row(_b("👤 حسابي", "me"), _b("🎟 تفعيل كود", "redeem"))
    if _s("referral"):
        markup.row(_b("🎁 ادعُ صديق", "invite", style="success"))
    return markup


# ---------------- تقرير فشل الدخول ----------------
def _login_fail_text(code):
    hint = ""
    if code in (400, 401):
        hint = "\nتأكد من كود الطالب وكلمة المرور (من غير مسافات) وجرّب تدخل بيهم من موقع المنصة الأول."
    elif code == 403:
        hint = "\nالموقع رافض الاتصال حاليًا، جرّب بعد شوية."
    elif code == 429:
        hint = "\nطلبات كتير، استنى دقيقتين وجرّب تاني."
    return f"❌ <b>فشل الدخول! رد السيرفر: {code}.</b>{hint}"


def _login_fail_report(cid, platform, r):
    log_event("login_fail", cid, f"{platform} → {r.status_code}")
    now = time.time()
    if now - _LOGIN_REPORTED.get(cid, 0) < 600 or is_admin(cid):
        return
    _LOGIN_REPORTED[cid] = now
    try:
        body = _esc((getattr(r, "text", "") or "")[:200])
        _owners_send(f"🔑 فشل دخول — المستخدم <code>{cid}</code>\nالمنصة: {_esc(platform)} • الكود: "
                                   f"<b>{r.status_code}</b>\nرد السيرفر:\n<code>{body}</code>", parse_mode="HTML")
    except Exception:
        pass


# ---------------- نسخ احتياطي تلقائي ----------------
def _send_backup(chat, caption):
    with DB_LOCK:
        save_db(DB)
        tmp = f"backup_{int(time.time())}.json"
        with open(USERS_FILE, "rb") as src, open(tmp, "wb") as dst:
            dst.write(src.read())
    try:
        with open(tmp, "rb") as f:
            bot.send_document(chat, f, caption=caption)
    finally:
        try:
            os.remove(tmp)
        except Exception:
            pass


def _backup_tick():
    if not _s("auto_backup", True):
        return False
    if time.time() - int(_s("last_backup", 0)) < 86400:
        return False
    DB["settings"]["last_backup"] = int(time.time())
    save_db(DB)
    for _o in OWNER_IDS:
        try:
            _send_backup(_o, "💾 نسخة احتياطية تلقائية • " + _ts(int(time.time())))
        except Exception as _e:
            print("backup send:", _e)
    return True


def _backup_loop():
    while True:
        time.sleep(600)
        try:
            _backup_tick()
        except Exception as e:
            print("backup loop:", e)


def start_background():
    threading.Thread(target=_backup_loop, daemon=True).start()


# ---------------- صفحات اللوحة (بتحل محل القديمة) ----------------
def ap_home_kb(uid):
    rows = [
        [_b("📊 الإحصائيات", "adm:stats"), _b("👥 المستخدمين", "adm:users:a:0")],
        [_b("📢 إذاعة", "adm:bc", style="primary"), _b("🎟 الأكواد", "adm:codes", style="success")],
        [_b("🎁 العروض", "adm:offers"), _b("📜 السجل", "adm:log")],
        [_b("🩺 فحص النظام", "adm:health"), _b("⚙️ الإعدادات", "adm:set")],
    ]
    last = [_b("💾 نسخة", "adm:backup"), _b("📤 تصدير", "adm:export")]
    if is_owner(uid):
        last.insert(0, _b("🛡 الأدمنز", "adm:admins"))
    rows.append(last)
    rows.append([_b("إغلاق", "adm:close", style="danger")])
    return _kb(*rows)


def ap_home_text():
    st = DB["settings"]
    running = sum(1 for u in USERS.values() if u.get("running"))
    unused = sum(1 for v in DB["codes"].values() if not v.get("used_by"))
    return (f"🎛 <b>لوحة التحكم</b>\n\n"
            f"👥 المستخدمين: <b>{len(DB['users'])}</b>   ⚡ شغال دلوقتي: <b>{running}</b>\n"
            f"🎟 أكواد متاحة: <b>{unused}</b>\n"
            f"📢 الاشتراك الإجباري: {'🟢' if st.get('force_sub', True) else '🔴'}   "
            f"🛠 الصيانة: {'🟢' if st.get('maintenance') else '🔴'}\n"
            f"🕐 {datetime.now(_TZ).strftime('%Y-%m-%d %H:%M')}\n\nاختار قسم:")


_old_ap_stats = ap_stats


def _growth_chart():
    now = datetime.now(_TZ)
    counts = []
    for i in range(6, -1, -1):
        day = (now - timedelta(days=i)).replace(hour=0, minute=0, second=0, microsecond=0)
        a = int(day.timestamp())
        n = sum(1 for v in DB["info"].values() if a <= v.get("joined", 0) < a + 86400)
        counts.append((day.strftime("%m-%d"), n))
    mx = max([n for _, n in counts] or [1]) or 1
    lines = ["📈 <b>الجداد آخر 7 أيام</b>"]
    for d, n in counts:
        lines.append(f"<code>{d}</code> {'▇' * (max(1, int(8 * n / mx)) if n else 0)} {n}")
    return "\n".join(lines)


def ap_stats():
    text, kb = _old_ap_stats()
    refs = sum(DB["refs"].values()) if DB["refs"] else 0
    used = sum(1 for v in DB["codes"].values() if v.get("used_by"))
    return text + f"\n\n🎟 أكواد اتفعّلت: <b>{used}</b> • 👥 إحالات: <b>{refs}</b>\n\n" + _growth_chart(), kb


def ap_settings():
    st = DB["settings"]
    on = lambda v: "🟢 شغال" if v else "🔴 مقفول"
    sty = lambda v: "success" if v else "danger"
    text = (
        "⚙️ <b>الإعدادات</b>\n\n"
        f"📢 قناة الاشتراك: <code>{_esc(st.get('channel'))}</code>\n"
        f"📢 الاشتراك الإجباري (على كل الأزرار): {on(st.get('force_sub', True))}\n"
        f"🛠 وضع الصيانة: {on(st.get('maintenance'))}\n\n"
        f"⚡ أقصى عمليات متزامنة: <b>{st.get('max_running', 25)}</b>\n"
        f"🔔 إشعار مستخدم جديد: {on(st.get('notify_new'))}\n"
        f"💾 نسخ احتياطي يومي للمالك: {on(st.get('auto_backup', True))}\n"
        f"🎨 الأزرار الملونة الأصلية: {on(st.get('native_colors', True))}\n\n"
        "<i>أي تغيير بيتطبق فورًا بدون إعادة تشغيل.</i>"
    )
    return text, _kb(
        [_b("الاشتراك الإجباري", "adm:tog:force_sub", style=sty(st.get("force_sub", True))),
         _b("الصيانة", "adm:tog:maintenance", style="danger" if st.get("maintenance") else "success")],
        [_b("➖ 5", "adm:num2:max_running:-5"),
         _b(f"⚡ {st.get('max_running', 25)} متزامنة", "adm:noop"),
         _b("➕ 5", "adm:num2:max_running:5")],
        [_b("إشعار الجداد", "adm:tog2:notify_new", style=sty(st.get("notify_new"))),
         _b("نسخ يومي", "adm:tog2:auto_backup", style=sty(st.get("auto_backup", True)))],
        [_b("✏️ تغيير القناة", "adm:chan"), _b("✏️ رسالة الشراء", "adm:ask_buy")],
        [_b("الأزرار الملونة الأصلية", "adm:tog:native_colors", style=sty(st.get("native_colors", True)))],
        _back())


def ap_codes():
    unused = [c for c, v in DB["codes"].items() if not v.get("used_by")]
    used = len(DB["codes"]) - len(unused)
    text = (f"🎟 <b>أكواد التفعيل</b>\n\nمتاحة: <b>{len(unused)}</b> • اتفعّلت: <b>{used}</b>\n\n"
            "اختار نوع الكود (×1 أو ×10) — المستخدم يكتب الكود في زر 🎟 تفعيل كود أو /redeem:")
    keys = []
    for k, label, _t, _v in CODE_TYPES:
        keys.append([_b(f"{label} ×1", f"adm:cgen:{k}:1", style="success"),
                     _b(f"{label} ×10", f"adm:cgen:{k}:10", style="primary")])
    keys.append([_b("📋 الأكواد المتاحة", "adm:clist"), _b("حذف المستخدمة", "adm:cdel_used", style="danger")])
    keys.append(_back())
    return text, _kb(*keys)


def ap_offers():
    st = DB["settings"]
    on = lambda v: "🟢 شغال" if v else "🔴 مقفول"
    text = (
        "🎁 <b>العروض</b>\n\n"
        f"👥 نظام الإحالات: {on(st.get('referral'))}\n"
        f"🎁 مكافأة كل دعوة: <b>{st.get('referral_reward', 1)}</b> فرصة\n"
        f"إجمالي الإحالات: <b>{sum(DB['refs'].values()) if DB['refs'] else 0}</b>\n\n"
        "🎉 <b>منح فرص للجميع</b> (للمستخدمين النشطين غير المحظورين):"
    )
    return text, _kb(
        [_b("نظام الإحالات", "adm:tog2:referral", style="success" if st.get("referral") else "danger")],
        [_b("➖", "adm:num2:referral_reward:-1"),
         _b(f"🎁 {st.get('referral_reward', 1)} فرصة/دعوة", "adm:noop"),
         _b("➕", "adm:num2:referral_reward:1")],
        [_b("+1 للكل", "adm:gift:1", style="primary"), _b("+3 للكل", "adm:gift:3", style="primary"),
         _b("+5 للكل", "adm:gift:5", style="primary")],
        _back())


_EVENT_ICON = {"join": "🆕", "solve": "✅", "error": "⚠️", "login_fail": "🔑",
               "redeem": "🎟", "admin": "🛠", "referral": "👥", "gift": "🎁"}


def ap_log():
    rows = DB["log"][-15:][::-1]
    if not rows:
        text = "📜 <b>السجل</b>\n\nمفيش أحداث لسه."
    else:
        lines = ["📜 <b>آخر الأحداث</b>\n"]
        for e in rows:
            t = datetime.fromtimestamp(e["t"], _TZ).strftime("%m-%d %H:%M")
            lines.append(f"{_EVENT_ICON.get(e['k'], '•')} <code>{t}</code> {_esc(e.get('u'))} {_esc(e.get('x'))}")
        text = "\n".join(lines)
    return text, _kb([_b("🔄 تحديث", "adm:log")], _back())


def ap_health():
    lines = ["🩺 <b>فحص النظام</b>\n"]

    def probe(name, url):
        t = time.time()
        try:
            r = make_session().get(url, timeout=8)
            lines.append(f"🟢 {name}: {r.status_code} ({int((time.time() - t) * 1000)}ms)")
        except Exception as e:
            lines.append(f"🔴 {name}: <code>{_esc(type(e).__name__)}: {_esc(str(e)[:110])}</code>")

    probe("Qureo Portal", QUREO_PORTAL)
    probe("Qureo API", QUREO_BASE)
    probe("SPX", BASE)
    lines.append("🟢 فحص القناة: متوقف (الاشتراك الإجباري ملغي)")
    missing = [f for f in ("max.json", "javascript_final_db.json", "study_data.json", "answers_by_level.json")
               if not os.path.exists(f)]
    lines.append("🟢 ملفات الأسئلة كاملة" if not missing else "🔴 ملفات ناقصة: " + ", ".join(missing))
    running = sum(1 for u in USERS.values() if u.get("running"))
    lines.append(f"\n⚡ عمليات شغالة: <b>{running}</b> / {DB['settings'].get('max_running', 25)}")
    lines.append(f"👥 مستخدمين: <b>{len(DB['users'])}</b> • 🧵 خيوط: <b>{threading.active_count()}</b>")
    lines.append(f"🐍 Python {sys.version.split()[0]}")
    return "\n".join(lines), _kb([_b("🔄 إعادة الفحص", "adm:health")], _back())


def _export_users():
    path = f"users_export_{int(time.time())}.csv"
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["id", "name", "username", "joined", "last_seen", "credits", "vip_until",
                    "trial_used", "banned", "blocked", "referrals"])
        for uid in DB["users"]:
            k = str(uid)
            i = DB["info"].get(k, {})
            w.writerow([uid, i.get("name", ""), i.get("username", ""), _ts(i.get("joined")),
                        _ts(i.get("last_seen")), DB["credits"].get(k, ""), _ts(DB["vip_until"].get(k)) if k in DB["vip_until"] else "",
                        DB["trial_used"].get(k, 0), int(bool(DB["banned"].get(k))), int(k in DB["blocked"]),
                        DB["refs"].get(k, 0)])
    return path


AP_EXTRA = {"health", "export", "log", "codes", "cgen", "clist", "cdel_used",
            "offers", "gift", "gift_go", "tog2", "num2"}


def ap_extra_cb(c, act, a, uid, chat, mid):
    answer, alert = "", False
    try:
        if act == "health":
            _show(chat, mid, "🩺 جاري الفحص... (لحد 25 ثانية)", _kb(_back()))
            _show(chat, mid, *ap_health())
        elif act == "log":
            _show(chat, mid, *ap_log())
        elif act == "export":
            path = _export_users()
            try:
                with open(path, "rb") as f:
                    bot.send_document(chat, f, caption=f"📤 {len(DB['users'])} مستخدم")
            finally:
                os.remove(path)
            answer = "اتبعت ✅"
        elif act == "codes":
            _show(chat, mid, *ap_codes())
        elif act == "cgen":
            key, n = a[0], max(1, min(50, int(a[1])))
            spec = [t for t in CODE_TYPES if t[0] == key][0]
            made = []
            with DB_LOCK:
                while len(made) < n:
                    code = "QR-" + secrets.token_hex(3).upper() + "-" + secrets.token_hex(3).upper()
                    if code in DB["codes"]:
                        continue
                    DB["codes"][code] = {"type": spec[2], "value": spec[3], "created": int(time.time()),
                                         "used_by": None, "used_at": None}
                    made.append(code)
                save_db(DB)
            log_event("admin", uid, f"cgen {spec[1]} x{n}")
            body = "\n".join(f"<code>{x}</code>" for x in made)
            _show(chat, mid, f"✅ تم إنشاء <b>{n}</b> كود ({spec[1]}):\n\n{body}\n\n<i>اضغط على الكود لنسخه.</i>",
                  _kb([_b("➕ كمان", "adm:codes", style="success")], _back()))
        elif act == "clist":
            rows = [(c_, v) for c_, v in DB["codes"].items() if not v.get("used_by")][-40:]
            body = "\n".join(f"<code>{c_}</code> — {_code_label(v)}" for c_, v in rows) or "مفيش أكواد متاحة."
            _show(chat, mid, f"📋 <b>الأكواد المتاحة</b> (آخر {len(rows)}):\n\n{body}",
                  _kb([_b("🔙 الأكواد", "adm:codes")]))
        elif act == "cdel_used":
            with DB_LOCK:
                for c_ in [c_ for c_, v in DB["codes"].items() if v.get("used_by")]:
                    del DB["codes"][c_]
                save_db(DB)
            answer = "اتحذفت الأكواد المستخدمة"
            _show(chat, mid, *ap_codes())
        elif act == "offers":
            _show(chat, mid, *ap_offers())
        elif act == "tog2":
            key = a[0]
            if key in ("referral", "notify_new", "auto_backup"):
                cur = DB["settings"].get(key, key == "auto_backup")
                DB["settings"][key] = not cur
                save_db(DB)
            _show(chat, mid, *(ap_offers() if a[0] == "referral" else ap_settings()))
        elif act == "num2":
            key, d = a[0], int(a[1])
            lim = {"max_running": (5, 200, 25), "referral_reward": (0, 5, 1)}.get(key)
            if lim:
                DB["settings"][key] = max(lim[0], min(lim[1], int(DB["settings"].get(key, lim[2])) + d))
                save_db(DB)
            _show(chat, mid, *(ap_offers() if key == "referral_reward" else ap_settings()))
        elif act == "gift":
            n = int(a[0])
            cnt = len([u for u in DB["users"] if not DB["banned"].get(str(u)) and str(u) not in DB["blocked"]
                       and DB["credits"].get(str(u)) != "max"])
            _show(chat, mid, f"🎁 هتمنح <b>{n}</b> فرصة لـ <b>{cnt}</b> مستخدم.\n"
                             "⚠️ الفرصة المدفوعة بتحل المادة كاملة. متأكد؟",
                  _kb([_b("تأكيد", f"adm:gift_go:{n}", style="success"), _b("إلغاء", "adm:offers", style="danger")]))
        elif act == "gift_go":
            n = max(1, min(10, int(a[0])))
            done = 0
            with DB_LOCK:
                for u in DB["users"]:
                    k = str(u)
                    cr = DB["credits"].get(k)
                    if DB["banned"].get(k) or k in DB["blocked"] or cr == "max":
                        continue
                    DB["credits"][k] = (cr if isinstance(cr, int) else 0) + n
                    done += 1
                save_db(DB)
            log_event("gift", uid, f"+{n} لـ {done} مستخدم")
            answer = f"🎁 اتمنح {done} مستخدم"
            _show(chat, mid, *ap_offers())
    except Exception as e:
        answer, alert = "⚠️ حصل خطأ: " + str(e)[:150], True
    try:
        bot.answer_callback_query(c.id, answer, show_alert=alert)
    except Exception:
        pass


# ==========================================
# 🧯 تشغيل آمن للحل: أي خطأ بيتعرض بدل ما يفضل "جاري تسجيل الدخول" للأبد
# ==========================================
def _safe_run(fn, cid, message_id, *args):
    try:
        fn(cid, message_id, *args)
    except Exception as e:
        err = f"{type(e).__name__}: {e}"
        print("RUN ERROR:", err)
        log_event("error", cid, err[:100])
        try:
            bot.edit_message_text(f"❌ <b>حصل خطأ أثناء الحل:</b>\n<code>{html.escape(err[:300])}</code>",
                                  cid, message_id, parse_mode="HTML")
        except Exception:
            pass
        try:
            _owners_send(f"⚠️ خطأ في الحل للمستخدم <code>{cid}</code>:\n<code>{html.escape(err[:500])}</code>",
                             parse_mode="HTML")
        except Exception:
            pass
    finally:
        try:
            USERS[cid]["running"] = False
        except Exception:
            pass


# ==========================================
# 🧠 تشغيل كل مواد الصف الثاني بالتتابع
# ==========================================
def run_code_tool(cid_tg, message_id, student_id, password):
    run_qureo_tool(cid_tg, message_id, student_id, password, "javascript_ar", "javascript_final_db.json", "JavaScript")
    if USERS.get(cid_tg, {}).get("running"):
        run_qureo_tool(cid_tg, message_id, student_id, password, "python_short_ar", "max.json", "Python")


def run_all_tool(cid_tg, message_id, student_id, password):
    run_qureo_tool(cid_tg, message_id, student_id, password, "javascript_ar", "javascript_final_db.json", "JavaScript")
    if USERS.get(cid_tg, {}).get("running"):
        run_qureo_tool(cid_tg, message_id, student_id, password, "python_short_ar", "max.json", "Python")
    if USERS.get(cid_tg, {}).get("running"):
        run_spx_tool(cid_tg, message_id, student_id, password)


# ==========================================
# 🧠 استقبال الأزرار
# ==========================================
def _send_selection_prompt(cid, text, markup=None):
    """يرسل prompt مستقل؛ يعمل سواء كانت رسالة القائمة نصاً أو صورة."""
    return bot.send_message(cid, text, reply_markup=markup, parse_mode="HTML")


@bot.callback_query_handler(func=lambda c: not (c.data or "").startswith("adm:"))
def cb(call):
    cid = call.message.chat.id
    track_user(call.message.chat)
    if not user_gate(cid, call):          # حظر / صيانة / اشتراك القناة — على كل زر
        return
    _now = time.time()                    # ضد الضغط المتكرر (سبام)
    if not is_admin(cid) and _now - _LAST_CB.get(cid, 0) < CB_MIN_GAP:
        try: bot.answer_callback_query(call.id)
        except Exception: pass
        return
    _LAST_CB[cid] = _now
    if cid not in USERS: USERS[cid] = {"running": False}

    if call.data == "start_grades":
        bot.answer_callback_query(call.id)
        _send_selection_prompt(cid, "🎓 اختر الصف الدراسي:", get_grade_keyboard())
        return

    if call.data == "grade_1":
        USERS[cid]["grade"] = "grade_1"
        USERS[cid]["platform"] = "js"
        USERS[cid].pop("login_id", None)
        USERS[cid].pop("password", None)
        USERS[cid]["awaiting_login_id"] = True
        USERS[cid]["awaiting_password"] = False
        bot.answer_callback_query(call.id, "تم اختيار أولى ثانوي")
        _send_selection_prompt(cid, "✅ أولى ثانوي — JavaScript فقط (42 فصل)\n\n📝 أرسل كود الطالب:")
        return

    if call.data == "grade_2":
        USERS[cid]["grade"] = "grade_2"
        USERS[cid].pop("login_id", None)
        USERS[cid].pop("password", None)
        USERS[cid].pop("awaiting_login_id", None)
        USERS[cid].pop("awaiting_password", None)
        bot.answer_callback_query(call.id, "تم اختيار ثانية ثانوي")
        _send_selection_prompt(cid, "✅ ثانية ثانوي\n\nاختر المواد التي تريد حلها:", get_subject_keyboard())
        return

    if call.data == "sel_code":
        USERS[cid]["platform"] = "all_code"
        USERS[cid].pop("login_id", None)
        USERS[cid].pop("password", None)
        USERS[cid]["awaiting_login_id"] = True
        USERS[cid]["awaiting_password"] = False
        bot.answer_callback_query(call.id)
        _send_selection_prompt(cid, "✅ JavaScript + Python\n\n📝 أرسل كود الطالب:")
        return

    if call.data == "sel_all":
        USERS[cid]["platform"] = "all"
        USERS[cid].pop("login_id", None)
        USERS[cid].pop("password", None)
        USERS[cid]["awaiting_login_id"] = True
        USERS[cid]["awaiting_password"] = False
        bot.answer_callback_query(call.id)
        _send_selection_prompt(cid, "✅ تم اختيار كل المواد\n\n📝 أرسل كود الطالب:")
        return

    # خلص رصيده؟ نوقفه من أول اختيار منصة قبل ما يكتب بياناته
    if call.data in ("sel_js", "sel_python", "sel_spx") and user_plan(cid)[0] == "none":
        bot.answer_callback_query(call.id)
        show_buy(cid, call.message.message_id)
        return
    
    if call.data == "sel_js":
        USERS[cid]['platform'] = 'js'
        USERS[cid].pop("login_id", None); USERS[cid].pop("password", None)
        USERS[cid]["awaiting_login_id"] = True; USERS[cid]["awaiting_password"] = False
        _send_selection_prompt(cid, "✅ اخترت <b>JavaScript</b>\n\n📝 أرسل كود الطالب:")
    elif call.data == "sel_python":
        USERS[cid]['platform'] = 'python'
        USERS[cid].pop("login_id", None); USERS[cid].pop("password", None)
        USERS[cid]["awaiting_login_id"] = True; USERS[cid]["awaiting_password"] = False
        _send_selection_prompt(cid, "✅ اخترت <b>Python</b>\n\n📝 أرسل كود الطالب:")
    elif call.data == "sel_spx":
        USERS[cid]['platform'] = 'spx'
        USERS[cid].pop("login_id", None); USERS[cid].pop("password", None)
        USERS[cid]["awaiting_login_id"] = True; USERS[cid]["awaiting_password"] = False
        _send_selection_prompt(cid, "✅ اخترت <b>الثقافة المالية</b>\n\n📝 أرسل كود الطالب:")
        
    elif call.data == "start_solve":
        plan, _x = user_plan(cid)
        if plan == "none":
            bot.answer_callback_query(call.id)
            show_buy(cid, call.message.message_id)
            return
        if USERS.get(cid, {}).get("running"):
            bot.answer_callback_query(call.id, "⏳ في عملية شغالة بالفعل", show_alert=True)
            return
        _busy = sum(1 for u in USERS.values() if u.get("running"))
        if not is_admin(cid) and _busy >= int(DB["settings"].get("max_running", 25)):
            bot.answer_callback_query(call.id, f"⏳ السيرفر مشغول دلوقتي ({_busy} عملية شغالة). جرّب بعد دقايق.", show_alert=True)
            return

        if "login_id" in USERS.get(cid, {}) and "password" in USERS.get(cid, {}):
            USERS[cid]["running"] = True
            bot.answer_callback_query(call.id, "🚀 بدأ الحل!")
            msg_id = call.message.message_id
            platform = USERS[cid].get('platform')
            
            if platform == 'all':
                threading.Thread(target=_safe_run, args=(run_all_tool, cid, msg_id, USERS[cid]['login_id'], USERS[cid]['password'])).start()
            elif platform == 'all_code':
                threading.Thread(target=_safe_run, args=(run_code_tool, cid, msg_id, USERS[cid]['login_id'], USERS[cid]['password'])).start()
            elif platform == 'spx':
                threading.Thread(target=_safe_run, args=(run_spx_tool, cid, msg_id, USERS[cid]['login_id'], USERS[cid]['password'])).start()
            elif platform == 'js':
                js_limit = 42 if USERS[cid].get('grade') == 'grade_1' else None
                threading.Thread(target=_safe_run, args=(run_qureo_tool, cid, msg_id, USERS[cid]['login_id'], USERS[cid]['password'], "javascript_ar", "javascript_final_db.json", "JavaScript", js_limit)).start()
            elif platform == 'python':
                threading.Thread(target=_safe_run, args=(run_qureo_tool, cid, msg_id, USERS[cid]['login_id'], USERS[cid]['password'], "python_short_ar", "max.json", "Python")).start()
        else:
            bot.answer_callback_query(call.id, "⚠️ البيانات ناقصة.", show_alert=True)

    elif call.data == "me":
        bot.answer_callback_query(call.id)
        bot.send_message(cid, account_card(cid), parse_mode="HTML")

    elif call.data == "redeem":
        bot.answer_callback_query(call.id)
        USERS.setdefault(cid, {"running": False})["await_code"] = True
        bot.send_message(cid, "🎟 ابعت كود التفعيل دلوقتي:")

    elif call.data == "invite":
        bot.answer_callback_query(call.id)
        if DB["settings"].get("referral"):
            bot.send_message(cid, invite_text(cid), parse_mode="HTML", disable_web_page_preview=True)

    elif call.data == "my_stats":
        bot.answer_callback_query(call.id, plan_text(cid), show_alert=True)

# ==========================================
# 🆔 استقبال الكود والباسورد
# ==========================================
@bot.message_handler(func=lambda msg: (
    msg.chat.type == "private" and msg.chat.id in USERS
    and USERS[msg.chat.id].get("awaiting_login_id") is True
    and "platform" in USERS[msg.chat.id]
))
def step_id(msg):
    cid = msg.chat.id
    if not user_gate(cid):
        return
    USERS[cid]['login_id'] = (msg.text or "").strip()
    USERS[cid]['awaiting_login_id'] = False
    USERS[cid]['awaiting_password'] = True
    m = bot.send_message(cid, "🔑 أرسل كلمة المرور:")
    bot.register_next_step_handler(m, step_pass)

def step_pass(msg):
    cid = msg.chat.id
    if cid not in USERS or USERS[cid].get("awaiting_password") is not True:
        bot.send_message(cid, "اختار الصف والمادة من /start أولاً.")
        return
    pw = msg.text.strip()
    if not user_gate(cid):
        return
    try: bot.delete_message(cid, msg.message_id)
    except: pass
    if cid not in USERS or 'platform' not in USERS[cid]:
        bot.send_message(cid, "⚠️ الجلسة انتهت، يرجى إرسال /start من جديد.")
        return
    USERS[cid]['password'] = pw
    USERS[cid]['awaiting_password'] = False
    
    plan, _x = user_plan(cid)
    if plan == "none":
        show_buy(cid)
        return

    note = ""
    markup = types.InlineKeyboardMarkup().add(_b("🚀 بدء الحل التلقائي", "start_solve", style="success"))
    bot.send_message(cid, "✅ <b>تم حفظ البيانات!</b>\n\nاضغط لبدء الحل." + note, reply_markup=markup, parse_mode="HTML")


@bot.message_handler(func=lambda msg: (
    msg.chat.type == "private" and bool((msg.text or "").strip())
    and not (msg.text or "").lstrip().startswith("/")
    and not USERS.get(msg.chat.id, {}).get("awaiting_login_id")
    and not USERS.get(msg.chat.id, {}).get("awaiting_password")
    and not USERS.get(msg.chat.id, {}).get("await_code")
))
def reject_unselected_credentials(msg):
    bot.send_message(msg.chat.id, "اختار الصف والمادة من /start أولاً.")

# ==========================================
# 🚀 تشغيل البوت
# ==========================================
def startup_report():
    """بعد التشغيل: فحص الاتصالات الخارجية فقط، وبيبعت الملخص للمالك."""
    lines = [f"✅ <b>{BOT_NAME} اشتغل</b> — " + ("عبر بروكسي" if BOT_PROXY else "اتصال مباشر بدون بروكسي")]
    if not BOT_PROXY and (SITE_PROXY or _pool_urls()):
        lines.append(f"🌐 بروكسي المواقع: متاح ({len(_pool_urls()) or 1} بروكسي) — بيتجرب تلقائي مع Qureo/SPX")
    try:
        me = bot.get_me()
        lines.append(f"🤖 @{me.username}")
        lines.append("🟢 فحص الاشتراك الإجباري: متوقف")
    except Exception as e:
        lines.append(f"🔴 get_me: <code>{_esc(str(e)[:90])}</code>")
    for name, url in (("Qureo", QUREO_PORTAL), ("SPX", BASE)):
        t = time.time()
        try:
            r = make_session().get(url, timeout=8)
            lines.append(f"🟢 {name}: {r.status_code} ({int((time.time() - t) * 1000)}ms)")
        except Exception as e:
            lines.append(f"🔴 {name}: <code>{_esc(type(e).__name__)}</code>")
    _owners_send("\n".join(lines), parse_mode="HTML")


def wait_for_telegram():
    """بيتأكد إن التوكن سليم والاتصال بتيليجرام شغال (بيعيد المحاولة بدل ما يقع)."""
    delay = 3
    while True:
        try:
            me = bot.get_me()
            print(f"🤖 متصل كـ @{me.username}")
            return
        except Exception as e:
            if "401" in str(e) or "Unauthorized" in str(e):
                print("❌ التوكن غلط أو اتلغى — راجع BOT_TOKEN.")
                raise SystemExit(1)
            print(f"⚠️ مش قادر يوصل لتيليجرام ({type(e).__name__}) — إعادة محاولة بعد {delay}ث. "
                  "لو الاستضافة بتفرض بروكسي حط BOT_PROXY.")
            time.sleep(delay)
            delay = min(delay * 2, 60)


if __name__ == "__main__":
    print(f"👑 {BOT_NAME} (JS + Python + SPX) Started...")
    wait_for_telegram()
    start_background()
    threading.Thread(target=startup_report, daemon=True).start()
    while True:
        try:
            bot.infinity_polling(timeout=60, long_polling_timeout=60)
        except Exception as e:
            print(f"⚠️ انقطع الاتصال: {e}")
            time.sleep(5)
