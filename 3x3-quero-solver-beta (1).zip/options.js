const $ = id => document.getElementById(id);
chrome.storage.sync.get(["apiKey"], v => { $("key").value = v.apiKey || ""; });
$("save").onclick = () => chrome.storage.sync.set(
  { apiKey: $("key").value.trim() },
  () => { $("msg").textContent = "تم الحفظ ✓"; }
);
