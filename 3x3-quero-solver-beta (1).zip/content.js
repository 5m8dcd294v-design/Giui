(() => {
  const IS_TOP = window === window.top;
  const EXPIRY_TS = Date.parse("2026-11-23T00:00:00Z");
  const isExpired = () => Date.now() >= EXPIRY_TS;
  const FIELD_SEL = 'input[type=text], input[type=number], input[type=email], input:not([type]), textarea, select';
  const EDITOR_SEL = ".ace_editor, .monaco-editor, .CodeMirror, .cm-editor, .ace_content, .cm-content, .view-lines";
  const FEEDBACK_SEL = '[class*=console i],[class*=output i],[class*=result i],[class*=feedback i],[class*=message i],[class*=toast i],[class*=modal i],[role=alert],[role=dialog]';
  const MODAL_SEL = '[role=dialog],[class*=modal i],[class*=popup i],[class*=dialog i]';
  const RUN_RE = /^\s*(run( code)?|execute|تشغيل( الكود)?)\s*[▶►◀◄▷◁<>]?\s*$/i;
  const REVEAL_RE = /^\s*(show|view|see|reveal|display|check)\s+(the\s+)?(correct\s+|model\s+|sample\s+)?(answer|solution|code)s?\s*$|^\s*(model |sample )?(answer|solution)s?\s*$|(عرض|إظهار|اظهار|أظهر|اعرض)\s*(ال)?(إجابة|اجابة|حل|الحل|الإجابة|الاجابة)|^\s*(الإجابة|الاجابة|الحل|الإجابة الصحيحة|الاجابة الصحيحة)\s*$/i;
  const CLOSE_RE = /^\s*(close|ok|okay|done|got it|x|×|✕|✖|إغلاق|اغلاق|حسنا|تم|موافق)\s*$/i;
  const NAV_RE = /^\s*(next|submit|check|answer|ok|close|hint|hints|back|skip|continue|retry|reset|clear|undo|home|menu|login|log in|sign in|save|cancel|view hints.*|التالي|إرسال|ارسال|تلميح|تلميحات|رجوع|تخطي|متابعة|إعادة|حفظ|إلغاء)\s*[▶►◀◄>]?\s*$/i;
  const CHOICE_CLASS = /choice|option|answer|alternative|radio|checkbox|quiz-?item|mcq/i;
  const ED_BASE = ".ace_editor, .monaco-editor, .CodeMirror, .cm-editor";
  const LANG_RE = /^(html|css|javascript|js|typescript|ts|scss|sass|less|json|xml|php|python|py|sql|java|jsx|tsx)$/i;
  const ANSWER_RE = /^\s*(إجابة|اجابة|الإجابة|الاجابة|إرسال|ارسال|تأكيد|submit|check|check answer|answer)\s*[▶►◀◄>]?\s*$/i;
  const NEXT_RE = /^\s*(السؤال التالي|التالي|next( question)?|continue|متابعة)\s*[▶►◀◄>]?\s*$/i;

  let running = false, busy = false, debounce = null, observer = null, lastCodeSig = null, poll = null;
  const solvedSigs = new Set();
  const pathCount = new Map();
  const tplSeen = new Set();
  const pageProcessed = new Map();
  const doneLogged = new Set();
  const scanned = new Set();
  const skipSeen = new Map();
  let curEl = null, curEid = null, curIdx = 0;
  let persistTimer = null;
  const persistSolved = () => {
    clearTimeout(persistTimer);
    persistTimer = setTimeout(() => chrome.storage.local.set({ esolved: [...solvedSigs].slice(-300) }), 300);
  };
  chrome.storage.local.get(["esolved"], v => (v.esolved || []).forEach(x => solvedSigs.add(x)));
  let refreshUI = () => {};

  const hash = s => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return String(h); };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function setStatus(text, stat, n) {
    try {
      const k = text.startsWith("⚠") ? "err" : (text.includes("✓") ? "ok" : "info");
      chrome.storage.local.set({ estatus: { t: (IS_TOP ? "" : "[frame] ") + text, k, stat: stat || null, n: n || 0, ts: Date.now() } });
    } catch (e) {}
  }
  const failStop = msg => {
    chrome.storage.local.set({ running: false });
    setTimeout(() => setStatus("⚠ " + msg), 500);
  };

  async function ask(type, payload, soft) {
    const timeout = new Promise(r => setTimeout(() => r({ ok: false, msg: "محدش رد خلال 60 ثانية، ممكن يكون في اتصال بطيء" }), 60000));
    const res = await Promise.race([chrome.runtime.sendMessage({ type, ...payload }), timeout]);
    if (!res || !res.ok) {
      if (soft) return null;
      failStop((res && res.msg) || "مفيش رد");
      const e = new Error("handled"); e.handled = true; throw e;
    }
    return res;
  }

  // ================= أدوات عامة =================
  function elVisible(e) {
    if (!e || !e.isConnected) return false;
    const r = e.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const cs = getComputedStyle(e);
    return cs.visibility !== "hidden" && cs.display !== "none";
  }

  function realClick(el) {
    const o = { bubbles: true, cancelable: true, view: window };
    try { el.dispatchEvent(new PointerEvent("pointerdown", o)); } catch (e) {}
    el.dispatchEvent(new MouseEvent("mousedown", o));
    try { el.dispatchEvent(new PointerEvent("pointerup", o)); } catch (e) {}
    el.dispatchEvent(new MouseEvent("mouseup", o));
    el.click();
  }

  function findBtn(re, scope, near) {
    const root = scope || document;
    const all = [...root.querySelectorAll('button, [role=button], a, input[type=button], input[type=submit], div, span')]
      .filter(e => elVisible(e) && !e.closest("#elattal-root") && re.test((e.innerText || e.value || "").trim()));
    const leaf = all.filter(e => !all.some(o => o !== e && e.contains(o)));
    const clickable = leaf.filter(e => e.closest("button, [role=button], a"));
    let pool = clickable.length ? clickable : leaf;
    if (near && pool.length > 1) {
      const r = near.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const dist = e => { const b = e.getBoundingClientRect(); return Math.hypot(b.left + b.width / 2 - cx, b.top + b.height / 2 - cy); };
      pool = [...pool].sort((a, b) => dist(a) - dist(b));
    }
    return pool[0] || null;
  }

  function clickBtn(re, scope, near) {
    const b = findBtn(re, scope, near);
    if (!b) return false;
    (b.closest("button, [role=button], a") || b).click();
    return true;
  }

  function closeModals() {
    let any = false;
    document.querySelectorAll(MODAL_SEL).forEach(m => {
      if (m.offsetParent !== null && !m.closest("#elattal-root") && clickBtn(CLOSE_RE, m)) any = true;
    });
    return any;
  }

  const liveLines = () => new Set((document.body.innerText || "").split("\n").map(l => l.trim()).filter(Boolean));

  const newLinesSince = before => [...liveLines()].filter(l => !before.has(l)).join("\n");

  function feedbackText() {
    return [...document.querySelectorAll(FEEDBACK_SEL)]
      .filter(e => e.offsetParent !== null && !e.closest("#elattal-root"))
      .map(e => (e.innerText || "").trim()).filter(Boolean).join("\n---\n").slice(0, 1500);
  }

  const TEXT_EXCLUDE = EDITOR_SEL + ", #elattal-root, script, style, noscript, [class*=console i], [class*=output i], [id*=console i], [id*=output i], [role=alert]";

  const BLOCK_SEL = "p,div,li,pre,h1,h2,h3,h4,h5,h6,td,tr,section,article,button,label,ul,ol,br";

  function pageText(root, cap) {
    root = root || document.body; cap = cap || 6000;
    const cache = new Map();
    let out = "", prevBlk = null;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (!n.nodeValue || !n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        const el = n.parentElement;
        if (!el) return NodeFilter.FILTER_REJECT;
        let ok = cache.get(el);
        if (ok === undefined) {
          ok = !el.closest(TEXT_EXCLUDE) &&
            (el.checkVisibility ? el.checkVisibility({ checkVisibilityCSS: true }) : el.getClientRects().length > 0);
          cache.set(el, ok);
        }
        return ok ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    while (walker.nextNode()) {
      const n = walker.currentNode, el = n.parentElement;
      const blk = el.closest(BLOCK_SEL) || el;
      if (blk !== prevBlk && out) out += "\n";
      prevBlk = blk;
      out += el.closest("pre, code, [class*=code i], [class*=mono i]") ? n.nodeValue : n.nodeValue.replace(/\s+/g, " ");
      if (out.length > cap * 2) break;
    }
    return out.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim().slice(0, cap);
  }

  function textBefore(edEl, root, cap) {
    const cache = new Map();
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (!n.nodeValue || !n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        const el = n.parentElement;
        if (!el || edEl.contains(n)) return NodeFilter.FILTER_REJECT;
        if (edEl.compareDocumentPosition(n) & Node.DOCUMENT_POSITION_FOLLOWING) return NodeFilter.FILTER_REJECT;
        let ok = cache.get(el);
        if (ok === undefined) {
          ok = !el.closest(TEXT_EXCLUDE) &&
            (el.checkVisibility ? el.checkVisibility({ checkVisibilityCSS: true }) : el.getClientRects().length > 0);
          cache.set(el, ok);
        }
        return ok ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    let out = "";
    while (walker.nextNode()) out += (out ? "\n" : "") + walker.currentNode.nodeValue.replace(/\s+/g, " ").trim();
    return out.slice(-cap);
  }

  // نص التمرين اللي حوالين عنصر معيّن: أصغر حاوية فيها نص كفاية (مش الصفحة كلها)
  function scopeText(el) {
    el = el || document.querySelector(ED_BASE);
    if (!el) return pageText();
    let a = el.parentElement, small = "", big = null;
    for (let i = 0; i < 12 && a && a !== document.body; i++, a = a.parentElement) {
      const t = pageText(a, 6000);
      if (t.length > 150) { small = t; break; }
      if (t.length > 2500) { big = a; break; }
    }
    let ctx = small;
    if (small.length > 3000) ctx = small.slice(0, 3000);
    // لو النص قصير: ضيف أقرب نص قبل العنصر (التعليمات غالباً فوق المحرر)
    if (ctx.length < 700) {
      const before = textBefore(el, big || (a && a !== document.body ? a : document.body), 700);
      if (before && !ctx.includes(before.slice(-100))) ctx = (before + "\n" + ctx).trim();
    }
    return (ctx || pageText()).slice(-3000);
  }
  const exerciseText = scopeText;

  // صور السؤال (رسمة / شكل مطلوب) بتتبعت لـ Claude مع النص
  async function imgData(img) {
    try {
      const c = document.createElement("canvas");
      c.width = Math.min(img.naturalWidth, 1200);
      c.height = Math.max(1, Math.round(c.width * img.naturalHeight / img.naturalWidth));
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      return c.toDataURL("image/png");
    } catch (e) {
      try {
        const r = await chrome.runtime.sendMessage({ type: "FETCH_IMG", url: img.currentSrc || img.src });
        return r && r.ok ? r.data : null;
      } catch (e2) { return null; }
    }
  }
  async function collectImages(el) {
    let a = el ? el.parentElement : null, imgs = [];
    for (let i = 0; i < 8 && a && a !== document.body; i++, a = a.parentElement) {
      if (pageText(a, 3200).length > 3000) break;
      imgs = [...a.querySelectorAll("img")].filter(m => elVisible(m) && m.naturalWidth >= 80 && m.naturalHeight >= 40 &&
        !m.closest("#elattal-root") && !m.closest(EDITOR_SEL) && !/\.svg(\?|$)/i.test(m.currentSrc || m.src));
      if (imgs.length) break;
    }
    const out = [];
    for (const m of imgs.slice(0, 3)) { const d = await imgData(m); if (d && d.length < 2500000) out.push(d); }
    return out;
  }

  function previewText() {
    const out = [];
    for (const f of document.querySelectorAll("iframe")) {
      try { const d = f.contentDocument; if (d && d.body) { const t = (d.body.innerText || "").trim(); if (t) out.push(t.slice(0, 500)); } } catch (e) {}
    }
    return out.join("\n---\n").slice(0, 900);
  }

  async function getPageText(el) {
    let t = scopeText(el);
    if (!IS_TOP) {
      try {
        const r = await chrome.runtime.sendMessage({ type: "TOP_TEXT" });
        if (r && r.text) t = r.text + " " + t;
      } catch (e) {}
    }
    return t;
  }

  // ================= صفحات النتيجة / المراجعة (بنتخطاها) =================
  function allEditors() {
    return [...document.querySelectorAll(ED_BASE)].filter(e => !(e.parentElement && e.parentElement.closest(ED_BASE)));
  }

  function isResultPage() {
    if (/\/(test\/)?results?(\/|$)|\/review(\/|$)/i.test(location.pathname)) return true;
    if (allEditors().length >= 2 && /كود الإجابة|كود الاجابة|answer code|model answer/i.test(document.body.innerText || "")) return true;
    return false;
  }

  async function skipResultPage() {
    const opts = await chrome.storage.sync.get(["autoNext"]);
    const key = location.pathname + "|" + hash(pageText(document.body, 1200));
    const prev = skipSeen.get(key) || { n: 0, t: 0 };
    if (prev.n >= 3 || (prev.n >= 1 && Date.now() - prev.t < 10000)) return; // مرة واحدة، ولو الصفحة ما اتغيرتش بعد 10 ثواني يحاول تاني
    skipSeen.set(key, { n: prev.n + 1, t: Date.now() });
    if (opts.autoNext === false) { setStatus("صفحة نتيجة: بيتخطاها من غير أي حل"); return; }
    if (clickBtn(NEXT_RE)) setStatus("صفحة نتيجة اختبار، اتخطّاها ✓");
    else setStatus("صفحة نتيجة، مالقيتش زرار التالي");
  }

  // ================= أسئلة الاختيار (native + custom) =================
  function nativeVisible(el) {
    if (elVisible(el)) return true;
    const l = (el.labels && el.labels[0]) || el.closest("label");
    if (l && elVisible(l)) return true;
    const p = el.parentElement;
    return !!(p && elVisible(p) && (p.innerText || "").trim());
  }

  function optionText(el) {
    let t = "";
    const l = (el.labels && el.labels[0]) || el.closest("label");
    if (l) t = l.innerText;
    if (!t && el.nextSibling) t = el.nextSibling.textContent || "";
    if (!t && el.parentElement) t = el.parentElement.innerText || "";
    return (t || el.value || "").trim().slice(0, 250);
  }

  function groupAnchor(el) {
    const sel = `input[type=${el.type}]`;
    let a = el.parentElement;
    while (a && a !== document.body && a.querySelectorAll(sel).length < 2) a = a.parentElement;
    return a && a !== document.body ? a : (el.form || el.parentElement);
  }

  function questionOf(anchor, optTexts) {
    const optLen = optTexts.join("").length;
    let a = anchor;
    for (let i = 0; i < 6 && a && a !== document.body; i++) {
      const t = (a.innerText || "").trim();
      if (t.length - optLen > 25) return t.slice(0, 900);
      a = a.parentElement;
    }
    return ((anchor && anchor.innerText) || "").trim().slice(0, 900);
  }

  function optionLabel(k) {
    const ed = k.querySelector(ED_BASE);
    if (ed) {
      const lines = [...ed.querySelectorAll(".ace_line, .view-line, .CodeMirror-line, .cm-line")]
        .map(l => (l.innerText || l.textContent || "").replace(/\u00a0/g, " ").replace(/\s+$/, ""));
      const code = lines.join("\n").trim();
      if (code) return code;
    }
    return (k.innerText || "").trim();
  }

  function structuralGroups(known) {
    const out = [];
    const noise = t => NAV_RE.test(t) || RUN_RE.test(t) || REVEAL_RE.test(t) || CLOSE_RE.test(t) || LANG_RE.test(t) || /^\d+$/.test(t);
    const used = new Set();
    for (const c of document.querySelectorAll("div, ul, ol, section, fieldset, form")) {
      const n = c.childElementCount;
      if (n < 2 || n > 8) continue;
      if (c.closest("#elattal-root, nav, header, footer, aside, [role=navigation], [role=tablist], [role=menu], [role=toolbar]") || c.closest(EDITOR_SEL)) continue;
      const kids = [...c.children];
      if (!kids.every(elVisible)) continue;
      const texts = kids.map(optionLabel);
      if (texts.some(t => t.length < 1 || t.length > 200 || noise(t))) continue;
      const interactive = k => [...k.querySelectorAll("input, textarea, select, button, a[href]:not([href='#'])")].some(x => !x.closest(ED_BASE));
      if (kids.some(k => interactive(k) || (k.tagName === "A" && k.getAttribute("href") && k.getAttribute("href") !== "#"))) continue;
      const rs = kids.map(k => k.getBoundingClientRect());
      const ratio = a => Math.max(...a) / Math.max(1, Math.min(...a));
      if (ratio(rs.map(r => r.width)) > 2.5 && ratio(rs.map(r => r.height)) > 2.5) continue;
      const clickable = kids.filter(k => {
        const f = k.firstElementChild;
        return getComputedStyle(k).cursor === "pointer" || (f && getComputedStyle(f).cursor === "pointer") ||
          k.tagName === "BUTTON" || k.tagName === "LABEL" || k.hasAttribute("tabindex") ||
          /^(option|radio|checkbox|button)$/.test(k.getAttribute("role") || "");
      }).length;
      if (clickable < Math.ceil(kids.length * 0.6)) continue;
      if (kids.some(k => known.some(e => k === e || k.contains(e) || e.contains(k)) || used.has(k))) continue;
      const selected = kids.some(k => k.getAttribute("aria-selected") === "true" || k.getAttribute("aria-checked") === "true" ||
        /\b(selected|checked|chosen|is-selected|is-checked)\b/i.test(typeof k.className === "string" ? k.className : ""));
      if (selected) continue;
      const q = questionOf(c, texts);
      if (q.length < texts.join("").length + 20) continue; // مفيش نص سؤال
      kids.forEach(k => used.add(k));
      out.push({
        kind: "custom", structural: true,
        multi: /select all|choose all|more than one|multiple|all that apply|اختر كل|حدد كل|أكثر من/i.test(q),
        first: kids[0], question: q,
        options: kids.map((k, i) => ({ text: texts[i], el: k }))
      });
    }
    return out;
  }

  function collectChoiceGroups() {
    const groups = [];

    // --- native radio / checkbox (حتى لو مخفية والـ label ظاهر) ---
    const inputs = [...document.querySelectorAll("input[type=radio], input[type=checkbox]")]
      .filter(el => !el.disabled && !el.closest(EDITOR_SEL) && nativeVisible(el));
    const nat = [];
    for (const el of inputs) {
      const anchor = groupAnchor(el);
      let g = nat.find(x => x.anchor === anchor && x.type === el.type && x.name === (el.name || ""));
      if (!g) { g = { anchor, type: el.type, name: el.name || "", els: [] }; nat.push(g); }
      g.els.push(el);
    }
    for (const g of nat) {
      if (g.els.length < 2) continue;
      if (g.els.some(e => e.checked)) continue;
      const texts = g.els.map(optionText);
      groups.push({
        kind: "native",
        multi: g.type === "checkbox",
        first: g.els[0],
        question: questionOf(g.anchor, texts),
        options: g.els.map((el, i) => ({ text: texts[i], el }))
      });
    }

    // --- custom: divs / li / buttons شكلها اختيارات ---
    const cands = [...document.querySelectorAll('[role=radio],[role=checkbox],[role=option],[role=menuitemradio],[class],li,label,button')].filter(e => {
      if (e.closest("#elattal-root") || e.closest(EDITOR_SEL)) return false;
      if (["INPUT", "TEXTAREA", "SELECT", "SCRIPT", "STYLE", "OPTION"].includes(e.tagName)) return false;
      const role = e.getAttribute("role");
      const roleOk = !!role && /^(radio|checkbox|option|menuitemradio)$/.test(role);
      const cls = (typeof e.className === "string" ? e.className : "") + " " + (e.id || "");
      const clsOk = CHOICE_CLASS.test(cls);
      if (!roleOk && !clsOk) return false;
      const t = (e.innerText || "").trim();
      if (t.length < 1 || t.length > 250) return false;
      if (NAV_RE.test(t) || RUN_RE.test(t) || REVEAL_RE.test(t)) return false;
      if (e.querySelector("input[type=radio], input[type=checkbox]")) return false;
      const lab = e.closest("label");
      if (lab && lab.querySelector("input[type=radio], input[type=checkbox]")) return false;
      if (!roleOk && !["BUTTON", "LABEL", "LI"].includes(e.tagName) && getComputedStyle(e).cursor !== "pointer") return false;
      return elVisible(e);
    });
    const leaf = cands.filter(e => !cands.some(o => o !== e && e.contains(o)));
    const byParent = new Map();
    for (const c of leaf) {
      let unit = c;
      while (unit.parentElement && leaf.filter(o => unit.parentElement.contains(o)).length === 1) unit = unit.parentElement;
      const key = unit.parentElement;
      if (!key) continue;
      if (!byParent.has(key)) byParent.set(key, []);
      byParent.get(key).push({ unit, el: c });
    }
    for (const [key, list] of byParent) {
      if (list.length < 2 || list.length > 10) continue;
      const selected = list.some(({ unit, el }) => [unit, el].some(n =>
        n.getAttribute("aria-checked") === "true" || n.getAttribute("aria-selected") === "true" ||
        /\b(selected|checked|chosen|is-selected|is-checked)\b/i.test(typeof n.className === "string" ? n.className : "")));
      if (selected) continue;
      const texts = list.map(x => (x.el.innerText || "").trim());
      const question = questionOf(key, texts);
      groups.push({
        kind: "custom",
        multi: /select all|choose all|more than one|multiple|all that apply|すべて/i.test(question),
        first: list[0].el,
        question,
        options: list.map((x, i) => ({ text: texts[i], el: x.el }))
      });
    }

    // --- أي قايمة شكلها اختيارات حتى لو من غير class مميز ---
    const known = groups.flatMap(g => g.options.map(o => o.el));
    for (const g of structuralGroups(known)) groups.push(g);

    groups.sort((a, b) => (a.first.compareDocumentPosition(b.first) & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1);
    const out = [];
    for (const g of groups) {
      g.sig = hash(g.question.slice(0, 200) + "|" + g.options.map(o => o.text).join("|"));
      if (solvedSigs.has(g.sig)) continue;
      g.gid = out.length;
      out.push(g);
    }
    return out;
  }

  const snapOf = k => (typeof k.className === "string" ? k.className : "") + "|" +
    [...k.querySelectorAll("*")].map(e => (typeof e.className === "string" ? e.className : "") + (e.getAttribute("aria-checked") || "") + (e.getAttribute("aria-selected") || "")).join(",");

  async function selectCustom(kid, multi) {
    const before = snapOf(kid);
    realClick(kid);
    await sleep(250);
    if (multi || snapOf(kid) !== before) return;
    // الكارت ما اتغيرش: ممكن الضغط شغال على الدايرة اللي جواه
    const dots = [...kid.querySelectorAll("*")].filter(e => {
      if ((e.innerText || "").trim() || e.closest(ED_BASE)) return false;
      const r = e.getBoundingClientRect();
      return r.width >= 12 && r.width <= 48 && r.height >= 12 && r.height <= 48 && Math.abs(r.width - r.height) <= 6;
    });
    const dot = dots[dots.length - 1];
    if (dot) { realClick(dot); await sleep(200); }
  }

  function clickAnswerBtn(near) {
    const b = findBtn(ANSWER_RE, null, near);
    if (!b) return false;
    const t = b.closest("button, [role=button], a") || (b.tagName === "INPUT" ? b : null);
    if (!t) return false;
    t.click();
    return true;
  }

  async function applyChoices(groups, answers) {
    const { autoSubmit } = await chrome.storage.sync.get(["autoSubmit"]);
    answers = [...answers].sort((a, b) => a.gid - b.gid);
    let done = 0;
    for (const a of answers) {
      const g = groups[a.gid];
      if (!g) continue;
      let picks = (Array.isArray(a.pick) ? a.pick : [a.pick]).map(Number).filter(i => g.options[i]);
      if (!g.multi) picks = picks.slice(0, 1);
      for (const i of picks) {
        await sleep(350);
        const { el } = g.options[i];
        try {
          if (g.kind === "native") {
            if (!el.checked) {
              const lab = (el.labels && el.labels[0]) || el.closest("label");
              realClick(lab && elVisible(lab) ? lab : el);
              if (!el.checked) {
                el.checked = true;
                el.dispatchEvent(new Event("input", { bubbles: true }));
                el.dispatchEvent(new Event("change", { bubbles: true }));
              }
            }
            const mark = (el.labels && el.labels[0]) || el.parentElement;
            if (mark) mark.style.outline = "2px solid #22c55e";
          } else {
            await selectCustom(el, g.multi);
            el.style.outline = "2px solid #22c55e";
          }
        } catch (e) { console.warn("Elattal choice fail", e); }
      }
      if (picks.length) {
        done++;
        if (autoSubmit !== false) {
          await sleep(400);
          if (clickAnswerBtn(g.first)) { setStatus("اتضغط (إجابة) ✓"); await sleep(600); }
        }
      }
      await sleep(500);
    }
    return done;
  }

  // ================= خانات النصوص والقوائم =================
  function describe(el) {
    let label = "";
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l) label = l.innerText;
    }
    if (!label && el.closest("label")) label = el.closest("label").innerText;
    if (!label && el.nextSibling) label = el.nextSibling.textContent || "";
    const box = el.closest("fieldset, .question, [class*=question], li, section") || el.parentElement;
    const info = {
      type: el.tagName === "SELECT" ? "select" : (el.type || el.tagName.toLowerCase()),
      name: el.name || "",
      label: label.trim().slice(0, 300),
      context: (box ? box.innerText : "").trim().slice(0, 700)
    };
    if (el.tagName === "SELECT") info.options = [...el.options].map(o => o.text);
    return info;
  }

  function isAnswered(el) {
    if (el.tagName === "SELECT") return el.selectedIndex > 0 && el.value !== "";
    return (el.value || "").trim() !== "";
  }

  function setValue(el, value) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async function applyActions(actions) {
    actions = [...actions].sort((x, y) => x.aid - y.aid);
    for (const a of actions) {
      await sleep(250);
      const el = document.querySelector(`[data-aid="${a.aid}"]`);
      if (!el) continue;
      try {
        if (a.action === "fill") setValue(el, String(a.value));
        else if (a.action === "select") {
          const opt = [...el.options].find(o => o.text.trim() === String(a.value).trim());
          if (opt) { el.value = opt.value; el.dispatchEvent(new Event("change", { bubbles: true })); }
        } else if (a.action === "check") { if (!el.checked) realClick(el); }
        el.style.outline = "2px solid #22c55e";
      } catch (e) { console.warn("Elattal: fail", a, e); }
    }
  }

  function overlapsEditor(el, ed) {
    ed = ed || curEl;
    if (!ed) return false;
    const r = ed.getBoundingClientRect(), b = el.getBoundingClientRect();
    const cx = b.left + b.width / 2, cy = b.top + b.height / 2;
    return cx >= r.left && cx <= r.right && cy >= r.top && cy <= r.bottom;
  }
  function lineTextFor(el) {
    const b = el.getBoundingClientRect();
    const cy = b.top + b.height / 2;
    const lines = [...(curEl || document).querySelectorAll(".ace_line, .view-line, .CodeMirror-line, .cm-line")];
    const hit = lines.find(l => { const r = l.getBoundingClientRect(); return r.height > 0 && cy >= r.top - 3 && cy <= r.bottom + 3; });
    return hit ? (hit.innerText || hit.textContent || "").replace(/\u00a0/g, " ").trim().slice(0, 300) : "";
  }
  function blankInputsFor(ed) {
    return [...document.querySelectorAll("input")].filter(el =>
      !el.closest("#elattal-root") && ["text", ""].includes(el.type || "") && elVisible(el) && overlapsEditor(el, ed));
  }

  // الخانات العادية (اللي مش جوه محرر)
  function candidateFields() {
    const eds = allEditors();
    const out = [];
    for (const el of document.querySelectorAll(FIELD_SEL)) {
      if (!elVisible(el) || el.closest("#elattal-root") || el.closest(EDITOR_SEL) || isAnswered(el)) continue;
      if (eds.some(ed => overlapsEditor(el, ed))) continue;
      const info = describe(el);
      const sig = hash(info.context.slice(0, 200) + "|" + info.label + "|" + info.name);
      if (el.dataset.esig === sig) continue;
      out.push({ el, info, sig });
    }
    return out;
  }

  // ================= محرر الكود =================
  function bridge(op, code, edits) {
    return new Promise(resolve => {
      const id = Math.random().toString(36).slice(2);
      const to = setTimeout(() => { window.removeEventListener("message", h); resolve({ ok: false }); }, 700);
      function h(ev) {
        if (ev.source === window && ev.data && ev.data.type === "ELATTAL_RES" && ev.data.id === id) {
          clearTimeout(to); window.removeEventListener("message", h); resolve(ev.data);
        }
      }
      window.addEventListener("message", h);
      window.postMessage({ type: "ELATTAL_REQ", id, op, code, edits, eid: curEid }, "*");
    });
  }

  function tagEditor(el) {
    if (!el.dataset.eid) el.dataset.eid = String(Math.floor(Math.random() * 1e9));
    return el.dataset.eid;
  }

  async function editorReadOnly() {
    const r = await bridge("info");
    if (r.ok) return !!r.ro;
    const ta = curEl && curEl.querySelector("textarea");
    return !!(ta && (ta.readOnly || ta.disabled));
  }

  function typeIntoEditor(code) {
    const ed = curEl || document.querySelector(ED_BASE);
    if (!ed) return false;
    const ta = ed.querySelector("textarea") || ed.querySelector("[contenteditable=true]");
    if (!ta) return false;
    ta.focus();
    ta.dispatchEvent(new KeyboardEvent("keydown", { key: "a", code: "KeyA", keyCode: 65, which: 65, ctrlKey: true, metaKey: true, bubbles: true, cancelable: true }));
    document.execCommand("selectAll");
    return document.execCommand("insertText", false, code);
  }

  async function readEditor() {
    const cur = await bridge("get");
    if (cur.ok) return cur.code;
    const ed = curEl || document.querySelector(ED_BASE);
    return ed ? (ed.innerText || "").slice(0, 4000) : "";
  }

  let lastWritten = "";

  const norm = t => (t || "").replace(/\r\n/g, "\n").replace(/[ \t]+$/gm, "").trim();

  async function writeCode(code) {
    let ok = (await bridge("set", code)).ok;
    if (!ok) ok = typeIntoEditor(code);
    if (!ok) return false;
    await sleep(200);
    const g = await bridge("get");
    if (g.ok && norm(g.code) !== norm(code)) {          // اتأكد إن اللي اتكتب هو المطلوب بالحرف
      await bridge("set", code);
      await sleep(200);
      const g2 = await bridge("get");
      if (g2.ok && norm(g2.code) !== norm(code)) setStatus("⚠ المحرر غيّر الكود بعد الكتابة (تنسيق تلقائي)");
    }
    lastWritten = code;
    return true;
  }

  function parseCodeReply(t) {
    t = t.trim();
    let conf = "high";
    const m = t.match(/^CONFIDENCE:\s*(high|low)\s*\n?/i);
    if (m) { conf = m[1].toLowerCase(); t = t.slice(m[0].length); }
    t = t.replace(/^\s*```[a-zA-Z]*\n?/, "").replace(/```\s*$/, "").replace(/^\n+/, "");
    return { conf, code: t };
  }

  function clickRunFor(ed) {
    let a = ed ? ed.parentElement : null;
    for (let i = 0; i < 8 && a && a !== document.body; i++, a = a.parentElement) {
      if (clickBtn(RUN_RE, a, ed)) return true;
    }
    return clickBtn(RUN_RE, null, ed);
  }

  async function runAndRead() {
    const before = liveLines();
    if (!clickRunFor(curEl)) return { ran: false, feedback: "" };
    await sleep(2500);
    return { ran: true, feedback: (feedbackText() + "\n---NEW LINES---\n" + newLinesSince(before) + "\n---PREVIEW---\n" + previewText()).slice(0, 2600) };
  }

  async function revealFlow(text) {
    setStatus("بيدوس عرض الإجابة...");
    const e0 = await readEditor();
    const before = liveLines();
    if (!clickBtn(REVEAL_RE, null, curEl)) { setStatus("⚠ مالقيتش زرار عرض الإجابة"); return false; }
    await sleep(1800);

    const e1 = await readEditor();
    if (e1.trim() && e1.trim() !== e0.trim()) {
      closeModals(); await sleep(500);
      const r = await runAndRead();
      setStatus(r.ran ? "الإجابة الصح اتحطت وتشغّلت ✓" : "الإجابة الصح اتحطت ✓", "code", 1);
      return true;
    }

    const revealed = (newLinesSince(before) || (document.body.innerText || "")).slice(0, 4000);
    setStatus("بيقرا الإجابة الصح...");
    const r = await ask("EXTRACT", { page: text, current: e0, revealed });
    closeModals(); await sleep(500);
    if (!(await writeCode(r.code))) { setStatus("⚠ مقدرتش أكتب الإجابة الصح"); return false; }
    await sleep(600);
    const run = await runAndRead();
    setStatus(run.ran ? "كتب الإجابة الصح وشغّلها ✓" : "كتب الإجابة الصح ✓ (مالقيتش Run)", "code", 1);
    return true;
  }

  async function blankFinish(items, text) {
    const opts = await chrome.storage.sync.get(["autoRunCode", "autoReveal"]);
    if (opts.autoRunCode === false) { setStatus("تم تعبئة الفراغات ✓"); return; }
    await sleep(600);
    setStatus("بيشغّل الكود...");
    const code = await readEditor();
    const run = await runAndRead();
    if (!run.ran) { setStatus("تم تعبئة الفراغات ✓ (مالقيتش زرار Run)"); return; }

    setStatus("بيتأكد من النتيجة...");
    const vals = items.map(i => i.el.value).join(" | ");
    const j = await ask("JUDGE", { page: text, code: code + "\n\nBLANK VALUES: " + vals, feedback: run.feedback });
    if (j.verdict !== "FAIL") { setStatus("تم حل الفراغات وتشغيل الكود ✓"); return; }
    if (opts.autoReveal === false) { setStatus("الحل غالباً غلط (التعلّم التلقائي مقفول)"); return; }

    setStatus("الحل غلط، بيدوس عرض الإجابة...");
    const before = liveLines();
    const vals0 = items.map(i => i.el.value).join("|");
    if (!clickBtn(REVEAL_RE, null, curEl)) { setStatus("⚠ مالقيتش زرار عرض الإجابة"); return; }
    await sleep(1800);

    if (items.map(i => i.el.value).join("|") !== vals0) {
      closeModals(); await sleep(500); await runAndRead();
      setStatus("الإجابة الصح اتحطت وتشغّلت ✓", "code", 1);
      return;
    }
    const revealed = (newLinesSince(before) || (document.body.innerText || "")).slice(0, 4000);
    setStatus("بيقرا الإجابة الصح...");
    const r = await ask("EXTRACT_BLANKS", { page: text, revealed, blanks: items.map(i => ({ aid: i.aid, line: i.line, current: i.el.value })) });
    closeModals(); await sleep(500);
    for (const a of r.answers) {
      const it = items.find(i => i.aid === a.aid);
      if (it) { setValue(it.el, String(a.value)); it.el.style.outline = "2px solid #22c55e"; }
      await sleep(250);
    }
    await sleep(600);
    await runAndRead();
    setStatus("كتب الإجابة الصح وشغّلها ✓", "code", 1);
  }

  const hasReveal = () => !!findBtn(REVEAL_RE, null, curEl);

  async function solveEdits(text, els) {
    const opts = await chrome.storage.sync.get(["autoRunCode", "autoReveal"]);
    let fb = "", revealed = "", applied = false;
    for (let attempt = 0; attempt < 3; attempt++) {
      const code = await readEditor();
      const numbered = code.split("\n").map((l, i) => `${i + 1}| ${l}`).join("\n");
      const blanks = els.map((el, i) => ({ index: i, line: lineTextFor(el), value: el.value }));
      setStatus(attempt ? `محاولة ${attempt + 1}: بيصلّح التعديلات...` : "بيفكر في الأجزاء الناقصة في المحرر...");
      const res = await ask("ASK_EDITS", { page: text, code: numbered, blanks, feedback: fb, revealed, images: await collectImages(curEl) });

      for (const b of res.blanks || []) {
        const el = els[b.index];
        if (el && String(b.value) !== el.value) {
          setValue(el, String(b.value)); el.style.outline = "2px solid #22c55e"; applied = true; await sleep(250);
        }
      }
      const edits = (res.edits || []).filter(e => e && Number.isInteger(e.line) && typeof e.code === "string");
      if (edits.length) {
        setStatus(`بيكتب ${edits.length} تعديل في المحرر...`);
        const r = await bridge("edit", null, edits);
        if (!r.ok) { setStatus("⚠ مقدرتش أعدّل المحرر"); return applied; }
        applied = true;
        await sleep(300);
      }
      if (!applied) return false; // مفيش حاجة ناقصة

      if (opts.autoRunCode === false) { setStatus("تم التعديل ✓", "code", 1); return true; }
      await sleep(600);
      setStatus("بيشغّل الكود...");
      const run = await runAndRead();
      if (!run.ran) { setStatus("تم التعديل ✓ (مالقيتش Run)", "code", 1); return true; }

      setStatus("بيتأكد من النتيجة...");
      const finalCode = await readEditor();
      const j = await ask("JUDGE", { page: text, code: finalCode + "\n\nBLANK VALUES: " + els.map(e => e.value).join(" | "), feedback: run.feedback });
      if (j.verdict !== "FAIL") { setStatus("تم حل التمرين وتشغيله ✓", "code", 1); return true; }

      fb = run.feedback;
      if (attempt === 1 && opts.autoReveal !== false && hasReveal()) {
        const before = liveLines();
        clickBtn(REVEAL_RE, null, curEl);
        await sleep(1800);
        revealed = newLinesSince(before).slice(0, 3000);
        closeModals(); await sleep(400);
      }
    }
    setStatus("⚠ الحل لسه غلط بعد 3 محاولات، كمّل بنفسك");
    return true;
  }

  async function solveCodeInner(text) {
    const opts = await chrome.storage.sync.get(["autoRunCode", "autoReveal", "autoReview"]);
    const starter = await readEditor();
    setStatus("قرا التمرين: \"" + text.replace(/\s+/g, " ").slice(0, 70) + "…\"");
    let cur = starter, prev = "", fb = "";
    for (let attempt = 0; attempt < 3; attempt++) {
      setStatus(attempt ? `محاولة ${attempt + 1}: بيصلّح الحل...` : "بيفكر في التمرين...");
      const { raw } = await ask("ASK_CODE", { page: text, current: starter, prev, feedback: fb, images: await collectImages(curEl) });
      const parsed = parseCodeReply(raw);
      const conf = parsed.conf;
      let code = parsed.code;
      if (opts.autoReview !== false) {
        setStatus("بيراجع الكود حرف حرف...");
        const rv = await ask("REVIEW", { page: text, current: starter, code }, true);
        if (rv && rv.code) code = rv.code;
      }

      setStatus(`بيكتب الكود (ثقة: ${conf === "high" ? "عالية" : "ضعيفة"})...`);
      if (!(await writeCode(code))) { setStatus("⚠ مقدرتش أكتب في المحرر"); return; }
      cur = code;
      if (opts.autoRunCode === false) { setStatus("تم كتابة الكود ✓", "code", 1); return; }

      await sleep(600);
      setStatus("بيشغّل الكود...");
      const run = await runAndRead();
      if (!run.ran) { setStatus("تم كتابة الكود ✓ (مالقيتش زرار Run)", "code", 1); return; }

      setStatus("بيتأكد من النتيجة...");
      const j = await ask("JUDGE", { page: text, code, feedback: run.feedback });
      const failed = j.verdict === "FAIL" || (conf === "low" && j.verdict !== "PASS");
      if (!failed) { setStatus("تم كتابة الكود وتشغيله ✓", "code", 1); return; }

      if (opts.autoReveal !== false && hasReveal()) { await revealFlow(text); return; }
      prev = code; fb = run.feedback; // مفيش عرض إجابة: يصلّح بنفسه من نتيجة التشغيل
    }
    setStatus("⚠ الحل لسه غلط بعد 3 محاولات، كمّل بنفسك");
  }

  const tplSig = async (text, blanks) =>
    hash(location.pathname + location.search + "|" + curIdx + "|" + text.slice(0, 1500) + "|" + (await readEditor()) + "|" + blanks.map(e => e.value).join("|"));

  // تمرين قالب: فراغات input + أسطر فاضية تتكتب (تعديل أسطر بس من غير ما نمسح القالب)
  async function solveTemplate(blanks, text) {
    const before = await tplSig(exerciseText(curEl), blanks);
    if (tplSeen.has(before)) return false;
    tplSeen.add(before);
    const changed = await solveEdits(text, blanks);
    tplSeen.add(await tplSig(exerciseText(curEl), blanks));
    return changed;
  }

  async function solveCode(text) {
    if (text.length < 30) { setStatus("لقيت محرر بس مفيش نص تمرين"); return; }
    const kt = exerciseText(curEl);
    const key = "code:" + hash(location.pathname + location.search + "|" + curIdx + "|" + kt.slice(0, 2500));
    if (solvedSigs.has(key)) return;
    const ck = location.pathname + "#" + curIdx;
    const cnt = (pathCount.get(ck) || 0) + 1;
    if (cnt > 8) return; // حماية من التكرار اللانهائي
    pathCount.set(ck, cnt);
    solvedSigs.add(key); persistSolved();
    try {
      await solveCodeInner(text);
    } catch (e) {
      solvedSigs.delete(key); persistSolved();
      throw e;
    }
    const k2 = "code:" + hash(location.pathname + location.search + "|" + curIdx + "|" + exerciseText(curEl).slice(0, 2500));
    solvedSigs.add(k2); persistSolved();
  }

  // ================= محرك الأسئلة بالترتيب =================
  async function fillBlanks(els, text) {
    document.querySelectorAll("[data-aid]").forEach(e => e.removeAttribute("data-aid"));
    const fields = els.map((el, i) => { el.setAttribute("data-aid", i); return { aid: i, ...describe(el), blank: true, line: lineTextFor(el) }; });
    setStatus(`بيحل ${fields.length} فراغ جوه الكود...`);
    const res = await ask("ASK", { fields, page: text, code: await readEditor(), images: await collectImages(els[0]) });
    await applyActions(res.actions);
    setStatus(`تم تعبئة ${res.actions.length} فراغ ✓`, "fields", res.actions.length);
  }

  // ---------- تمارين بأكتر من تاب (HTML + CSS + JS) ----------
  function findTabs(rect) {
    const cands = [...document.querySelectorAll("button, [role=tab], li, a, div, span")].filter(e => {
      if (e.closest("#elattal-root") || !elVisible(e)) return false;
      if (!LANG_RE.test((e.innerText || "").trim())) return false;
      const b = e.getBoundingClientRect();
      return b.bottom >= rect.top - 90 && b.top <= rect.top + 50 && b.right >= rect.left - 20 && b.left <= rect.right + 20;
    });
    const leaf = cands.filter(e => !cands.some(o => o !== e && e.contains(o)));
    const seen = new Set(), out = [];
    for (const e of leaf.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left)) {
      const label = e.innerText.trim().toLowerCase();
      if (seen.has(label)) continue;
      seen.add(label); out.push({ label, el: e });
    }
    return out;
  }

  function activeEditor(rect) {
    const vis = allEditors().filter(elVisible);
    let best = null, bestA = -1;
    for (const e of vis) {
      const r = e.getBoundingClientRect();
      const w = Math.max(0, Math.min(r.right, rect.right) - Math.max(r.left, rect.left));
      const h = Math.max(0, Math.min(r.bottom, rect.bottom) - Math.max(r.top, rect.top));
      if (w * h > bestA) { bestA = w * h; best = e; }
    }
    return best || vis[0] || null;
  }

  async function switchTab(label) {
    const rect = curEl.getBoundingClientRect();
    const tab = findTabs(rect).find(t => t.label === label);
    if (!tab) return false;
    realClick(tab.el);
    await sleep(350);
    const ed = activeEditor(rect);
    if (!ed) return false;
    curEl = ed; curEid = tagEditor(ed);
    return true;
  }

  const multiKey = (tabs, kt) => "multi:" + hash(location.pathname + location.search + "|" + tabs.map(t => t.label).join(",") + "|" + kt.slice(0, 2500));

  async function solveMulti(tabs, text) {
    const opts = await chrome.storage.sync.get(["autoRunCode", "autoReveal", "autoReview"]);
    const labels = tabs.map(t => t.label);
    const readAll = async () => {
      const files = [];
      for (const l of labels) if (await switchTab(l)) files.push({ name: l, code: await readEditor() });
      return files;
    };
    const starter = await readAll();
    if (!starter.length) { setStatus("⚠ مقدرتش أفتح التابات"); return; }
    let fb = "", revealed = "";
    for (let attempt = 0; attempt < 3; attempt++) {
      setStatus(attempt ? `محاولة ${attempt + 1}: بيصلّح الملفات...` : `تمرين بـ ${labels.length} تابات (${labels.join(" + ").toUpperCase()}) بيفكر...`);
      const current = await readAll();
      const res = await ask("ASK_FILES", { page: text, starter, files: current, feedback: fb, revealed, images: await collectImages(curEl) });

      let written = 0;
      for (const f of res.files || []) {
        const name = String(f.name || "").toLowerCase();
        if (!labels.includes(name) || typeof f.code !== "string") continue;
        if (!(await switchTab(name))) continue;
        let code = f.code;
        if (opts.autoReview !== false) {
          setStatus(`بيراجع ${name.toUpperCase()} حرف حرف...`);
          const rv = await ask("REVIEW", { page: text, current: (current.find(x => x.name === name) || {}).code || "", code }, true);
          if (rv && rv.code) code = rv.code;
        }
        setStatus(`بيكتب في تاب ${name.toUpperCase()}...`);
        if (await writeCode(code)) written++;
      }
      if (!written) {
        if (attempt === 0) { setStatus("التابات مكتملة، مفيش حاجة تتكتب ✓"); return; }
        break;
      }
      if (opts.autoRunCode === false) { setStatus(`تم كتابة ${written} ملف ✓`, "code", 1); return; }

      await sleep(600);
      setStatus("بيشغّل الكود...");
      const run = await runAndRead();
      if (!run.ran) { setStatus("تم كتابة الملفات ✓ (مالقيتش زرار Run)", "code", 1); return; }

      setStatus("بيتأكد من النتيجة...");
      const finalFiles = await readAll();
      const j = await ask("JUDGE", { page: text, code: finalFiles.map(f => `--- ${f.name.toUpperCase()} ---\n${f.code}`).join("\n\n"), feedback: run.feedback });
      const failed = j.verdict === "FAIL" || (res.confidence === "low" && j.verdict !== "PASS");
      if (!failed) { setStatus(`تم حل التمرين (${labels.join(" + ").toUpperCase()}) وتشغيله ✓`, "code", 1); return; }

      fb = run.feedback;
      if (attempt === 1 && opts.autoReveal !== false && hasReveal()) {
        const before = liveLines();
        clickBtn(REVEAL_RE, null, curEl);
        await sleep(1800);
        revealed = newLinesSince(before).slice(0, 3000);
        closeModals(); await sleep(400);
      }
    }
    setStatus("⚠ الحل لسه غلط بعد 3 محاولات، كمّل بنفسك");
  }

  async function solveMultiKeyed(tabs, text) {
    const kt = exerciseText(curEl);
    const key = multiKey(tabs, kt);
    if (solvedSigs.has(key)) return;
    const ck = location.pathname + "#" + tabs.map(t => t.label).join(",");
    const cnt = (pathCount.get(ck) || 0) + 1;
    if (cnt > 8) return;
    pathCount.set(ck, cnt);
    solvedSigs.add(key); persistSolved();
    try { await solveMulti(tabs, text); }
    catch (e) { solvedSigs.delete(key); persistSolved(); throw e; }
    solvedSigs.add(multiKey(tabs, exerciseText(curEl))); persistSolved();
  }

  async function editorPending(ed, idx) {
    curEid = tagEditor(ed); curEl = ed; curIdx = idx;
    if (await editorReadOnly()) return false; // محرر للعرض بس (إجابة / مثال / مخرجات)
    const text = exerciseText(ed);
    const blanks = blankInputsFor(ed);
    if (blanks.length) {
      if (blanks.some(el => !(el.value || "").trim())) return true;
      return !tplSeen.has(await tplSig(text, blanks));
    }
    if (text.length < 30) return false;
    const tabs = findTabs(ed.getBoundingClientRect());
    if (tabs.length >= 2) return !solvedSigs.has(multiKey(tabs, text));
    return !solvedSigs.has("code:" + hash(location.pathname + location.search + "|" + idx + "|" + text.slice(0, 2500)));
  }

  async function processEditor(ed, idx) {
    curEid = tagEditor(ed); curEl = ed; curIdx = idx;
    const blanks = blankInputsFor(ed);
    const text = await getPageText(ed);
    if (blanks.length) {
      const empty = blanks.filter(el => !(el.value || "").trim());
      if (empty.length) await fillBlanks(empty, text);
      const changed = await solveTemplate(blanks, text);
      if (!changed && empty.length) {
        await blankFinish(empty.map((el, i) => ({ aid: i, el, line: lineTextFor(el), blank: true })), text);
      }
    } else {
      const tabs = findTabs(ed.getBoundingClientRect());
      if (tabs.length >= 2) await solveMultiKeyed(tabs, text);
      else await solveCode(text);
    }
  }

  async function collectItems() {
    const items = [];
    for (const g of collectChoiceGroups()) items.push({ type: "choice", g, el: g.first });
    const eds = allEditors();
    for (let i = 0; i < eds.length; i++) {
      if (!elVisible(eds[i])) continue;
      if (await editorPending(eds[i], i)) items.push({ type: "editor", ed: eds[i], idx: i, el: eds[i] });
    }
    for (const f of candidateFields()) items.push({ type: "field", f, el: f.el });
    items.sort((a, b) => (a.el.compareDocumentPosition(b.el) & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1);
    return items;
  }

  async function runChoices(run) {
    const groups = run.map((it, i) => Object.assign(it.g, { gid: i }));
    setStatus(`لقيت ${groups.length} سؤال اختياري، بيحلها بالترتيب...`);
    groups.forEach(g => solvedSigs.add(g.sig));
    persistSolved();
    let res;
    try {
      res = await ask("ASK_CHOICES", {
        page: scopeText(groups[0].first),
        images: await collectImages(groups[0].first),
        groups: groups.map(g => ({ gid: g.gid, multi: g.multi, question: g.question, options: g.options.map(o => o.text) }))
      });
    } catch (e) { groups.forEach(g => solvedSigs.delete(g.sig)); persistSolved(); throw e; }
    const n = await applyChoices(groups, res.answers);
    setStatus(`تم حل ${n} سؤال اختياري ✓`, "choices", n);
  }

  async function runFields(run) {
    document.querySelectorAll("[data-aid]").forEach(e => e.removeAttribute("data-aid"));
    run.forEach((f, i) => { f.el.setAttribute("data-aid", i); f.el.dataset.esig = f.sig; });
    const fields = run.map((f, i) => ({ aid: i, ...f.info }));
    setStatus(`بيحل ${fields.length} خانة بالترتيب...`);
    let res;
    try { res = await ask("ASK", { fields, page: scopeText(run[0].el), code: "", images: await collectImages(run[0].el) }); }
    catch (e) { run.forEach(f => delete f.el.dataset.esig); throw e; }
    await applyActions(res.actions);
    setStatus(`تم تعبئة ${res.actions.length} خانة ✓`, "fields", res.actions.length);
  }

  // بيعدّي على الصفحة مرة عشان أي أسئلة بتتحمل مع السكرول تظهر
  async function scrollScan() {
    if (scanned.has(location.pathname)) return;
    scanned.add(location.pathname);
    const H = document.documentElement.scrollHeight;
    if (H <= window.innerHeight * 1.3) return;
    setStatus("بيمسح الصفحة عشان ما يفوّتش سؤال...");
    const y0 = window.scrollY;
    for (let y = 0; y < H; y += Math.floor(window.innerHeight * 0.8)) { window.scrollTo(0, y); await sleep(180); }
    window.scrollTo(0, y0);
  }

  // ================= الحلقة الرئيسية =================
  async function solveOnce() {
    if (busy || !running) return;
    if (isExpired()) { stop(); chrome.storage.local.set({ running: false }); setStatus("⚠ مدتك المجانية خلصت، النسخة دي بطلت تحل"); return; }
    busy = true;
    let didWork = false;
    try {
      let items;
      if (isResultPage()) {
        items = await collectItems();
        if (!items.length) { await skipResultPage(); return; } // فعلاً نتيجة: مفيش حاجة تتحل
      }
      await scrollScan();
      items = await collectItems();
      if (!items.length) {
        if ((pageProcessed.get(location.pathname) || 0) > 0 && !doneLogged.has(location.pathname)) {
          doneLogged.add(location.pathname);
          setStatus("خلصت كل أسئلة الصفحة ✓");
        }
        return;
      }
      doneLogged.delete(location.pathname);
      const first = items[0];
      try { first.el.scrollIntoView({ block: "center" }); } catch (e) {}
      await sleep(250);
      didWork = true;

      if (first.type === "choice") {
        const run = [];
        for (const it of items) { if (it.type !== "choice" || run.length >= 6) break; run.push(it); }
        await runChoices(run);
      } else if (first.type === "field") {
        const run = [];
        for (const it of items) { if (it.type !== "field" || run.length >= 10) break; run.push(it); }
        await runFields(run);
      } else {
        await processEditor(first.ed, first.idx);
      }
      pageProcessed.set(location.pathname, (pageProcessed.get(location.pathname) || 0) + 1);
    } catch (e) {
      if (!e.handled) failStop(e.message);
    } finally {
      busy = false;
      if (didWork && running) schedule(800); // كمّل للسؤال اللي بعده بالترتيب
    }
  }

  function schedule(ms) { clearTimeout(debounce); debounce = setTimeout(solveOnce, ms); }

  function start() {
    if (running) return;
    if (isExpired()) {
      chrome.storage.local.set({ running: false });
      setStatus("⚠ مدتك المجانية خلصت، النسخة دي بطلت تحل");
      refreshUI();
      return;
    }
    running = true;
    lastCodeSig = null;
    pathCount.clear(); pageProcessed.clear(); doneLogged.clear(); scanned.clear(); skipSeen.clear();
    document.querySelectorAll("[data-esig]").forEach(e => delete e.dataset.esig);
    observer = new MutationObserver(() => schedule(1500));
    observer.observe(document.documentElement, { childList: true, subtree: true });
    poll = setInterval(() => schedule(0), 4000);
    setStatus("شغال - بيراقب الصفحة");
    refreshUI();
    schedule(300);
  }

  function stop() {
    running = false;
    clearTimeout(debounce);
    if (observer) observer.disconnect();
    observer = null;
    clearInterval(poll);
    setStatus("واقف");
    refreshUI();
  }

  chrome.runtime.onMessage.addListener((m, snd, send) => {
    if (m.type === "GET_TEXT" && IS_TOP) send({ text: exerciseText() });
  });

  chrome.runtime.onMessage.addListener((m, snd, send) => {
    if (m.type === "GET_TEXT" && IS_TOP) send({ text: scopeText() });
  });

  // ================= النافذة العائمة (3X3 Quero Solver) =================
  if (IS_TOP) buildWindow();

  function buildWindow() {
    const host = document.createElement("div");
    host.id = "elattal-root";
    host.style.cssText = "position:fixed;left:0;top:0;z-index:2147483647;";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
<style>
*{box-sizing:border-box;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
#wrap{--o1:#ff9a2e;--o2:#ff6a00;--o3:#e04800;--bg:#0b0b0d;--txt:#fff;--mut:rgba(255,255,255,.6);--line:rgba(255,255,255,.11);--chip:#17171b;--logbg:#101013;--shadow:0 18px 50px rgba(0,0,0,.65)}
#wrap.light{--bg:#fff;--txt:#111;--mut:rgba(0,0,0,.55);--line:rgba(0,0,0,.11);--chip:#f3f3f6;--logbg:#fafafb;--shadow:0 18px 50px rgba(0,0,0,.28)}

.frame{position:relative;width:min(344px,calc(100vw - 24px));border-radius:24px;padding:2px;overflow:hidden;
  background:linear-gradient(135deg,rgba(255,106,0,.65),rgba(255,106,0,.1));box-shadow:var(--shadow);
  animation:pop .5s cubic-bezier(.2,1.4,.4,1)}
.frame::before{content:"";position:absolute;inset:-70%;opacity:0;transition:opacity .5s;
  background:conic-gradient(from 0deg,transparent 0 60%,var(--o2) 80%,#fff 90%,transparent 100%);animation:spin 2.6s linear infinite}
.run .frame::before{opacity:1}
.win{position:relative;background:var(--bg);color:var(--txt);border-radius:22px;overflow:hidden}
.win::after{content:"";position:absolute;inset:0;pointer-events:none;border-radius:22px;
  background:radial-gradient(120% 60% at 100% 0%,rgba(255,106,0,.16),transparent 60%)}

.hdr{display:flex;align-items:center;gap:9px;padding:11px 12px;cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;
  border-bottom:1px solid var(--line);position:relative;z-index:1}
.hdr:active{cursor:grabbing}
.logo{height:26px;width:auto;flex:none;display:block;animation:float 3.4s ease-in-out infinite;filter:drop-shadow(0 3px 8px rgba(255,106,0,.45));pointer-events:none}
.ttl{flex:1;min-width:0;line-height:1.1}
.ttl b{display:block;font-size:14px;font-weight:800;letter-spacing:.03em;white-space:nowrap}
.ttl b em{font-style:normal;color:var(--o2)}
.st{display:flex;align-items:center;gap:6px;margin-top:3px;font-size:9.5px;font-weight:800;letter-spacing:.16em;color:var(--mut)}
.loader{display:grid;grid-template-columns:repeat(3,4px);gap:1.5px;flex:none}
.loader i{width:4px;height:4px;border-radius:1px;background:var(--mut);opacity:.45}
.run .st{color:var(--o2)} .err .st{color:#ef4444}
.busy .loader i{background:var(--o2);opacity:1;animation:wave 1s ease-in-out infinite}
.busy .loader i:nth-child(1){animation-delay:0s}.busy .loader i:nth-child(2),.busy .loader i:nth-child(4){animation-delay:.1s}
.busy .loader i:nth-child(3),.busy .loader i:nth-child(5),.busy .loader i:nth-child(7){animation-delay:.2s}
.busy .loader i:nth-child(6),.busy .loader i:nth-child(8){animation-delay:.3s}.busy .loader i:nth-child(9){animation-delay:.4s}

.ib{width:30px;height:30px;border-radius:10px;border:1px solid var(--line);background:var(--chip);color:var(--txt);font-size:14px;cursor:pointer;
  display:grid;place-items:center;flex:none;padding:0;transition:transform .15s,border-color .2s,color .2s}
.ib:hover{border-color:var(--o2);color:var(--o2);transform:translateY(-1px)}
.ib:active{transform:scale(.9)}

.bar{height:3px;position:relative;overflow:hidden;z-index:1}
.bar i{position:absolute;top:0;bottom:0;left:-40%;width:40%;opacity:0;background:linear-gradient(90deg,transparent,var(--o2),#fff,var(--o2),transparent)}
.busy .bar i{opacity:1;animation:slide 1.1s ease-in-out infinite}

.body{padding:12px;position:relative;z-index:1}
.btns{display:grid;grid-template-columns:1.3fr 1fr;gap:9px}
.btn{position:relative;overflow:hidden;border:0;border-radius:15px;padding:13px 0;font-size:14px;font-weight:800;letter-spacing:.05em;cursor:pointer;
  transition:transform .12s,box-shadow .25s,opacity .2s,background .25s,color .25s}
.btn:active{transform:scale(.96)}
#start{background:linear-gradient(135deg,var(--o1),var(--o2) 55%,var(--o3));color:#fff;box-shadow:0 8px 22px rgba(255,106,0,.45)}
#start::after{content:"";position:absolute;top:0;bottom:0;width:38%;left:-60%;transform:skewX(-20deg);
  background:linear-gradient(100deg,transparent,rgba(255,255,255,.6),transparent);animation:shine 2.8s ease-in-out infinite}
#end{background:transparent;color:var(--txt);border:1.5px solid var(--txt)}
.run #end:not(:disabled){background:var(--txt);color:var(--bg)}
.btn:disabled{opacity:.28;cursor:default;box-shadow:none}
.btn:disabled::after{display:none}

.stats{display:flex;gap:8px;margin:12px 0 10px}
.chip{flex:1;background:var(--chip);border:1px solid var(--line);border-radius:15px;padding:8px 2px;text-align:center;font-size:10px;font-weight:700;color:var(--mut);direction:rtl}
.chip b{display:block;font-size:21px;line-height:1.1;font-weight:800;color:var(--txt)}
.chip.pop{border-color:var(--o2)}
.chip.pop b{animation:numpop .55s cubic-bezier(.2,1.6,.4,1);color:var(--o2)}

.log{height:118px;overflow:auto;background:var(--logbg);border:1px solid var(--line);border-radius:15px;padding:8px 10px;font-size:11.5px;line-height:1.55;scrollbar-width:thin}
.ln{display:flex;gap:7px;padding:1px 0;animation:slideIn .3s ease}
.ln time{opacity:.45;font-size:10px;flex:none;direction:ltr;padding-top:1px;font-variant-numeric:tabular-nums}
.ln span{unicode-bidi:plaintext;word-break:break-word}
.ln.ok span{color:var(--o2);font-weight:700}
.ln.err span{color:#ef4444;font-weight:700}
.ln.info span{opacity:.85}

.set{max-height:0;overflow:hidden;opacity:0;transition:max-height .4s ease,opacity .3s,margin .3s}
.set.open{max-height:400px;opacity:1;margin-top:12px}
.set input[type=password],.set input[type=text]{width:100%;padding:10px 11px;margin-bottom:8px;border-radius:12px;border:1px solid var(--line);
  background:var(--chip);color:var(--txt);font-size:12.5px;outline:none;transition:border-color .2s,box-shadow .2s}
.set input:focus{border-color:var(--o2);box-shadow:0 0 0 3px rgba(255,106,0,.22)}
.set label{display:flex;align-items:center;gap:8px;margin:7px 0;font-size:12px;direction:rtl}
.set label input{accent-color:var(--o2);width:16px;height:16px;flex:none}
#save{width:100%;margin-top:8px;border:0;border-radius:13px;padding:11px;background:linear-gradient(135deg,var(--o1),var(--o3));color:#fff;font-weight:800;font-size:13px;cursor:pointer;transition:transform .12s}
#clear{width:100%;margin-top:7px;border:1px solid var(--line);border-radius:13px;padding:9px;background:transparent;color:var(--txt);font-size:12px;cursor:pointer;transition:border-color .2s}
#save:active,#clear:active{transform:scale(.97)} #clear:hover{border-color:var(--o2)}

.bubble{display:none;position:relative;width:60px;height:60px;border-radius:19px;background:#0b0b0d;padding:6px;cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;
  box-shadow:0 12px 30px rgba(0,0,0,.5),0 0 0 2px var(--o2);animation:pop .45s cubic-bezier(.2,1.4,.4,1)}
.bubble img{width:100%;height:100%;display:block;pointer-events:none}
.bubble .ring{position:absolute;inset:-5px;border-radius:23px;border:2px solid var(--o2);opacity:0;pointer-events:none}
.run .bubble .ring{animation:ring 1.6s ease-out infinite}
.bubble .dot{position:absolute;right:-5px;top:-5px;width:15px;height:15px;border-radius:50%;background:#6b7280;border:2.5px solid #fff}
.run .bubble .dot{background:var(--o2)} .err .bubble .dot{background:#ef4444}
.bubble .cnt{position:absolute;left:-7px;bottom:-7px;min-width:23px;height:23px;border-radius:12px;background:#0b0b0d;color:#fff;font-size:11px;font-weight:800;display:grid;place-items:center;padding:0 6px;border:2px solid var(--o2)}
.mini .frame{display:none}.mini .bubble{display:block}
.flash .frame{animation:flash .9s ease}

@keyframes spin{to{transform:rotate(360deg)}}
@keyframes pop{from{transform:scale(.88);opacity:0}to{transform:scale(1);opacity:1}}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-2px)}}
@keyframes wave{0%,100%{transform:scale(.7);opacity:.5}50%{transform:scale(1.35);opacity:1}}
@keyframes slide{0%{left:-40%}100%{left:100%}}
@keyframes shine{0%,55%{left:-60%}100%{left:130%}}
@keyframes numpop{0%{transform:scale(1)}40%{transform:scale(1.5)}100%{transform:scale(1)}}
@keyframes slideIn{from{transform:translateX(-8px);opacity:0}to{transform:none;opacity:1}}
@keyframes ring{0%{transform:scale(.9);opacity:.9}100%{transform:scale(1.35);opacity:0}}
@keyframes flash{0%{box-shadow:var(--shadow)}35%{box-shadow:0 0 0 4px rgba(255,106,0,.55),0 0 38px rgba(255,106,0,.7)}100%{box-shadow:var(--shadow)}}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
</style>
<div id="wrap" class="dark">
  <div class="frame">
    <div class="win">
      <div class="hdr" id="hdr">
        <img class="logo" src="${E_LOGO}" alt="3X3">
        <div class="ttl"><b><em>Quero</em> Solver</b>
          <div class="st"><span class="loader"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></span><span id="state">IDLE</span></div>
        </div>
        <button class="ib" id="theme" title="theme">◐</button>
        <button class="ib" id="gear" title="settings">⚙</button>
        <button class="ib" id="min" title="minimize">–</button>
      </div>
      <div class="bar"><i></i></div>
      <div class="body">
        <div class="btns"><button class="btn" id="start">▶ Start</button><button class="btn" id="end">■ End</button></div>
        <div class="stats">
          <div class="chip"><b id="s-choices">0</b>اختياري</div>
          <div class="chip"><b id="s-code">0</b>كود</div>
          <div class="chip"><b id="s-fields">0</b>خانات</div>
        </div>
        <div class="log" id="log"></div>
        <div class="set" id="set">
          <input id="key" type="password" placeholder="Gemini API key (AIzaSy... أو AQ....)">
          <label><input type="checkbox" id="autorun"> شغّل الكود تلقائي (Run)</label>
          <label><input type="checkbox" id="autoreview"> راجع الكود حرف حرف قبل الكتابة</label>
          <label><input type="checkbox" id="autosubmit"> اضغط (إجابة) بعد اختيار الإجابة</label>
          <label><input type="checkbox" id="autonext"> اتخطّى صفحات النتيجة تلقائي (التالي)</label>
          <label><input type="checkbox" id="autoreveal"> لو مش متأكد: جرّب ثم اعرض الإجابة واكتبها</label>
          <button id="save">حفظ</button>
          <button id="clear">مسح قائمة اللي اتحل</button>
        </div>
      </div>
    </div>
  </div>
  <div class="bubble" id="bubble"><img src="${E_TILE}" alt="3X3"><div class="ring"></div><div class="dot"></div><div class="cnt" id="bcnt">0</div></div>
</div>`;
    const $ = id => root.getElementById(id);
    const wrap = $("wrap");
    const stats = { choices: 0, code: 0, fields: 0 };
    let minimized = false, hadError = false, busyFlag = false;

    function place(x, y) {
      const w = host.offsetWidth || 60, h = host.offsetHeight || 60;
      x = Math.max(4, Math.min(window.innerWidth - w - 4, x));
      y = Math.max(4, Math.min(window.innerHeight - h - 4, y));
      host.style.left = x + "px"; host.style.top = y + "px";
      return { x, y };
    }
    const savePos = () => chrome.storage.local.set({ epos: { x: parseFloat(host.style.left), y: parseFloat(host.style.top), min: minimized } });

    function drag(handle, onTap, ignoreButtons) {
      let dragging = false, moved = false, sx = 0, sy = 0, ox = 0, oy = 0;
      handle.addEventListener("pointerdown", e => {
        if (ignoreButtons && e.target.closest("button")) return;
        dragging = true; moved = false; sx = e.clientX; sy = e.clientY;
        const r = host.getBoundingClientRect(); ox = r.left; oy = r.top;
        try { handle.setPointerCapture(e.pointerId); } catch (_) {}
      });
      handle.addEventListener("pointermove", e => {
        if (!dragging) return;
        const dx = e.clientX - sx, dy = e.clientY - sy;
        if (Math.abs(dx) + Math.abs(dy) > 6) moved = true;
        if (moved) place(ox + dx, oy + dy);
      });
      handle.addEventListener("pointerup", () => { if (!dragging) return; dragging = false; if (moved) savePos(); else if (onTap) onTap(); });
      handle.addEventListener("pointercancel", () => { dragging = false; });
    }

    function setMin(v) {
      minimized = v;
      wrap.classList.toggle("mini", v);
      const r = host.getBoundingClientRect();
      place(r.left, r.top);
      savePos();
    }
    drag($("hdr"), null, true);
    drag($("bubble"), () => setMin(false), false);
    $("min").onclick = () => setMin(true);

    function paint() {
      wrap.classList.toggle("run", running);
      wrap.classList.toggle("busy", running && busyFlag);
      wrap.classList.toggle("err", hadError && !running);
      $("state").textContent = hadError && !running ? "ERROR" : running ? (busyFlag ? "WORKING" : "RUNNING") : "IDLE";
    }
    refreshUI = () => {
      $("start").disabled = running || isExpired(); $("end").disabled = !running;
      if (running) hadError = false; else busyFlag = false;
      paint();
    };

    function paintStats() {
      for (const k of ["choices", "code", "fields"]) {
        const b = $("s-" + k);
        if (b.textContent !== String(stats[k])) {
          b.textContent = stats[k];
          const chip = b.parentElement;
          chip.classList.remove("pop"); void chip.offsetWidth; chip.classList.add("pop");
          setTimeout(() => chip.classList.remove("pop"), 700);
        }
      }
      $("bcnt").textContent = stats.choices + stats.code + stats.fields;
    }

    const logEl = $("log");
    function addLog(t, k, ts) {
      const d = new Date(ts || Date.now());
      const hh = [d.getHours(), d.getMinutes(), d.getSeconds()].map(n => String(n).padStart(2, "0")).join(":");
      const row = document.createElement("div");
      row.className = "ln " + (k || "info");
      const tm = document.createElement("time"); tm.textContent = hh;
      const sp = document.createElement("span"); sp.textContent = t;
      row.append(tm, sp);
      logEl.appendChild(row);
      while (logEl.children.length > 40) logEl.removeChild(logEl.firstChild);
      logEl.scrollTop = logEl.scrollHeight;
    }

    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== "local" || !ch.estatus || !ch.estatus.newValue) return;
      const s = ch.estatus.newValue;
      addLog(s.t, s.k, s.ts);
      busyFlag = /(\.\.\.|…)"?$/.test(s.t);
      if (s.k === "err") hadError = true;
      if (s.k === "ok") { wrap.classList.add("flash"); setTimeout(() => wrap.classList.remove("flash"), 950); }
      if (s.stat && stats[s.stat] !== undefined) {
        stats[s.stat] += s.n || 1;
        paintStats();
        chrome.storage.local.set({ estatsTop: stats });
      }
      paint();
    });

    function setTheme(t) {
      wrap.classList.toggle("light", t === "light");
      wrap.classList.toggle("dark", t !== "light");
      chrome.storage.local.set({ etheme: t });
    }
    $("theme").onclick = () => setTheme(wrap.classList.contains("light") ? "dark" : "light");

    $("start").onclick = () => { chrome.storage.local.set({ running: true }); start(); };
    $("end").onclick = () => { chrome.storage.local.set({ running: false }); stop(); };
    $("clear").onclick = () => { chrome.storage.local.set({ esolved: [] }); setStatus("تم مسح قائمة اللي اتحل ✓"); };
    $("gear").onclick = () => {
      $("set").classList.toggle("open");
      chrome.storage.sync.get(["apiKey", "autoRunCode", "autoReveal", "autoReview", "autoNext", "autoSubmit"], v => {
        $("key").value = v.apiKey || "";
        $("autorun").checked = v.autoRunCode !== false;
        $("autoreveal").checked = v.autoReveal !== false;
        $("autoreview").checked = v.autoReview !== false;
        $("autonext").checked = v.autoNext !== false;
        $("autosubmit").checked = v.autoSubmit !== false;
      });
    };
    $("save").onclick = () => chrome.storage.sync.set(
      { apiKey: $("key").value.trim(), autoRunCode: $("autorun").checked, autoReveal: $("autoreveal").checked, autoReview: $("autoreview").checked, autoNext: $("autonext").checked, autoSubmit: $("autosubmit").checked },
      () => { setStatus("تم حفظ الإعدادات ✓"); $("set").classList.remove("open"); }
    );

    document.documentElement.appendChild(host);
    chrome.storage.local.get(["epos", "estatsTop", "etheme"], v => {
      if (v.estatsTop) { Object.assign(stats, v.estatsTop); paintStats(); }
      setTheme(v.etheme === "light" ? "light" : "dark");
      const p = v.epos || { x: window.innerWidth - 360, y: 90, min: false };
      minimized = !!p.min;
      wrap.classList.toggle("mini", minimized);
      place(p.x, p.y);
    });
    window.addEventListener("resize", () => { const r = host.getBoundingClientRect(); place(r.left, r.top); });
    if (isExpired()) addLog("⚠ مدتك المجانية خلصت، النسخة دي بطلت تحل", "err");
    else addLog("جاهز. دوس Start", "info");
    refreshUI();
  }

  // ================= مزامنة Start/End =================
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === "local" && ch.esolved && (!ch.esolved.newValue || !ch.esolved.newValue.length)) { solvedSigs.clear(); lastCodeSig = null; }
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === "local" && ch.running) ch.running.newValue ? start() : stop();
  });
  chrome.storage.local.get(["running"], v => { if (v.running) setTimeout(start, 1200); });
})();
