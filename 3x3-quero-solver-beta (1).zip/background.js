const SYS_FIELDS = `You are an expert tutor answering quiz questions and fill-in-the-blank code exercises on a web page.
You get the exercise page text, the code currently in the editor, and a list of form fields (with context) as JSON, in page order.
A field with "blank": true is a gap INSIDE the code; "line" is the code line it sits in. For such a gap write ONLY the code that goes in the gap so the exercise instructions are satisfied. Write each value exactly as it must be typed: exact spelling and letter case, correct spaces and punctuation, no leading or trailing spaces.
Never explain, never ask for more information: if something is unclear, give your best guess.
Return ONLY a JSON array of actions (no markdown, no prose):
  {"aid": <int>, "action": "check"}                      -> the correct radio/checkbox
  {"aid": <int>, "action": "fill", "value": "..."}       -> text/number/textarea
  {"aid": <int>, "action": "select", "value": "<option text>"}
Rules:
- Radio group: choose exactly one. Checkbox group: check every correct one.
- For fill-in-the-blank inputs that sit inside a sentence or a line of code, write ONLY the missing part, never the whole line.
- If unsure, still give your single best answer.
- Answer in the language the question is written in.`;

const SYS_CHOICES = `You are an expert tutor answering multiple-choice questions from an online course page.
You get the page text for context and a JSON list of questions. Each has: gid, multi (true if several answers may be correct), question (its text including the stem), options (array of strings, 0-based).
Think carefully about each question and use the page text when it contains the relevant lesson.
Return ONLY a JSON array, no markdown: [{"gid":0,"pick":[1]}, ...]
- If multi is false, pick exactly one index.
- If multi is true, pick every correct index.
- Always answer every question, even if unsure (give your best guess).
- EXCEPTION: if an item is clearly not a real question (navigation menu, toolbar, tabs, decoration, a list of facts), return an empty pick: {"gid":N,"pick":[]}.`;

const SYS_BLANKS = `After the learner clicked "show answer" on a fill-in-the-blank code exercise, you get the exercise text, the text that newly appeared, and a list of blanks (aid, line = code line containing the gap, current = what was typed).
Return ONLY a JSON array [{"aid":0,"value":"exact text that goes into the gap"}, ...] with the correct value for every blank. No prose, no markdown.`;

const SYS_REVIEW = `You are a meticulous code reviewer for an online coding course. You get the exercise text, the starter code, and a proposed final code for the editor.
Check the proposed code character by character against the instructions: identifier spelling and letter case (case-sensitive), spaces, quotes, brackets, semicolons, indentation, and any exact strings, numbers or output the instructions require. Keep starter code that must stay unchanged.
Return ONLY the corrected full code (identical if already correct). Raw code, no markdown fences, no explanation.`;

const SYS_EDITS = `You are an expert programming tutor completing a code exercise inside an editor that holds a template. Some template parts are fixed, some are blank INPUTS (their current values are listed), and some are empty lines or placeholder comments where the learner must type code.
You get the exercise text, the editor code with line numbers ("N| text"), the blank inputs (index, line text, current value), and optionally the result after the last run and/or the revealed model answer.
Return ONLY a JSON object, no markdown, no prose:
{"confidence":"high","edits":[{"line":N,"mode":"replace","code":"..."}],"blanks":[{"index":0,"value":"..."}]}
Rules:
- "replace" overwrites line N entirely: use it for an EMPTY line or placeholder-comment line that must be filled, or to fix a wrong line you wrote earlier. "insert_after" adds new line(s) after line N.
- Never touch template lines that are already correct, and never touch a line that contains a blank input (change blank inputs only through "blanks").
- "code" must carry its own indentation (match the surrounding style) and may contain several lines separated by \n. Exact spelling, letter case, spaces, quotes and semicolons.
- "blanks": only when a blank's current value is empty or wrong; give the correct full value.
- If everything is already complete and correct, return empty arrays.
- Use the exercise text to decide exactly what to write; the program must produce what the exercise asks.`;

const SYS_FILES = `You are an expert web-development tutor completing a multi-file code exercise (for example HTML + CSS + JavaScript tabs) on an online course platform.
You get the exercise page text (and maybe images of the expected result), the starter files, the CURRENT files in the editor tabs, and optionally the result after the last run and/or the revealed model answer.
Return ONLY a JSON object, no markdown, no prose: {"confidence":"high","files":[{"name":"html","code":"..."},{"name":"css","code":"..."}]}
Rules:
- "name" must be exactly one of the provided tab names.
- Include a file ONLY if it must change; its "code" is the COMPLETE final content of that file.
- Keep starter/template parts that must stay and add what is missing. Copy any code, tags, selectors, class names, text and values given in the instructions EXACTLY: spelling, letter case, spaces, quotes, punctuation. Match the starter's indentation and quote style.
- Every CSS selector, class or id you use must exist in the HTML, and the HTML must match what the exercise (or the expected-result image) shows.
- If everything is already correct, return {"confidence":"high","files":[]}.`;

const SYS_CODE = `You are an expert programming tutor solving exercises on an online coding-course platform.
You receive the exercise page text (instructions, hints) and the code currently in the editor.
Rules:
- Copy any code, identifiers, strings or numbers that appear in the instructions EXACTLY, character by character: spaces, quotes, capitalization, punctuation, semicolons. Match the starter code's indentation and quote style.
- Follow the instructions exactly: use the exact names, values, output format and structure requested. Do not add anything the exercise says will come later (e.g. "the call will be entered in the next exercise").
- If the editor already contains starter code, a template or partially written code, KEEP all existing text exactly as it is and only add or complete what is missing. Replace placeholders like ____, ???, ..., /* write here */ or // TODO with the minimal correct code. If a line is partly written, continue it exactly from where it stops instead of rewriting it.
- If the editor already holds code from an earlier step of the same exercise, build on it (keep what is still needed) unless the new instructions say otherwise.
- If the editor is empty, write the full solution. Keep it simple and idiomatic for the language shown. No comments unless asked.
- Output format: the first line must be exactly "CONFIDENCE: high" or "CONFIDENCE: low" (low = you are unsure what the platform expects). Then the full final code for the editor: raw, no markdown fences, no explanation.`;

const SYS_JUDGE = `A learner ran code for a programming exercise. You get the exercise text, the code, and the text that appeared on the page after pressing Run (console output, feedback messages).
Decide if the exercise was solved. Reply with exactly one word: PASS, FAIL or UNKNOWN.`;

const SYS_EXTRACT = `A coding-exercise page revealed the model answer after the learner clicked "show answer".
You get the exercise text, the code currently in the editor, and the text that newly appeared on the page.
Output the complete correct final code for the editor exactly as the answer shows it (merge with the starter template if needed).
Raw code only: no markdown fences, no explanation.`;

const FIXED_MODEL = "gemini-3.5-flash-lite"; // ثابت، مش بيتغيّر من الإعدادات. سريع ومن غير "تفكير" افتراضي (مناسب للمهمة دي أكتر من 3.8-flash)

const REQUEST_TIMEOUT_MS = 45000; // لو جوجل اتأخرت أكتر من كده، نوقف وما نفضلش معلّقين للأبد

async function callClaude(system, content, retry = true) {
  const { apiKey } = await chrome.storage.sync.get(["apiKey"]);
  if (!apiKey) throw new Error("حط الـ API key من زرار ⚙ في اللوحة");
  const m = FIXED_MODEL;
  const ctrl = new AbortController();
  const to = setTimeout(() => ctrl.abort(), REQUEST_TIMEOUT_MS);
  let res;
  try {
    res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${apiKey}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      signal: ctrl.signal,
      body: JSON.stringify({
        systemInstruction: { role: "system", parts: [{ text: system }] },
        contents: [{ role: "user", parts: toParts(content) }],
        // flash-lite افتراضياً من غير "تفكير" (minimal)، وده بالظبط المطلوب هنا: سرعة واستقرار.
        generationConfig: { maxOutputTokens: 8192, thinkingConfig: { thinkingLevel: "minimal" } }
      })
    });
  } catch (e) {
    clearTimeout(to);
    if (e.name === "AbortError") {
      if (retry) return callClaude(system, content, false);
      throw new Error("Gemini متأخر جداً في الرد (timeout)، جرّب تاني");
    }
    throw new Error("فشل الاتصال بـ Gemini: " + e.message);
  }
  clearTimeout(to);
  if (!res.ok) {
    if (retry && [429, 500, 503].includes(res.status)) {
      await new Promise(r => setTimeout(r, 2500));
      return callClaude(system, content, false);
    }
    throw new Error(`API ${res.status}: ${(await res.text()).slice(0, 200)}`);
  }
  const data = await res.json();
  const cand = data.candidates && data.candidates[0];
  if (!cand) throw new Error("Gemini مرجعش رد (ممكن الفلتر الأمني بتاعه يكون منع الرد)");
  const text = (cand.content.parts || []).map(b => b.text || "").join("");
  if (!text.trim()) {
    const reason = cand.finishReason || "unknown";
    throw new Error(`Gemini رجّع رد فاضي (finishReason: ${reason})، جرّب تاني`);
  }
  return text;
}

// بيحوّل (نص + صور data URL) لـ "parts" بشكل Gemini
function withImages(text, images) {
  const blocks = [];
  for (const d of images || []) {
    const m = /^data:(image\/(?:png|jpeg|gif|webp));base64,(.+)$/.exec(d || "");
    if (m) blocks.push({ type: "image", mimeType: m[1], data: m[2] });
  }
  if (!blocks.length) return text;
  return [...blocks, { type: "text", text: "(The images above are from the exercise page, e.g. the expected result or a diagram.)\n\n" + text }];
}
const addText = (content, extra) => Array.isArray(content) ? [...content, { type: "text", text: extra }] : content + extra;

// محتوى داخلي (نص أو مصفوفة أجزاء) -> parts بشكل Gemini (inlineData بدل source.base64)
function toParts(content) {
  if (typeof content === "string") return [{ text: content }];
  return content.map(b => b.type === "image"
    ? { inlineData: { mimeType: b.mimeType, data: b.data } }
    : { text: b.text });
}

const stripFences = t => t.replace(/^\s*```[a-zA-Z]*\n?/, "").replace(/```\s*$/, "").trim();
const reply = (p, send) => p.then(r => send({ ok: true, ...r })).catch(e => send({ ok: false, msg: String(e.message || e) }));

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  switch (msg.type) {
    case "TOP_TEXT":
      chrome.tabs.sendMessage(sender.tab.id, { type: "GET_TEXT" }, { frameId: 0 })
        .then(r => send(r || {})).catch(() => send({}));
      return true;
    case "ASK":
      reply(jsonArray(SYS_FIELDS, withImages(
        `EXERCISE PAGE TEXT:\n${(msg.page || "").slice(0, 3000)}\n\nEDITOR CODE:\n${(msg.code || "").slice(0, 3000)}\n\nFIELDS (JSON):\n${JSON.stringify(msg.fields)}`, msg.images))
        .then(actions => ({ actions })), send);
      return true;
    case "ASK_CHOICES":
      reply(jsonArray(SYS_CHOICES, withImages(`PAGE TEXT:\n${(msg.page || "").slice(0, 3000)}\n\nQUESTIONS:\n${JSON.stringify(msg.groups)}`, msg.images))
        .then(answers => ({ answers })), send);
      return true;
    case "EXTRACT_BLANKS":
      reply(jsonArray(SYS_BLANKS, `EXERCISE:\n${msg.page}\n\nNEWLY REVEALED TEXT:\n${msg.revealed}\n\nBLANKS:\n${JSON.stringify(msg.blanks)}`)
        .then(answers => ({ answers })), send);
      return true;
    case "ASK_CODE":
      reply(callClaude(SYS_CODE, withImages(
        `PAGE TEXT:\n${msg.page}\n\nORIGINAL EDITOR CODE (starter):\n${msg.current}` +
        (msg.prev ? `\n\nPREVIOUS ATTEMPT (FAILED):\n${msg.prev}\n\nWHAT HAPPENED AFTER RUN:\n${msg.feedback}\n\nFix it and return the corrected full code.` : ""), msg.images))
        .then(t => ({ raw: t })), send);
      return true;
    case "ASK_EDITS":
      reply(jsonObject(SYS_EDITS, withImages(
        `EXERCISE:\n${msg.page}\n\nEDITOR CODE (numbered):\n${msg.code}\n\nBLANK INPUTS:\n${JSON.stringify(msg.blanks)}` +
        (msg.feedback ? `\n\nRESULT AFTER LAST RUN:\n${msg.feedback}` : "") +
        (msg.revealed ? `\n\nREVEALED MODEL ANSWER TEXT:\n${msg.revealed}` : ""), msg.images))
        .then(o => ({ edits: o.edits || [], blanks: o.blanks || [] })), send);
      return true;
    case "ASK_FILES": {
      const fmt = fs => (fs || []).map(f => `### TAB: ${f.name}\n${f.code}`).join("\n\n");
      reply(jsonObject(SYS_FILES, withImages(
        `EXERCISE:\n${msg.page}\n\nSTARTER FILES:\n${fmt(msg.starter)}\n\nCURRENT FILES:\n${fmt(msg.files)}\n\nAVAILABLE TAB NAMES: ${(msg.files || []).map(f => f.name).join(", ")}` +
        (msg.feedback ? `\n\nRESULT AFTER LAST RUN:\n${msg.feedback}` : "") +
        (msg.revealed ? `\n\nREVEALED MODEL ANSWER TEXT:\n${msg.revealed}` : ""), msg.images))
        .then(o => ({ files: o.files || [], confidence: o.confidence })), send);
      return true;
    }
    case "FETCH_IMG":
      (async () => {
        try {
          const r = await fetch(msg.url);
          const bl = await r.blob();
          if (!/^image\/(png|jpeg|gif|webp)$/.test(bl.type) || bl.size > 1500000) return send({ ok: false });
          const buf = new Uint8Array(await bl.arrayBuffer());
          let s = "";
          for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
          send({ ok: true, data: `data:${bl.type};base64,${btoa(s)}` });
        } catch (e) { send({ ok: false }); }
      })();
      return true;
    case "REVIEW":
      reply(callClaude(SYS_REVIEW, `EXERCISE:\n${msg.page}\n\nSTARTER CODE:\n${msg.current}\n\nPROPOSED FINAL CODE:\n${msg.code}`)
        .then(t => ({ code: stripFences(t) })), send);
      return true;
    case "JUDGE":
      reply(callClaude(SYS_JUDGE, `EXERCISE:\n${msg.page}\n\nCODE:\n${msg.code}\n\nAFTER RUN:\n${msg.feedback}`)
        .then(t => ({ verdict: (t.match(/PASS|FAIL|UNKNOWN/i) || ["UNKNOWN"])[0].toUpperCase() })), send);
      return true;
    case "EXTRACT":
      reply(callClaude(SYS_EXTRACT, `EXERCISE:\n${msg.page}\n\nCURRENT EDITOR CODE:\n${msg.current}\n\nNEWLY REVEALED TEXT:\n${msg.revealed}`)
        .then(t => ({ code: stripFences(t) })), send);
      return true;
  }
});
