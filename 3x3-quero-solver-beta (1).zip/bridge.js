// بيشتغل في عالم الصفحة نفسها عشان يوصل لمحررات الكود (Monaco / Ace / CodeMirror)
// eid = رقم المحرر (data-eid) عشان لو في أكتر من محرر في الصفحة
(() => {
  function getApi(eid) {
    const root = eid ? document.querySelector('[data-eid="' + eid + '"]') : null;

    // Monaco
    try {
      if (window.monaco && window.monaco.editor && (!root || root.classList.contains("monaco-editor") || root.querySelector(".monaco-editor"))) {
        const eds = window.monaco.editor.getEditors ? window.monaco.editor.getEditors() : [];
        let ed = null;
        if (root) ed = eds.find(e => { const d = e.getDomNode && e.getDomNode(); return d && (d === root || root.contains(d) || d.contains(root)); });
        else ed = eds[0];
        const m = ed ? ed.getModel() : (!root ? window.monaco.editor.getModels()[0] : null);
        if (m) {
          const R = window.monaco.Range;
          return {
            ro: () => { try { return !!ed.getOption(window.monaco.editor.EditorOption.readOnly); } catch (e) { return false; } },
            get: () => m.getValue(),
            set: c => m.setValue(c),
            edit: edits => {
              const ops = [];
              for (const e of edits) {
                const n = e.line;
                if (n < 1 || n > m.getLineCount()) continue;
                const max = m.getLineMaxColumn(n);
                if (e.mode === "insert_after") ops.push({ range: new R(n, max, n, max), text: "\n" + e.code });
                else ops.push({ range: new R(n, 1, n, max), text: e.code });
              }
              m.applyEdits(ops);
            }
          };
        }
      }
    } catch (e) {}

    // Ace
    try {
      const el = root ? (root.classList.contains("ace_editor") ? root : root.querySelector(".ace_editor")) : document.querySelector(".ace_editor");
      if (el) {
        const ed = (el.env && el.env.editor) || (window.ace && window.ace.edit(el));
        if (ed) return {
          ro: () => !!ed.getReadOnly(),
          get: () => ed.getValue(),
          set: c => ed.setValue(c, 1),
          edit: edits => {
            const s = ed.session, R = ed.getSelectionRange().constructor;
            [...edits].sort((a, b) => b.line - a.line).forEach(e => {
              const row = e.line - 1;
              if (row < 0 || row >= s.getLength()) return;
              const len = s.getLine(row).length;
              if (e.mode === "insert_after") s.insert({ row, column: len }, "\n" + e.code);
              else s.replace(new R(row, 0, row, len), e.code);
            });
          }
        };
      }
    } catch (e) {}

    // CodeMirror 5
    try {
      const el = root ? (root.CodeMirror ? root : root.querySelector(".CodeMirror")) : document.querySelector(".CodeMirror");
      if (el && el.CodeMirror) {
        const cm = el.CodeMirror;
        return {
          ro: () => !!cm.getOption("readOnly"),
          get: () => cm.getValue(),
          set: c => cm.setValue(c),
          edit: edits => {
            [...edits].sort((a, b) => b.line - a.line).forEach(e => {
              const l = e.line - 1;
              if (l < 0 || l > cm.lastLine()) return;
              const len = cm.getLine(l).length;
              if (e.mode === "insert_after") cm.replaceRange("\n" + e.code, { line: l, ch: len });
              else cm.replaceRange(e.code, { line: l, ch: 0 }, { line: l, ch: len });
            });
          }
        };
      }
    } catch (e) {}
    return null;
  }

  window.addEventListener("message", ev => {
    if (ev.source !== window || !ev.data || ev.data.type !== "ELATTAL_REQ") return;
    const { id, op, code, edits, eid } = ev.data;
    let res = { ok: false };
    try {
      const api = getApi(eid);
      if (api) {
        if (op === "get") res = { ok: true, code: api.get() };
        else if (op === "info") res = { ok: true, ro: api.ro() };
        else if (op === "edit") { api.edit(edits || []); res = { ok: true }; }
        else { api.set(code); res = { ok: true }; }
      }
    } catch (e) { res = { ok: false, err: String(e) }; }
    window.postMessage({ type: "ELATTAL_RES", id, ...res }, "*");
  });
})();
