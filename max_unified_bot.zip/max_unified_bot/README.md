# Max Unified Bot

نسخة معدلة من محرك Max العامل، مع اختيار الصف والمواد ونظام الاشتراكات ولوحة المالك.

## الإعداد

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

ضع في `.env`:

```env
BOT_TOKEN=توكن_البوت
OWNER_IDS=123456789
```

لأكثر من مالك استخدم فاصلة: `123,456`.

شغّل:

```bash
python bot.py
```

## استخدام المالك

- `/admin` لفتح لوحة الإدارة.
- من لوحة الإدارة أنشئ كود اشتراك وحدد عدد الأيام والاستخدامات.
- المستخدم يرسل `/redeem` ثم الكود.

## التدفق

- `/start` ثم اختيار الصف.
- أولى ثانوي: JavaScript فقط.
- ثانية ثانوي: JavaScript أو Python أو الثقافة المالية أو الكل.
