"""Dependency-free local checks for HamoBot's admission and bundled data."""
import ast
import json
import logging
import pathlib
import threading
import time
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
BOT = ROOT / "bot" / "bot.py"


class AdmissionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        source = BOT.read_text(encoding="utf-8")
        tree = ast.parse(source)
        wanted = {"user_worker_alive", "submit_solve", "solve_active_count",
                  "register_run_session", "close_run_session"}
        nodes = [node for node in tree.body
                 if isinstance(node, ast.FunctionDef) and node.name in wanted]
        cls.ns = {
            "threading": threading,
            "logging": logging,
            "RUN_THREADS": {},
            "RUN_THREADS_LOCK": threading.Lock(),
            "RUN_SESSIONS": {},
            "SOLVE_SLOTS": threading.BoundedSemaphore(2),
            "_safe_run": lambda fn, uid, *args: fn(*args),
        }
        exec(compile(ast.Module(body=nodes, type_ignores=[]), "<admission-test>", "exec"), cls.ns)

    def test_http_session_cleanup(self):
        class DummySession:
            closed = False
            def close(self):
                self.closed = True
        session = DummySession()
        self.ns["register_run_session"](404, session)
        self.ns["close_run_session"](404)
        self.assertTrue(session.closed)
        self.assertNotIn(404, self.ns["RUN_SESSIONS"])

    def test_direct_start_duplicate_and_capacity_rejection(self):
        started = threading.Event()
        release = threading.Event()
        calls = []

        def job(value):
            calls.append(value)
            started.set()
            release.wait(3)

        first = self.ns["submit_solve"](101, job, (1,))
        self.assertIsNotNone(first)
        self.assertTrue(started.wait(1))
        self.assertIsNone(self.ns["submit_solve"](101, job, (2,)))

        second = self.ns["submit_solve"](202, job, (3,))
        self.assertIsNotNone(second)
        deadline = time.time() + 1
        while len(calls) < 2 and time.time() < deadline:
            time.sleep(0.01)
        self.assertEqual(sorted(calls), [1, 3])
        self.assertIsNone(self.ns["submit_solve"](303, job, (4,)))
        self.assertEqual(self.ns["solve_active_count"](), 2)

        release.set()
        first.join(2)
        second.join(2)
        self.assertFalse(first.is_alive())
        self.assertFalse(second.is_alive())
        self.assertEqual(self.ns["solve_active_count"](), 0)

        third = self.ns["submit_solve"](303, lambda: None, ())
        self.assertIsNotNone(third)
        third.join(2)


class ProjectIntegrityTests(unittest.TestCase):
    def test_empty_lecture_list_is_valid_but_malformed_payload_is_not(self):
        source = BOT.read_text(encoding="utf-8")
        tree = ast.parse(source)
        node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "_extract_lectures")
        ns = {}
        exec(compile(ast.Module(body=[node], type_ignores=[]), "<lecture-parser>", "exec"), ns)
        extract = ns["_extract_lectures"]
        self.assertEqual(extract({"lectures": []}), [])
        self.assertEqual(extract({"lectures": [{"id": 1}]}), [{"id": 1}])
        self.assertIsNone(extract({"data": []}))
        self.assertIsNone(extract(None))

    def test_spx_test_does_not_submit_without_a_known_answer(self):
        source = BOT.read_text(encoding="utf-8")
        tree = ast.parse(source)
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "SPXSolver")
        method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "solve_test")
        ns = {"find_spx_answer": lambda *a: None, "match_option": lambda *a: None,
              "time": type("Clock", (), {"sleep": staticmethod(lambda *_: None)})}
        exec(compile(ast.Module(body=[method], type_ignores=[]), "<spx-test>", "exec"), ns)

        class Response:
            status_code = 200
            def json(self):
                return {"data": {"questions": {"9": {"question_text": "unknown"}},
                                 "options": {"9": [{"id": 1}, {"id": 2}]},
                                 "test_questions": [{"id": 4, "question_id": 9}]}}

        class Solver:
            study = answers = None
            def __init__(self): self.calls = []
            def _post(self, path, payload=None): self.calls.append(("POST", path)); return Response()
            def _put(self, path, payload=None): self.calls.append(("PUT", path)); return Response()
            def _get(self, path): self.calls.append(("GET", path)); return {"data": []}

        solver = Solver()
        result = ns["solve_test"](solver, 123)
        self.assertFalse(result["ok"])
        self.assertEqual(result["solved"], 0)
        self.assertEqual([call[1] for call in solver.calls], ["/api/v1/tests/123/start"])

    def test_spx_test_requires_answer_write_and_platform_confirmation(self):
        source = BOT.read_text(encoding="utf-8")
        tree = ast.parse(source)
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "SPXSolver")
        method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "solve_test")
        ns = {"find_spx_answer": lambda *a: "right", "match_option": lambda *a: 7,
              "time": type("Clock", (), {"sleep": staticmethod(lambda *_: None)}),
              "_answer_parallel": lambda: 1,
              "_run_parallel": lambda items, fn, limit, should_stop=None: [fn(i) for i in items]}
        exec(compile(ast.Module(body=[method], type_ignores=[]), "<spx-test>", "exec"), ns)

        class Response:
            status_code = 200
            def json(self):
                return {"data": {"questions": {"9": {"question_text": "known"}},
                                 "options": {"9": [{"id": 7, "text": "right"}]},
                                 "test_questions": [{"id": 4, "question_id": 9}]}}

        class Solver:
            study = answers = None
            def __init__(self): self.calls = []
            def _post(self, path, payload=None): self.calls.append(("POST", path)); return Response()
            def _put(self, path, payload=None): self.calls.append(("PUT", path)); return Response()
            def _get(self, path):
                self.calls.append(("GET", path))
                return {"data": [{"status": "completed", "passed": True, "correct_count": 1}]}

        solver = Solver()
        result = ns["solve_test"](solver, 123)
        self.assertTrue(result["ok"])
        self.assertEqual(result["solved"], 1)
        self.assertEqual([call[0] for call in solver.calls], ["POST", "PUT", "POST", "GET"])

    def test_python_syntax(self):
        ast.parse(BOT.read_text(encoding="utf-8"))

    def test_json_files(self):
        for path in (ROOT / "bot").glob("*.json"):
            with self.subTest(file=path.name):
                json.loads(path.read_text(encoding="utf-8"))

    def test_no_solve_executor_or_queue_capacity(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertNotIn("ThreadPoolExecutor", source)
        self.assertNotIn("SOLVE_QUEUE_LIMIT", source)
        self.assertNotIn("SOLVE_EXECUTOR", source)
        self.assertNotIn("queue.Queue", source)
        tree = ast.parse(source)
        imported_modules = {alias.name for node in ast.walk(tree)
                            if isinstance(node, ast.Import) for alias in node.names}
        self.assertNotIn("queue", imported_modules)

    def test_balance_lookup_is_locked(self):
        tree = ast.parse(BOT.read_text(encoding="utf-8"))
        user_plan = next(node for node in tree.body
                         if isinstance(node, ast.FunctionDef) and node.name == "user_plan")
        self.assertTrue(any(isinstance(decorator, ast.Name) and decorator.id == "_db_locked"
                            for decorator in user_plan.decorator_list))

    def test_three_systems_are_configured(self):
        source = BOT.read_text(encoding="utf-8")
        for key in ('"gov"', '"lugat"', '"azhar"'):
            self.assertIn(key, source)
        self.assertIn('SYSTEM_GRADES = {"lugat": ["g2", "g1"], "gov": ["g2", "g1"], "azhar": ["g1"]}', source)
        self.assertNotIn('بكالوريا', source)

    def test_system_then_grade_screens(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn('"grade_g1":     ("grade", "الصف الأول الثانوي 1️⃣", "success")', source)
        self.assertIn('"grade_g2":     ("grade", "الصف الثاني الثانوي 2️⃣", "success")', source)
        self.assertIn('"cancel":       ("nav", "الغاء ❌", "danger")', source)
        self.assertIn('انت في أنهي نظام؟', source)
        self.assertIn('انت في سنة كام؟', source)
        self.assertNotIn('اختار المسار الدراسي', source)

    def test_auto_solve_runs_all_chapters_of_every_subject(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn('def run_all_subjects(', source)
        self.assertIn('ids = qureo_chapter_ids(course, load_json(', source)
        self.assertNotIn('اختار الفصول اللي عايز تحلها', source)

    def test_free_mode_is_an_admin_toggle(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn('if st.get("free_mode", True):', source)
        self.assertIn('"adm:tog:free_mode"', source)
        self.assertIn('"native_colors", "free_mode")', source)

    def test_qureo_engine_goes_back_to_finish_missing_items(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn("MAX_PASSES", source)
        self.assertIn("def process_chapter(", source)
        self.assertIn("def solve_lectures(", source)

    def test_result_image_is_sent_after_each_platform(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn("def _deliver_result(", source)
        self.assertIn("_deliver_result(cid)", source)
        self.assertIn("_record_result(", source)

    def test_spx_does_not_stop_at_first_stuck_item(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn("def find_next(self, skip_ids=None):", source)
        self.assertIn('"STUCK"', source)
        self.assertIn("final_round", source)

    def test_platform_screenshot_has_fallback_and_limits(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn("def _platform_screenshot(", source)
        self.assertIn("SHOT_SLOTS", source)
        self.assertNotIn("_make_result_image", source)       # ممنوع أي صورة مرسومة/وهمية
        self.assertEqual(source.count("welcome.jpg"), 1)           # ذكر واحد فقط: مسح الملف القديم عند التشغيل
        self.assertNotIn("WELCOME_IMG", source)
        self.assertNotIn("CARD_IMG", source)
        self.assertNotIn("PIL", source)
        self.assertIn("SHOT_CACHE", source)                  # الزرار بيعيد إرسال لقطات حقيقية فقط
        self.assertIn('"last_result"', source)               # جلسة اللقطة بتتمسح بعد الانتهاء

    def test_users_do_not_see_technical_errors(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn("def _friendly_reason(", source)
        self.assertIn("def _diag_owner(", source)
        self.assertIn("رجّع الإجابة الأصلية", source)          # إصلاح الإجابات بيحافظ على الأصلية لو الدرجة ما زادتش

    def test_already_completed_is_success_not_failure(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn("def _is_already_done(", source)
        self.assertIn('return True, "pre"', source)

    def test_no_promo_image_and_live_screenshot_button(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertFalse((ROOT / "bot" / "welcome.jpg").exists())
        self.assertIn("SHOT_SESSIONS", source)
        self.assertIn("لقطة حية من المنصة", source)

    def test_screenshot_can_login_inside_browser_and_never_keeps_password(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn("def _browser_login(", source)
        self.assertIn("def _needs_login(", source)
        self.assertIn('if k != "login"', source)          # الباسورد ما بيتحفظش مع جلسة الزرار

    def test_users_see_only_solved_list_not_error_lists(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn("MAX_ROUNDS", source)
        self.assertNotIn("الباقي محتاج مراجعة (التفاصيل تحت)", source)

    def test_custom_emoji_support_has_fallback(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn('def emo_text(', source)
        self.assertIn('def _strip_icons(', source)
        self.assertIn('icon_custom_emoji_id', source)

    def test_spx_progress_counts_processed_items(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn('max(int(completed or 0), _done_items)', source)
        self.assertIn('submit_res = self._post', source)


    def test_direct_sessions_ignore_proxy_environment(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertNotIn("apihelper.SESSION", source)
        self.assertIn("apihelper.proxy = None", source)
        self.assertIn("session.trust_env = False", source)
        tree = ast.parse(source)
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                  and n.name == "_configure_telegram_direct_session")
        class Session:
            trust_env = True
        class APIHelper:
            proxy = {"https": "http://proxy.invalid"}
            @staticmethod
            def _get_req_session():
                return session
        session = Session()
        ns = {"apihelper": APIHelper, "getattr": getattr, "callable": callable,
              "hasattr": hasattr, "logging": logging}
        exec(compile(ast.Module(body=[fn], type_ignores=[]), "<telegram-session-test>", "exec"), ns)
        self.assertTrue(ns["_configure_telegram_direct_session"]())
        self.assertFalse(session.trust_env)
        self.assertIsNone(APIHelper.proxy)

    def test_token_is_configured_with_env_override(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn('BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()', source)
        self.assertNotIn("DEFAULT_BOT_TOKEN", source)
        self.assertIn("BOT_TOKEN format is invalid", source)

    def test_login_id_and_password_messages_are_deleted(self):
        source = BOT.read_text(encoding="utf-8")
        tree = ast.parse(source)
        names = {n.name for n in tree.body if isinstance(n, ast.FunctionDef)}
        self.assertIn("step_id", names)
        self.assertIn("step_pass", names)
        step_id = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "step_id")
        step_pass = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "step_pass")
        self.assertIn("delete_message", ast.unparse(step_id))
        self.assertIn("delete_message", ast.unparse(step_pass))

    def test_database_path_is_absolute_and_permissions_restricted(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn("USERS_FILE = os.path.join(BASE_DIR, \"users_db.json\")", source)
        self.assertIn("os.chmod(USERS_FILE, 0o600)", source)

    def test_preflight_tool_exists_and_parses(self):
        path = ROOT / "tools" / "preflight.py"
        self.assertTrue(path.is_file())
        ast.parse(path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main(verbosity=2)

class DatabaseSafetyTests(unittest.TestCase):
    def test_corrupt_database_is_preserved_and_startup_fails_closed(self):
        import datetime
        import os
        import shutil
        import tempfile
        source = BOT.read_text(encoding="utf-8")
        tree = ast.parse(source)
        node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "load_db")
        with tempfile.TemporaryDirectory() as tmp:
            db_path = pathlib.Path(tmp) / "users_db.json"
            original = b'{ broken json'
            db_path.write_bytes(original)
            ns = {"USERS_FILE": str(db_path), "os": os, "json": json,
                  "shutil": shutil, "datetime": datetime.datetime, "logging": logging}
            exec(compile(ast.Module(body=[node], type_ignores=[]), "<load-db-test>", "exec"), ns)
            with self.assertRaises(RuntimeError):
                ns["load_db"]()
            self.assertEqual(db_path.read_bytes(), original)
            backups = list(pathlib.Path(tmp).glob("users_db.json.corrupt-*.bak"))
            self.assertEqual(len(backups), 1)
            self.assertEqual(backups[0].read_bytes(), original)

    def test_missing_database_uses_defaults(self):
        import os
        import shutil
        import tempfile
        import datetime
        source = BOT.read_text(encoding="utf-8")
        tree = ast.parse(source)
        node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "load_db")
        with tempfile.TemporaryDirectory() as tmp:
            ns = {"USERS_FILE": str(pathlib.Path(tmp) / "users_db.json"),
                  "os": os, "json": json, "shutil": shutil,
                  "datetime": datetime.datetime, "logging": logging}
            exec(compile(ast.Module(body=[node], type_ignores=[]), "<load-db-test>", "exec"), ns)
            self.assertEqual(ns["load_db"](),
                             {"users": [], "success": 0, "failed": 0, "credits": {}, "banned": {}})
