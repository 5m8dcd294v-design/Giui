#!/usr/bin/env python3
"""Check outbound HTTPS reachability without reading proxy environment variables."""
import socket
import ssl
import time

HOSTS = [
    "api.telegram.org",
    "me-tp.qureo.education",
    "me-portal.qureo.education",
    "egy.app.spx-learning-square.com",
]

ctx = ssl.create_default_context()
for host in HOSTS:
    started = time.monotonic()
    try:
        with socket.create_connection((host, 443), timeout=6) as raw:
            with ctx.wrap_socket(raw, server_hostname=host):
                elapsed = (time.monotonic() - started) * 1000
                print(f"OK   {host}:443 TLS ({elapsed:.0f} ms)")
    except Exception as exc:
        print(f"FAIL {host}:443 {type(exc).__name__}: {exc}")
