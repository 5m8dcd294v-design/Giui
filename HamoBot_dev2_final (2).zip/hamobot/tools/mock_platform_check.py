"""Offline check of the Qureo engine against a local mock platform (no Telegram/Qureo connection).

Simulates: chapter gating (next chapter 403 until earlier tests are Perfect and all lessons done),
lessons that must be done in order, transient 429/503 errors, tests that open only after the
chapter's lessons, and a chapter the platform blocks for good. Run:  python tools/mock_platform_check.py
"""
import os, sys, types as _t
os.environ.setdefault("BOT_TOKEN", "123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")   # توكن وهمي للاختبار فقط
try:
    import telebot  # noqa: F401
except ImportError:                      # بدون مكتبة تيليجرام: نعمل بديل بسيط يكفي للاختبار
    class _D:
        def __init__(self, *a, **k): pass
        def __call__(self, *a, **k): return _D()
        def __getattr__(self, n): return _D()
    class _Bot:
        def __getattr__(self, n):
            if n.endswith("_handler"):
                return lambda *a, **k: (lambda f: f)
            return lambda *a, **k: _D()
    tb = _t.ModuleType("telebot"); tb.TeleBot = lambda *a, **k: _Bot()
    ty = _t.ModuleType("telebot.types")
    class InlineKeyboardButton:
        def __init__(self, text="", url=None, callback_data=None, **kw):
            self.text, self.url, self.callback_data = text, url, callback_data
    class InlineKeyboardMarkup:
        def __init__(self, *a, **k): self.keyboard = []
        def row(self, *b): self.keyboard.append(list(b))
        def add(self, *b, **k): self.keyboard.append(list(b))
    ty.InlineKeyboardButton, ty.InlineKeyboardMarkup = InlineKeyboardButton, InlineKeyboardMarkup
    ty.__getattr__ = lambda name: type(name, (), {"__init__": lambda self, *a, **k: None})
    ah = _t.ModuleType("telebot.apihelper"); ah.proxy = None; ah.SESSION = None
    ah.__getattr__ = lambda name: (lambda *a, **k: None)
    tb.types, tb.apihelper = ty, ah
    sys.modules.update({"telebot": tb, "telebot.types": ty, "telebot.apihelper": ah})
import json, threading, time, re, os, importlib.util, tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import pathlib

import sys

Q, M = 5, 3
class Platform:
    def __init__(self, n, mode):
        self.n, self.mode = n, mode
        self.start = 1000
        self.answers = {}            # qid -> bool correct
        self.lec_done, self.lec_started = set(), set()
        self.flaky_start, self.flaky_comp, self.flaky_ans = set(), set(), set()
        self.hits = 0
        self.lock = threading.Lock()
        self.perm_block = None       # chapter index permanently blocked by platform
        self.hide = False            # GET لا يظهر أن الدرس مكتمل (زي المنصة الحقيقية مع already_completed)
        self.began = set()
    def cid(self, i): return self.start + i
    def qids(self, i): return [self.cid(i)*100 + j for j in range(Q)]
    def lids(self, i): return [self.cid(i)*10 + k for k in range(M)]
    def best(self, i): return sum(1 for q in self.qids(i) if self.answers.get(q))
    def full(self, i): return self.best(i) == Q and all(l in self.lec_done for l in self.lids(i))
    def idx(self, cid): return cid - self.start
    def unlocked(self, i):
        if self.perm_block is not None and i >= self.perm_block: return False
        return all(self.full(j) for j in range(i))
    def test_open(self, i):
        if not self.unlocked(i): return False
        if self.mode == "test_after_lessons":
            return all(l in self.lec_done for l in self.lids(i))
        return True

P = None
class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def _send(self, code, obj=None, cookie=None):
        body = json.dumps(obj if obj is not None else {}).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        if cookie: self.send_header("Set-Cookie", cookie)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers(); self.wfile.write(body)
    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}") if n else {}
    def do_POST(self):
        with P.lock: P.hits += 1
        if self.path.endswith("/oauth2/password-login"):
            self._body(); return self._send(200, {}, "egy_student_access_token=tok123; Path=/")
        self._send(404)
    def do_GET(self):
        with P.lock: P.hits += 1
        m = re.match(r"/api/study/students/chapters/(\d+)$", self.path)
        if m:
            i = P.idx(int(m.group(1)))
            if i not in P.began: return self._send(404)
            return self._send(200, {"best_correct_count": P.best(i), "completed_at": "x" if P.best(i)==Q else None})
        m = re.match(r"/api/study/chapters/(\d+)/test$", self.path)
        if m:
            i = P.idx(int(m.group(1)))
            if not P.test_open(i): return self._send(403)
            return self._send(200, [{"question":{"id":q,"type":"choice","choices":[{"id":q+k} for k in (6,7,8,9)]}} for q in P.qids(i)])
        m = re.match(r"/api/study/chapters/(\d+)$", self.path)
        if m:
            i = P.idx(int(m.group(1)))
            return self._send(200, {"lectures":[{"id":l,"is_completed": (l in P.lec_done) and not P.hide} for l in P.lids(i)]})
        self._send(404)
    def do_PUT(self):
        with P.lock: P.hits += 1
        body = self._body()
        m = re.match(r"/api/study/students/chapters/(\d+)/test$", self.path)
        if m:
            P.began.add(P.idx(int(m.group(1)))); return self._send(200)
        m = re.match(r"/api/study/students/test-questions/(\d+)/answer/choice$", self.path)
        if m:
            q = int(m.group(1)); i = P.idx(q // 100)
            if q in P.flaky_ans:
                P.flaky_ans.discard(q); return self._send(429)
            if not P.test_open(i): return self._send(403)
            P.answers[q] = (body.get("choice_id") == q + 7)
            return self._send(200)
        m = re.match(r"/api/study/students/lectures/(\d+)(/complete)?$", self.path)
        if m:
            l = int(m.group(1)); i = P.idx(l // 10); k = l % 10
            if not P.unlocked(i): return self._send(403)
            if l in P.lec_done:
                return self._send(400, {"already_completed": True})
            if m.group(2):
                if l in P.flaky_comp:
                    P.flaky_comp.discard(l); return self._send(503)
                if k > 0 and (l-1) not in P.lec_done: return self._send(403)   # الدروس بالترتيب
                if l not in P.lec_started: return self._send(409)
                P.lec_done.add(l); return self._send(200)
            if l in P.flaky_start:
                P.flaky_start.discard(l); return self._send(503)
            P.lec_started.add(l); return self._send(200)
        self._send(404)

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def run(modname, path, scenario):
    global P
    n = scenario.get("n", 10)
    P = Platform(n, scenario.get("mode"))
    # حالة سابقة: الطالب حل بعض الفصول يدويًا وسابها فيها درس ناقص
    for i in range(scenario.get("pre_full", 0)):
        for q in P.qids(i): P.answers[q] = True
        P.began.add(i)
        for l in P.lids(i):
            P.lec_done.add(l); P.lec_started.add(l)
    for (i,k) in scenario.get("leave_lesson", []):
        P.lec_done.discard(P.lids(i)[k])
    if scenario.get("flaky"):
        for i in range(n):
            for k,l in enumerate(P.lids(i)):
                if (i*3+k) % 3 == 0: P.flaky_start.add(l)
                if (i*3+k) % 4 == 1: P.flaky_comp.add(l)
            for j,q in enumerate(P.qids(i)):
                if (i+j) % 4 == 0: P.flaky_ans.add(q)
    P.perm_block = scenario.get("perm_block")
    P.hide = scenario.get("hide_completed", False)
    srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{srv.server_address[1]}"
    tmp = tempfile.mkdtemp(); os.chdir(tmp)
    mod = load(modname, path)
    mod.QUREO_BASE = base; mod.QUREO_PORTAL = base
    jf = os.path.join(tmp, "fake.json")
    bad = set(scenario.get("bad_answers", []))
    chapters = {str(P.cid(i)): {"answers": {str(q): {"answer": (q+9 if (i, j) in bad else q+7), "type":"choice", "verified": (i, j) not in bad}
                                            for j, q in enumerate(P.qids(i))}} for i in range(n)}
    json.dump({"content_id":"fake","chapters":chapters}, open(jf,"w"))
    course = {"kind":"qureo","file":jf,"content_id":"fake","start":P.start,"count":n}
    cid = 555
    mod.USERS[cid] = {"running": True}
    texts = []
    mod.bot.edit_message_text = lambda text, *a, **k: texts.append(text)
    t0 = time.time()
    mod.run_qureo_tool(cid, 1, "123", "pw", course, "Test")
    dt = time.time() - t0
    srv.shutdown()
    done = sum(1 for i in range(n) if P.full(i))
    return done, n, P.hits, dt, texts[-1] if texts else ""

scenarios = {
 "A) طالب حل جزء وسايب درس ناقص في فصل 3": dict(n=10, pre_full=4, leave_lesson=[(2,1)]),
 "B) أخطاء شبكة مؤقتة (503/429) + دروس بالترتيب": dict(n=10, flaky=True),
 "C) الاختبار ما يتفتحش غير بعد إكمال دروس الفصل": dict(n=8, mode="test_after_lessons"),
 "D) فصل 6 مقفول من المنصة نهائيًا": dict(n=10, perm_block=5),
 "F) دروس مكتملة بالفعل بترد 400 already_completed": dict(n=10, pre_full=6, hide_completed=True),
 "E) إجابات محفوظة غلط (غير موثّقة) لازم يصلّحها من درجة المنصة": dict(n=8, bad_answers=[(1, 2), (4, 0), (4, 3)]),
}
BOT = str(pathlib.Path(__file__).resolve().parents[1] / "bot" / "bot.py")
failed = 0
for name, sc in scenarios.items():
    done, n, hits, dt, last = run("hamo_" + str(abs(hash(name)) % 9999), BOT, sc)
    expect = 5 if sc.get("perm_block") is not None else n       # فصل مقفول نهائيًا = المتوقع يقف عنده
    ok = done == expect
    failed += (not ok)
    print(("✅" if ok else "❌"), name, f"— مكتمل {done}/{n} | طلبات {hits} | {dt:.1f}s")
sys.exit(1 if failed else 0)
