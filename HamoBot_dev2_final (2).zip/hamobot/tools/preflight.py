#!/usr/bin/env python3
"""Preflight checks for HamoBot. No credentials are printed and no proxy is used."""
from __future__ import annotations
import importlib.util
import os
import pathlib
import socket
import ssl
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
BOT_DIR = ROOT / "bot"
HOSTS = ("api.telegram.org", "me-tp.qureo.education", "me-portal.qureo.education", "egy.app.spx-learning-square.com")
REQUIRED_FILES = ("bot.py", "requirements.txt", "max.json", "javascript_final_db.json", "study_data.json", "answers_by_level.json")

def report(label: str, ok: bool, detail: str = "") -> bool:
    print(f"{'OK  ' if ok else 'FAIL'} {label}" + (f" — {detail}" if detail else ""))
    return ok

def main() -> int:
    checks = [report("Python version", sys.version_info >= (3, 10), sys.version.split()[0])]
    for module in ("telebot", "requests", "urllib3", "orjson"):
        present = importlib.util.find_spec(module) is not None
        optional = module == "orjson"
        checks.append(report(f"dependency: {module}", present or optional,
                             "optional; standard JSON fallback is used" if optional and not present else ("installed" if present else "install bot/requirements.txt")))
    for filename in REQUIRED_FILES:
        path = BOT_DIR / filename
        checks.append(report(f"file: {filename}", path.is_file(), f"{path.stat().st_size} bytes" if path.is_file() else "missing"))
    source = (BOT_DIR / "bot.py").read_text(encoding="utf-8")
    token = os.getenv("BOT_TOKEN", "").strip()
    token_valid = bool(token) and __import__("re").fullmatch(r"\d{6,12}:[A-Za-z0-9_-]{20,}", token) is not None
    checks.append(report("BOT_TOKEN configured and valid", token_valid, "present (value hidden)" if token_valid else "set a valid BOT_TOKEN in hosting environment"))
    checks.append(report("proxy-independent HTTP configuration", "trust_env = False" in source, "bot sessions ignore inherited proxy variables"))
    try:
        probe = BOT_DIR / ".write_probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        writable = True
    except OSError:
        writable = False
    checks.append(report("bot directory writable", writable, "needed for runtime database and logs"))
    context = ssl.create_default_context()
    for host in HOSTS:
        started = time.monotonic()
        try:
            with socket.create_connection((host, 443), timeout=5) as raw:
                with context.wrap_socket(raw, server_hostname=host):
                    elapsed = (time.monotonic() - started) * 1000
            checks.append(report(f"direct TLS {host}:443", True, f"{elapsed:.0f} ms"))
        except Exception as exc:
            checks.append(report(f"direct TLS {host}:443", False, type(exc).__name__))
    print(f"\nSummary: {sum(checks)}/{len(checks)} checks passed.")
    if any(os.getenv(k) for k in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy")):
        print("Note: proxy variables exist on host; HamoBot sessions are configured not to use them.")
    return 0 if all(checks) else 1

if __name__ == "__main__":
    raise SystemExit(main())
