"""Offline correctness/performance check for the SPX exact-answer index.
Run from the project root: python tools/benchmark_answer_index.py
No Telegram token or network access is needed.
"""
import html
import json
import re
import time
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "bot"


def canon(value):
    if not value:
        return ""
    value = html.unescape(str(value))
    value = re.sub(r"\[\[.*?\]\]", "", value)
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", value)).strip()


study = json.loads((ROOT / "study_data.json").read_text(encoding="utf-8"))
answers = json.loads((ROOT / "answers_by_level.json").read_text(encoding="utf-8"))
exact = {}
fallback = []
for level in (study.get("levels") or {}).values():
    for item in level.get("questions", []):
        question = canon(item.get("question", ""))
        if question and item.get("answer") and question not in exact:
            exact[question] = item["answer"]
for questions in answers.values():
    if isinstance(questions, list):
        for item in questions:
            if isinstance(item, dict) and item.get("answer"):
                prefix = canon(item["answer"])[:30]
                if prefix:
                    fallback.append((prefix, item["answer"]))

queries = [canon(item.get("question", "")) for level in study.get("levels", {}).values()
           for item in level.get("questions", []) if item.get("question")]

# Verify every indexed source question returns the same first exact answer.
for query in queries:
    expected = next((item.get("answer") for level in study.get("levels", {}).values()
                     for item in level.get("questions", [])
                     if canon(item.get("question", "")) == query and item.get("answer")), None)
    actual = exact.get(query)
    if actual != expected:
        raise SystemExit(f"Mismatch for question: {query[:80]!r}")

rounds = 3
start = time.perf_counter()
for _ in range(rounds):
    for query in queries:
        exact.get(query)
indexed_seconds = time.perf_counter() - start

start = time.perf_counter()
for _ in range(rounds):
    for query in queries:
        next((item.get("answer") for level in study.get("levels", {}).values()
              for item in level.get("questions", [])
              if canon(item.get("question", "")) == query), None)
linear_seconds = time.perf_counter() - start

print(f"Verified exact questions: {len(queries)}")
print(f"Indexed lookup: {rounds * len(queries) / max(indexed_seconds, 1e-9):,.0f} lookups/sec")
print(f"Linear lookup:  {rounds * len(queries) / max(linear_seconds, 1e-9):,.0f} lookups/sec")
print(f"Measured speedup: {linear_seconds / max(indexed_seconds, 1e-9):.1f}x")
print("Note: this measures local answer matching only, not Telegram/Qureo throughput.")
