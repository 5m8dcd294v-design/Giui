import telebot
from telebot import types
from telebot import apihelper
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import json
import time
import logging
import os
import re
import unicodedata
import html
import threading
import sys
import shutil
from datetime import datetime
from functools import lru_cache
from urllib.parse import quote, urlparse

try:
    import orjson as _fast_json
except ImportError:
    _fast_json = None

# ==========================================
# ⚙️ الإعدادات
# ==========================================
# لا نخزن التوكن في المصدر. يلزم تعيين BOT_TOKEN في بيئة الاستضافة.
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is missing. Set it in the hosting environment.")
if not re.fullmatch(r"\d{6,12}:[A-Za-z0-9_-]{20,}", BOT_TOKEN):
    raise RuntimeError("BOT_TOKEN format is invalid.")
OWNER_IDS = [7885527604]
OWNER_ID = OWNER_IDS[0]
# لا تُخفِ علاقات الصلاحيات عن أصحابها؛ قائمة المالكين تُدار مركزيًا.


def is_owner(uid):
    try:
        return int(uid) in OWNER_IDS
    except Exception:
        return False


OWNER_USERNAME = "@Hamo_fun"
OWNER_USERNAME_TG = "Hamo_fun" # يوزر التواصل

CHANNEL_USERNAME = ""      # مفيش قناة اشتراك

BASE = "https://egy.app.spx-learning-square.com"
SUBJECT = 7
QUREO_BASE = "https://me-tp.qureo.education"
QUREO_PORTAL = "https://me-portal.qureo.education"

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO").upper(),
                    format="%(asctime)s [%(levelname)s] %(message)s")

class _SecretRedactionFilter(logging.Filter):
    def filter(self, record):
        try:
            message = record.getMessage()
            if BOT_TOKEN and BOT_TOKEN in message:
                record.msg = message.replace(BOT_TOKEN, "[REDACTED_TOKEN]")
                record.args = ()
        except Exception:
            pass
        return True

for _handler in logging.getLogger().handlers:
    _handler.addFilter(_SecretRedactionFilter())


def _bounded_env_int(name, default, minimum, maximum):
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        logging.warning("Invalid %s; using default", name)
        value = default
    return min(maximum, max(minimum, value))


def _bounded_env_float(name, default, minimum, maximum):
    try:
        value = float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        logging.warning("Invalid %s; using default", name)
        value = default
    return min(maximum, max(minimum, value))

# Low-resource hosting: do not create a large TeleBot worker pool at startup.
# معالجات تيليجرام بالتوازي: لو واحد بس، أي رد بطيء بيأخر كل المستخدمين. الافتراضي 16.
BOT_HANDLER_THREADS = _bounded_env_int("BOT_HANDLER_THREADS", 16, 1, 64)
try:
    threading.stack_size(1024 * 1024)      # 1MB لكل خيط بدل 8MB → آلاف الخيوط بذاكرة أقل
except (ValueError, RuntimeError):
    pass


# تجاهل إعدادات البروكسي الموروثة من بيئة الاستضافة في اتصال Telegram.
# pyTelegramBotAPI الأحدث لا يوفّر جلسة عامة ثابتة؛ نستخدم واجهة الجلسة المتاحة ونتوافق مع القديم.
def _configure_telegram_direct_session():
    apihelper.proxy = None
    get_session = getattr(apihelper, "_get_req_session", None)
    if callable(get_session):
        try:
            session = get_session()
        except Exception:
            session = None
        if session is not None and hasattr(session, "trust_env"):
            session.trust_env = False
        # كل thread بيعمل جلسته؛ نغلّف الدالة عشان كل الجلسات الجديدة تتجاهل البروكسي كمان.
        def _no_env_req_session(*a, **k):
            _sess = get_session(*a, **k)
            try:
                _sess.trust_env = False
            except Exception:
                pass
            return _sess
        apihelper._get_req_session = _no_env_req_session
        return True
    old = getattr(apihelper, "SESSION", None)          # نسخ telebot القديمة
    if old is not None and hasattr(old, "trust_env"):
        old.trust_env = False
        return True
    logging.warning("Could not disable inherited proxy environment for Telegram: session API unavailable")
    return False


_configure_telegram_direct_session()
# معالجة التحديثات بعدة خيوط عشان آلاف المستخدمين ما يستناوش بعض؛ لو الاستضافة رفضت الخيوط نرجع للوضع المباشر.
try:
    bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML", threaded=True, num_threads=BOT_HANDLER_THREADS)
    HANDLER_MODE = f"threaded x{BOT_HANDLER_THREADS}"
except Exception as _thread_err:
    logging.warning("Threaded handlers unavailable (%s); falling back to inline handlers", _thread_err)
    bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML", threaded=False)
    HANDLER_MODE = "inline"

def direct_session():
    """جلسة HTTP مباشرة لا تقرأ HTTP(S)_PROXY من متغيرات البيئة."""
    session = requests.Session()
    session.trust_env = False
    return session
USERS = {}
RUN_THREADS = {}  # user_id -> Thread للعمل الجاري فقط
RUN_THREADS_LOCK = threading.Lock()
RUN_SESSIONS = {}  # user_id -> HTTP session للعمل الجاري؛ تُغلق عند انتهاء المهمة

# تنفيذ مباشر بلا طابور: كل طلب مقبول يبدأ في خيط مستقل بعد حجز خانة متاحة.
# لا ننشئ خيطًا إلا بعد حجز خانة متاحة، وإلا نرفض الطلب فورًا.
# بدون طابور: كل طلب مقبول يبدأ فورًا في خيط خاص. الافتراضي 1000 عملية متزامنة (لحد 5000).
# لو الاستضافة ضعيفة (RAM/خيوط) نزّله بمتغير البيئة SOLVE_WORKERS.
SOLVE_WORKERS = _bounded_env_int("SOLVE_WORKERS", 1000, 1, 5000)
# عدد إجابات الاختبار اللي تتبعت بالتوازي جوه الفصل الواحد (يقل تلقائيًا لما المستخدمين يكتروا).
ANSWER_PARALLEL = _bounded_env_int("ANSWER_PARALLEL", 3, 1, 8)
PROGRESS_EDIT_INTERVAL = _bounded_env_float("PROGRESS_EDIT_INTERVAL", 5.0, 3.0, 30.0)
SOLVE_SLOTS = threading.BoundedSemaphore(SOLVE_WORKERS)

def user_worker_alive(uid):
    with RUN_THREADS_LOCK:
        worker = RUN_THREADS.get(uid)
        return bool(worker and worker.is_alive())

def submit_solve(uid, fn, args):
    """Start a dedicated worker now; reject duplicates/full capacity without queuing."""
    with RUN_THREADS_LOCK:
        existing = RUN_THREADS.get(uid)
        if existing is not None and existing.is_alive():
            return None
        if not SOLVE_SLOTS.acquire(blocking=False):
            return None

        def _run():
            try:
                _safe_run(fn, uid, *args)
            finally:
                with RUN_THREADS_LOCK:
                    if RUN_THREADS.get(uid) is threading.current_thread():
                        RUN_THREADS.pop(uid, None)
                SOLVE_SLOTS.release()

        worker = threading.Thread(target=_run, name=f"solve-{uid}", daemon=True)
        RUN_THREADS[uid] = worker
        try:
            worker.start()
        except Exception:
            RUN_THREADS.pop(uid, None)
            SOLVE_SLOTS.release()
            raise
        return worker

def solve_active_count():
    with RUN_THREADS_LOCK:
        return sum(1 for worker in RUN_THREADS.values() if worker.is_alive())

def _run_parallel(items, fn, limit, should_stop=None):
    """ينفذ fn على كل عنصر بعدد محدود من الخيوط ويرجّع النتائج بنفس الترتيب (None = لم يُنفَّذ)."""
    results = [None] * len(items)
    if not items:
        return results
    cursor = [0]
    lock = threading.Lock()

    def _worker():
        while True:
            with lock:
                i = cursor[0]
                cursor[0] += 1
            if i >= len(items) or (should_stop is not None and should_stop()):
                return
            try:
                results[i] = fn(items[i])
            except Exception:
                logging.exception("parallel task failed")
                results[i] = False

    helpers = []
    for _ in range(max(0, min(int(limit), len(items)) - 1)):
        t = threading.Thread(target=_worker, daemon=True)
        try:
            t.start()
        except RuntimeError:      # حد الخيوط في الاستضافة: نكمل بالخيوط الموجودة
            break
        helpers.append(t)
    _worker()
    for t in helpers:
        t.join()
    return results


def _progress_interval():
    """كل ما العمليات الشغالة تزيد نقلل تحديثات رسائل التقدم (حد تيليجرام ≈ 30 تعديل/ث لكل البوت)."""
    try:
        return max(PROGRESS_EDIT_INTERVAL, solve_active_count() / 15.0)
    except Exception:
        return PROGRESS_EDIT_INTERVAL


def _answer_parallel():
    """توازي الإجابات جوه الفصل: كتير لما الحمل خفيف، ويقل لحد 1 لما المستخدمين كتير."""
    try:
        active = solve_active_count()
    except Exception:
        return ANSWER_PARALLEL
    if active <= 20:
        return ANSWER_PARALLEL
    return min(ANSWER_PARALLEL, 2) if active <= 100 else 1


def _is_already_done(res):
    """المنصة بترد 400 {"already_completed": true} لو الدرس/الاختبار متعمل قبل كده = ده نجاح مش فشل."""
    try:
        return (res is not None and res.status_code in (400, 409, 422)
                and "already" in (res.text or "").lower())
    except Exception:
        return False


def _friendly_reason(rec):
    """سبب بسيط للمستخدم (بدون أكواد HTTP أو تفاصيل تقنية)."""
    if rec.get("blocked"):
        return "لسه مقفول من المنصة (محتاج إكمال اللي قبله)"
    n = rec.get("note") or ""
    if "الاختبار" in n:
        return "الاختبار لم يصل لدرجة كاملة"
    if "درس" in n:
        return "فيه درس لم يكتمل"
    if "سؤال" in n:
        return "فيه سؤال محتاج مراجعة"
    return "لم يكتمل"


_DIAG_LAST = [0.0]


def _diag_owner(text):
    """تفاصيل تقنية للمالك بس (مش للمستخدم)، بحد أقصى رسالة كل 20 ثانية عشان ما نغرقش المحادثة."""
    now = time.time()
    if now - _DIAG_LAST[0] < 20:
        return
    _DIAG_LAST[0] = now
    try:
        _to_owners(text[:3500], parse_mode="HTML")
    except Exception:
        logging.exception("owner diagnostic failed")


def free_mode_on():
    """الحل المجاني للكل: بيتفعّل ويتقفل من /admin ← الإعدادات (الافتراضي شغال)."""
    try:
        return bool(DB["settings"].get("free_mode", True))
    except Exception:
        return True


def register_run_session(uid, session):
    with RUN_THREADS_LOCK:
        RUN_SESSIONS[uid] = session

def close_run_session(uid):
    with RUN_THREADS_LOCK:
        session = RUN_SESSIONS.pop(uid, None)
    if session is not None:
        try:
            session.close()
        except Exception:
            logging.exception("Could not close HTTP session for user %s", uid)

# ==========================================
# 💾 حفظ وتحميل المستخدمين والإحصائيات والفرص والحظر
# ==========================================
# يخلّي كل الملفات (max.json وغيره) تتقرا من فولدر البوت مهما كان مكان التشغيل في الاستضافة
try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    os.chdir(BASE_DIR)
except Exception:
    BASE_DIR = os.getcwd()
for _f in ("max.json", "javascript_final_db.json", "study_data.json", "answers_by_level.json"):
    if not os.path.exists(os.path.join(BASE_DIR, _f)):
        print(f"⚠️ ملف ناقص جنب البوت: {_f}  (ارفع فولدر bot كله مش bot.py لوحده)  — المسار: {BASE_DIR}")

USERS_FILE = os.path.join(BASE_DIR, "users_db.json")

def load_db():
    """Load the runtime database without ever silently replacing corrupt data."""
    defaults = {"users": [], "success": 0, "failed": 0, "credits": {}, "banned": {}}
    if not os.path.exists(USERS_FILE):
        return defaults
    try:
        with open(USERS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("database root must be a JSON object")
        for key, value in defaults.items():
            data.setdefault(key, value)
        return data
    except Exception as exc:
        # Keep the original bytes intact and stop startup: silently starting with
        # an empty DB could overwrite user balances, settings, or history.
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = f"{USERS_FILE}.corrupt-{stamp}.bak"
        try:
            shutil.copy2(USERS_FILE, backup)
            logging.critical("Database is unreadable; preserved original at %s", backup)
        except Exception:
            logging.exception("Could not preserve the unreadable database file")
        raise RuntimeError(
            f"Database file {USERS_FILE} is invalid; startup stopped to protect user data. "
            f"Check the file and backup {backup}."
        ) from exc

DB_LOCK = threading.RLock()

def _write_db_now(data):
    """كتابة ذرية فعلية على القرص (tmp ثم replace)."""
    tmp = USERS_FILE + ".tmp"
    try:
        with DB_LOCK:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, USERS_FILE)
            try:
                os.chmod(USERS_FILE, 0o600)
            except OSError:
                logging.warning("Could not restrict permissions on user database")
        return True
    except Exception:
        logging.exception("Could not persist bot database")
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass
        return False


# مع آلاف المستخدمين، كتابة الملف كله + fsync مع كل تغيير بتعطّل كل الخيوط. بنجمّع الحفظ:
# التغييرات بتتسجل في الذاكرة فورًا، والكتابة على القرص بتحصل في خيط خلفي كل ~1 ثانية كحد أقصى.
_SAVE_DIRTY = threading.Event()
_SAVE_STATE = {"data": None, "thread": None}
_SAVE_START_LOCK = threading.Lock()
SAVE_COALESCE_SECONDS = max(0.0, float(os.getenv("DB_SAVE_INTERVAL", "1")))


def _db_writer_loop():
    while True:
        _SAVE_DIRTY.wait()
        time.sleep(SAVE_COALESCE_SECONDS)
        _SAVE_DIRTY.clear()
        data = _SAVE_STATE["data"]
        if data is not None and not _write_db_now(data):
            _SAVE_DIRTY.set()
            time.sleep(0.5)


def save_db(data):
    """حفظ القاعدة: مجمّع وسريع، ومباشر لو الاستضافة رفضت الخيط الخلفي."""
    _SAVE_STATE["data"] = data
    t = _SAVE_STATE["thread"]
    if t is None or not t.is_alive():
        with _SAVE_START_LOCK:
            t = _SAVE_STATE["thread"]
            if t is None or not t.is_alive():
                try:
                    t = threading.Thread(target=_db_writer_loop, name="db-writer", daemon=True)
                    t.start()
                    _SAVE_STATE["thread"] = t
                except Exception:
                    return _write_db_now(data)
    _SAVE_DIRTY.set()
    return True


def flush_db():
    """يكتب القاعدة فورًا (قبل النسخ الاحتياطي وعند الإغلاق)."""
    data = _SAVE_STATE["data"]
    if data is None:
        return True
    _SAVE_DIRTY.clear()
    return _write_db_now(data)


import atexit
atexit.register(flush_db)

DB = load_db()
DB.setdefault("settings", {})
for _k in ("welcome_default_fid", "welcome_default_key"):          # صورة إعلانية قديمة متخزنة بالـ file_id: تتمسح
    DB["settings"].pop(_k, None)
try:
    os.remove(os.path.join(os.path.dirname(os.path.abspath(__file__)), "welcome.jpg"))
except OSError:
    pass
DB["settings"].setdefault("channel", CHANNEL_USERNAME)
DB["settings"].setdefault("force_sub", False)        # الاشتراك الإجباري على كل الأزرار
DB["settings"].setdefault("maintenance", False)     # وضع الصيانة
DB["settings"].setdefault("admins", [])             # أدمنز إضافيين
DB["settings"].setdefault("free_trial", True)       # المحاولة المجانية شغالة؟
DB["settings"].setdefault("free_attempts", 1)       # عدد المحاولات المجانية
DB["settings"].setdefault("free_chapters", 3)       # عدد الفصول في كل محاولة مجانية
DB["settings"].setdefault("native_colors", True)    # الأزرار الملونة الأصلية (style)
DB["settings"].setdefault("buy_text", "")           # فاضية = الرسالة الافتراضية
DB["settings"].setdefault("free_mode", True)        # الحل مجاني للكل (الشكل اللي في الواجهة: «الحل مجاني دلوقتي»)
if DB["settings"].get("welcome_media") == {"type": "none"} and not DB["settings"].get("welcome_v3"):
    DB["settings"].pop("welcome_media", None)          # ترحيل: الافتراضي بقى فيديو الترحيب
DB["settings"]["welcome_v3"] = True
DB.setdefault("info", {})        # اسم/يوزر/انضمام/آخر ظهور
DB.setdefault("blocked", {})     # اللي سابوا البوت
DB.setdefault("trial_used", {})  # كام محاولة مجانية استخدمها كل مستخدم
DB.setdefault("vip_until", {})   # تاريخ انتهاء اشتراك VIP المؤقت
DB.setdefault("ustats", {})      # إحصائيات كل مستخدم (محاولات / نجاح) للمسابقة
DB.setdefault("login_failed", 0)  # مرات فشل تسجيل الدخول
DB.setdefault("refs", {})         # بيانات الدعوات: {inviter: {"done": n, "ids": [...]}}
DB.setdefault("ref_by", {})       # مين دعا مين (عشان الصاحب يتحسب مرة واحدة بس)
DB.setdefault("ref_pending", {})  # دعوة مستنية لحد ما الصاحب يشترك في القناة
DB.setdefault("codes", {})        # أكواد التفعيل (لو تم تفعيلها بإصدار لاحق)
DB["settings"].setdefault("contest_text", "")   # نص المسابقة (الأدمن يقدر يغيره)
# إعدادات التزامن أصبحت من متغيرات البيئة؛ لا نستخدم قيمة JSON قديمة لتجاوز حدود الموارد.
DB["settings"]["max_parallel"] = SOLVE_WORKERS


class RunGate:
    """عداد للجلسات التي بدأت التنفيذ فعليًا داخل مجموعة العمال."""
    def __init__(self):
        self.cv = threading.Condition()
        self.active = 0

    def acquire(self, stop, on_wait=None):
        if stop():
            return False
        with self.cv:
            if stop():
                return False
            self.active += 1
            self.cv.notify_all()
            return True

    def release(self):
        with self.cv:
            self.active = max(0, self.active - 1)
            self.cv.notify_all()


RUN_GATE = RunGate()

def is_admin(uid):
    try:
        return is_owner(uid) or int(uid) in [int(x) for x in DB["settings"].get("admins", [])]
    except Exception:
        return False


# ==========================================
# 💎 نظام الاشتراكات والمحاولة المجانية (يتحكم فيه الأدمن من /admin)
# ==========================================
DEFAULT_BUY_TEXT = (
    "⚠️ <b>عذراً يا صديقي!</b>\n\n"
    "لقد استنفدت المحاولة المجانية المتاحة لك.\n"
    "<i>(المحاولة المجانية: حل {chapters} فصول فقط من منصة واحدة)</i>\n\n"
    "💳 <b>متاح شراء الأداة وتفعيل المحاولات فوراً:</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "🐍 بايثون (Qureo): <b>50 ج</b>\n"
    "💰 الثقافة المالية (SPX): <b>50 ج</b>\n"
    "☕ جافا سكريبت (Qureo): <b>50 ج</b>\n\n"
    "🔥 <b>عرض خاص:</b> جافا + الثقافة + بايثون معاً بـ <b>100 ج فقط!</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "📱 رقم الكاش: <code>01130686387</code>\n\n"
    "👇 اضغط على زر <b>OWNER</b> أدناه للتواصل مع المالك وتفعيل حسابك:"
)

DEFAULT_SUB_TEXT = (
    "💳 <b>اشترك وفعّل الأداة فوراً:</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "🐍 بايثون (Qureo): <b>50 ج</b>\n"
    "💰 الثقافة المالية (SPX): <b>50 ج</b>\n"
    "☕ جافا سكريبت (Qureo): <b>50 ج</b>\n\n"
    "🔥 <b>عرض خاص:</b> جافا + الثقافة + بايثون معاً بـ <b>100 ج فقط!</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "📱 رقم الكاش: <code>01130686387</code>\n\n"
    "⬇️ اضغط على زر <b>OWNER</b> أدناه للتواصل مع المالك وتفعيل حسابك:"
)

SUB_CACHE = {}          # uid -> وقت آخر تحقق ناجح (يوفر طلبات get_chat_member)
SUB_CACHE_TTL = 120


def _db_locked(fn):
    """Serialize reads that may also expire or normalize account balances."""
    def _wrapped(*args, **kwargs):
        with DB_LOCK:
            return fn(*args, **kwargs)
    return _wrapped

@_db_locked
def user_plan(cid):
    """
    بيرجّع (النوع, تفاصيل):
      admin  → أدمن (بدون حدود)
      vip    → اشتراك VIP (التفاصيل = وقت الانتهاء أو None لو دائم)
      paid   → عنده فرص مدفوعة (التفاصيل = العدد)
      free   → الحل مجاني للكل (بدون حدود)
      trial  → محاولة مجانية (التفاصيل = عدد الفصول المسموحة)
      none   → مفيش رصيد
    """
    if is_admin(cid):
        return ("admin", None)
    k = str(cid)
    st = DB["settings"]
    cr = DB["credits"].get(k)
    if cr == "max":
        until = DB["vip_until"].get(k)
        if until and until < time.time():            # اشتراك منتهي
            DB["credits"][k] = 0
            DB["vip_until"].pop(k, None)
            save_db(DB)
            cr = 0
        else:
            return ("vip", until)
    if st.get("free_mode", True):                    # الحل مجاني للكل بدون حدود
        return ("free", None)
    if isinstance(cr, int) and cr > 0:
        return ("paid", cr)
    if (cr is None and st.get("free_trial", True)
            and DB["trial_used"].get(k, 0) < int(st.get("free_attempts", 1))):
        return ("trial", int(st.get("free_chapters", 3)))
    return ("none", None)


def consume_attempt(cid, plan):
    with DB_LOCK:
        kind = plan[0]
        k = str(cid)
        if kind == "paid":
            cur = DB["credits"].get(k)
            if isinstance(cur, int) and cur > 0:
                DB["credits"][k] = cur - 1
        elif kind == "trial":
            DB["trial_used"][k] = DB["trial_used"].get(k, 0) + 1
        save_db(DB)


def trial_footer(plan):
    if plan[0] != "trial":
        return ""
    return T("trial_footer", chapters=plan[1])


def plan_text(cid):
    kind, d = user_plan(cid)
    if kind == "admin":
        return "👑 أدمن — بدون حدود"
    if kind == "vip":
        left = ""
        if d:
            days = max(0, int((d - time.time()) // 86400))
            left = f" (باقي {days} يوم)"
        return "💎 اشتراك VIP" + (left if d else " دائم")
    if kind == "free":
        return "🎁 الحل مجاني دلوقتي – حل كل موادك ببلاش"
    if kind == "paid":
        return f"🎟 رصيدك: {d} فرصة"
    if kind == "trial":
        return f"🎁 معاك محاولة مجانية: حل {d} فصول من منصة واحدة"
    return "🔒 مفيش رصيد — تواصل مع المالك للتفعيل"


def show_buy(cid, message_id=None, exhausted=True):
    """exhausted=True: المستخدم خلص رصيده (رسالة «استنفدت»). False: دخل من زر «اشترك» وهو لسه معاه رصيد."""
    n = DB["settings"].get("free_chapters", 3)
    default = DEFAULT_BUY_TEXT if exhausted else DEFAULT_SUB_TEXT
    text = (DB["settings"].get("buy_text") or default).replace("{chapters}", str(n))
    markup = _kbn([BT("buy_owner", url=f"https://t.me/{owner_tg()}")], [BT("buy_stats", "my_stats")])
    if message_id:
        try:
            bot.edit_message_caption(caption=text, chat_id=cid, message_id=message_id,
                                     reply_markup=markup, parse_mode="HTML")
            return
        except Exception:
            pass
    try:
        bot.send_message(cid, text, reply_markup=markup, parse_mode="HTML")
    except Exception:
        pass


def _gate_say(cid, call, text):
    try:
        if call:
            bot.answer_callback_query(call.id, text, show_alert=True)
        else:
            bot.send_message(cid, text)
    except Exception:
        pass


def user_gate(cid, call=None):
    """
    البوابة اللي كل زر ورسالة بتعدّي عليها: حظر ← صيانة ← اشتراك القناة.
    الأدمن بيعدّي دايمًا. True = مسموح.
    """
    if is_admin(cid):
        return True
    if DB["banned"].get(str(cid)):
        _gate_say(cid, call, T("alert_banned"))
        return False
    if DB["settings"].get("maintenance"):
        _gate_say(cid, call, T("alert_maint"))
        return False
    if not check_subscription(cid):
        if call:
            _gate_say(cid, call, T("alert_sub"))
        send_subscribe_msg(cid)
        return False
    return True


# ==========================================
# 🛡️ التحقق من الاشتراك
# ==========================================
def check_subscription(user_id):
    if is_admin(user_id):                       # الأدمن مستثنى
        return True
    if not DB.get("settings", {}).get("force_sub", False):
        return True
    if not DB.get("settings", {}).get("channel", CHANNEL_USERNAME):      # مفيش قناة = مفيش اشتراك إجباري
        return True
    hit = SUB_CACHE.get(int(user_id))
    if hit and time.time() - hit < SUB_CACHE_TTL:
        return True
    channel = DB.get("settings", {}).get("channel", CHANNEL_USERNAME)
    try:
        member = bot.get_chat_member(channel, user_id)
        if member.status in ['creator', 'administrator', 'member']:
            SUB_CACHE[int(user_id)] = time.time()
            return True
    except Exception as e:
        print(f"Sub Check Error: {e}")
    SUB_CACHE.pop(int(user_id), None)
    return False

def send_subscribe_msg(cid):
    channel = DB.get("settings", {}).get("channel", CHANNEL_USERNAME)
    channel_url = "https://t.me/" + channel.lstrip("@")
    markup = _kbn([BT("sub_join", url=channel_url)], [BT("sub_check", "check_sub")])
    try:
        bot.send_message(cid, T("subscribe"), reply_markup=markup, parse_mode="HTML")
    except Exception as e:
        print(f"Error sending subscribe msg: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "check_sub")
def callback_check_sub(call):
    cid = call.message.chat.id
    if check_subscription(cid):
        bot.answer_callback_query(call.id, T("sub_ok"))
        bot.delete_message(cid, call.message.message_id)
        cmd_start_for(cid, call.from_user.first_name, call.message.chat)
    else:
        bot.answer_callback_query(call.id, T("sub_fail"), show_alert=True)

# ==========================================
# 🧹 دوال المطابقة (SPX)
# ==========================================
def canon(t):
    if not t: return ""
    t = html.unescape(str(t))
    t = re.sub(r'\[\[.*?\]\]', '', t)
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', t)).strip()

def norm(t):
    return canon(t).replace(' ', '').replace('"', '').replace("'", '').replace('`', '').lower()

def _build_spx_answer_index(study, answers):
    """Build immutable lookup structures once; preserve source order and matching rules."""
    exact = {}
    fallback = []
    if isinstance(study, dict):
        for lvl in (study.get('levels') or {}).values():
            for item in lvl.get('questions', []):
                q = canon(item.get('question', ''))
                if q and item.get('answer') and q not in exact:
                    exact[q] = item['answer']
    if isinstance(answers, dict):
        for qs in answers.values():
            if isinstance(qs, list):
                for item in qs:
                    if isinstance(item, dict) and item.get('answer'):
                        answer = item['answer']
                        prefix = canon(answer)[:30]
                        if prefix:
                            fallback.append((prefix, answer))
    return exact, tuple(fallback)


def find_spx_answer(question_text, study=None, answers=None):
    study = STUDY_DATA if study is None else study
    answers = ANSWERS_LEVEL if answers is None else answers
    q_clean = canon(question_text)
    # Default shared dataset uses a precomputed O(1) exact-match index.
    if study is STUDY_DATA and answers is ANSWERS_LEVEL:
        exact, fallback = SPX_ANSWER_INDEX
    else:
        exact, fallback = get_spx_answer_index(study, answers)
    answer = exact.get(q_clean)
    if answer:
        return answer
    if len(q_clean) > 20:
        for prefix, candidate in fallback:
            if prefix in q_clean:
                return candidate
    return None

def match_option(options, answer_text, is_spx=True):
    if not answer_text: return None
    ans_clean = norm(answer_text)
    for opt in options:
        txt = opt.get('text', '') if is_spx else opt.get('content', '')
        if norm(txt) == ans_clean: return opt['id']
    for opt in options:
        txt = opt.get('text', '') if is_spx else opt.get('content', '')
        if ans_clean in norm(txt): return opt['id']
    return None

# ==========================================
# 📂 تحميل الملفات
# ==========================================
@lru_cache(maxsize=64)
def _load_json_cached(abs_path, mtime_ns, file_size):
    """Cache parsed course files by path + file signature; edits invalidate automatically."""
    try:
        with open(abs_path, "rb") as f:
            raw = f.read()
        if _fast_json is not None:
            return _fast_json.loads(raw)
        return json.loads(raw.decode("utf-8"))
    except Exception:
        logging.exception("Could not load JSON data file: %s", abs_path)
        return {}


def load_json(path):
    try:
        if not path:
            return {}
        abs_path = os.path.abspath(path)
        stat = os.stat(abs_path)
        return _load_json_cached(abs_path, stat.st_mtime_ns, stat.st_size)
    except FileNotFoundError:
        logging.warning("JSON data file not found: %s", path)
    except Exception:
        logging.exception("JSON data file load failed: %s", path)
    return {}

STUDY_DATA = load_json("study_data.json")
ANSWERS_LEVEL = load_json("answers_by_level.json")
SPX_ANSWER_INDEX = _build_spx_answer_index(STUDY_DATA, ANSWERS_LEVEL)
_SPX_INDEX_CACHE_LOCK = threading.Lock()
_SPX_INDEX_CACHE = {}


def get_spx_answer_index(study, answers):
    """Reuse indexes for other course datasets instead of rebuilding per question."""
    key = (id(study), id(answers))
    with _SPX_INDEX_CACHE_LOCK:
        cached = _SPX_INDEX_CACHE.get(key)
        if cached is not None and cached[0] is study and cached[1] is answers:
            return cached[2]
        index = _build_spx_answer_index(study, answers)
        if len(_SPX_INDEX_CACHE) >= 16:
            _SPX_INDEX_CACHE.pop(next(iter(_SPX_INDEX_CACHE)))
        _SPX_INDEX_CACHE[key] = (study, answers, index)
        return index

# ==========================================
# 🤖 محرك SPX (الثقافة المالية)
# ==========================================
def _extract_lectures(payload):
    """Return the lecture list, including an empty-but-valid list; None means malformed data."""
    if not isinstance(payload, dict):
        return None
    lectures = payload.get("lectures")
    return lectures if isinstance(lectures, list) else None


class SPXSolver:
    def __init__(self, login_id, password, subject=None, study=None, answers=None):
        self.login_id = login_id
        self.password = password
        self.subject = subject or SUBJECT
        self.study = study
        self.answers = answers
        self.s = direct_session()
        retry_policy = Retry(
            total=2, connect=2, read=1, status=1,
            backoff_factor=0.25, status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET", "HEAD", "OPTIONS"}),
            respect_retry_after_header=True,
        )
        adapter = HTTPAdapter(max_retries=retry_policy, pool_connections=6, pool_maxsize=6)
        self.s.mount("https://", adapter)
        self.s.mount("http://", adapter)
        self.s.headers.update({
            "accept": "application/json, text/plain, */*",
            "content-type": "application/json",
            "origin": BASE,
            "referer": f"{BASE}/subjects/{self.subject}/curriculum",
            "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 Chrome/139.0.0.0 Mobile Safari/537.36",
        })
        self.token = None

    def _req(self, method, path, **kw):
        url = path if path.startswith("http") else f"{BASE}{path}"
        # إرسال الإجابات idempotent: نعيده لحد مرتين لو حصل انقطاع/ضغط مؤقت (429/5xx).
        tries = 3 if (str(method).upper() in ("POST", "PUT") and "/answer" in url) else 1
        res = None
        for attempt in range(tries):
            try:
                res = self.s.request(method, url, timeout=(8, 18), **kw)
            except Exception:
                res = None
            if res is not None and res.status_code not in (429, 500, 502, 503, 504):
                return res
            if attempt < tries - 1:
                time.sleep(0.4 * (attempt + 1))
        return res

    def _get(self, path):
        r = self._req("GET", path)
        if r and r.status_code == 200:
            try: return r.json()
            except: return None
        return None

    def _post(self, path, payload=None): return self._req("POST", path, json=payload or {})
    def _put(self, path, payload=None): return self._req("PUT", path, json=payload or {})

    def login(self):
        r = self._post("/api/v1/auth/login", {"login_id": self.login_id, "password": self.password})
        if not r or r.status_code != 200: return False
        try: body = r.json()
        except: return False
        self.token = body.get("token") or (body.get("data") or {}).get("token")
        if not self.token:
            for c in self.s.cookies:
                if c.name == "learning_token":
                    self.token = c.value
                    break
        if not self.token: return False
        self.s.headers["authorization"] = f"Bearer {self.token}"
        return True

    def find_next(self, skip_ids=None):
        """أول عنصر غير مكتمل (بالترتيب) خارج skip_ids. "DONE" = كله مكتمل، "STUCK" = الباقي كله متعثر."""
        cur = self._get(f"/api/v1/subjects/{self.subject}/curriculum")
        if not cur or not isinstance(cur.get('data'), list): return None, 0, 0
        skip_ids = skip_ids or set()
        total, completed, next_item, any_incomplete = 0, 0, None, False
        for unit in cur['data']:
            for item in unit.get('items', []):
                total += 1
                if item.get('is_completed'):
                    completed += 1
                else:
                    any_incomplete = True
                    if not next_item and item.get('id') not in skip_ids:
                        next_item = item
        if total == 0:
            return None, 0, 0
        if next_item:
            return next_item, completed, total
        return ("STUCK" if any_incomplete else "DONE"), completed, total

    def solve_chapter(self, chapter_id):
        d = self._get(f"/api/v1/chapters/{chapter_id}/blocks")
        if not d or 'data' not in d: return {"ok": False, "total": 0, "solved": 0}
        blocks = d['data'].get('blocks', [])
        cleared = set(d['data'].get('chapter', {}).get('cleared_block_ids', []))
        questions = [b for b in blocks if b.get('type') == 'question']
        
        solved = 0
        for q in questions:
            if q['id'] in cleared:
                solved += 1; continue
            for opt in q.get('options', []):
                r = self._post(f"/api/v1/chapters/{chapter_id}/answer", {"block_id": q['id'], "selected_option_id": opt['id'], "hint_used": 0})
                if r and r.status_code == 200:
                    try:
                        ans = r.json().get('data', {})
                        if ans.get('is_correct'): solved += 1; break
                        if ans.get('correct_option_id'):
                            correct_res = self._post(
                                f"/api/v1/chapters/{chapter_id}/answer",
                                {"block_id": q['id'], "selected_option_id": ans['correct_option_id'], "hint_used": 0}
                            )
                            if correct_res and correct_res.status_code == 200:
                                solved += 1
                            break
                    except: pass
        completion = self._post(f"/api/v1/chapters/{chapter_id}/complete")
        complete_ok = bool(completion and completion.status_code in (200, 201, 204))
        # النجاح لا يُسجل لمجرد انتهاء الدالة؛ نتحقق من قراءة جديدة للمنصة (مش قايمة قديمة قبل الحل).
        fresh = self._get(f"/api/v1/chapters/{chapter_id}/blocks")
        if fresh and isinstance(fresh.get('data'), dict):
            cleared = set(fresh['data'].get('chapter', {}).get('cleared_block_ids', []))
        all_cleared = bool(questions) and all(q.get('id') in cleared for q in questions)
        verified = all_cleared or (complete_ok and solved == len(questions) and bool(questions))
        return {"ok": verified, "solved": solved, "total": len(questions)}

    def solve_review(self, review_id):
        r = self._post(f"/api/v1/reviews/{review_id}/complete")
        return {"ok": bool(r and r.status_code in (200, 201, 204)), "solved": 1, "total": 1}

    def solve_test(self, test_id):
        r = self._post(f"/api/v1/tests/{test_id}/start")
        if not r or r.status_code != 200: return {"ok": False, "solved": 0, "total": 0}
        try:
            data = r.json()['data']
            questions_map = data.get('questions', {})
            options_map = data.get('options', {})
            test_questions = data.get('test_questions', [])
        except: return {"ok": False, "solved": 0, "total": 0}
        
        solved = 0
        answers_batch = []
        for tq in test_questions:
            t_id = tq['id']
            q_id = str(tq['question_id'])
            q_text = questions_map.get(q_id, {}).get('question_text', '')
            options = options_map.get(q_id, [])
            if not q_text or not options: continue
            
            ans_text = find_spx_answer(q_text, self.study, self.answers)
            chosen_id = match_option(options, ans_text, True) if ans_text else None
            if chosen_id is None:
                continue
            answers_batch.append((t_id, chosen_id))
            solved += 1
        
        # لا نرسل تسليمًا فارغًا إذا لم نجد إجابات موثوقة في قاعدة البيانات.
        if not answers_batch:
            return {"ok": False, "solved": 0, "total": len(test_questions)}

        def _send(pair):
            t_id, chosen_id = pair
            res = self._put(f"/api/v1/tests/{test_id}/questions/{t_id}/answer",
                            {"selected_option_id": chosen_id})
            return bool(res and res.status_code in (200, 201, 204))

        sent = _run_parallel(answers_batch, _send, _answer_parallel())
        failed_pairs = [pair for pair, ok_ in zip(answers_batch, sent) if not ok_]
        failed_pairs = [pair for pair in failed_pairs if not _send(pair)]     # محاولة تسلسلية أخيرة
        if failed_pairs:
            return {"ok": False, "solved": 0, "total": len(test_questions)}
        
        submit_res = self._post(f"/api/v1/tests/{test_id}/submit")
        if not submit_res or submit_res.status_code not in (200, 201, 202, 204):
            return {"ok": False, "solved": solved, "total": len(test_questions)}
        # تحقق سريع متدرج بدل نوم ثابت؛ نوقف بمجرد ظهور نتيجة مكتملة.
        passed, score = False, 0
        for attempt in range(6):
            h = self._get(f"/api/v1/tests/{test_id}/history")
            if h and isinstance(h.get('data'), list):
                completed_entry = next((e for e in h['data'] if e.get('status') == 'completed'), None)
                if completed_entry is not None:
                    passed = bool(completed_entry.get('passed'))
                    score = completed_entry.get('correct_count', 0)
                    break
            if attempt < 5:
                time.sleep(0.3)
        return {"ok": passed, "solved": score, "total": len(test_questions)}

# ==========================================
# 🐍 محرك Qureo (بايثون + JavaScript)
# ==========================================
def qureo_chapter_ids(course, max_data):
    """إرجاع أرقام الفصول الفعلية بالترتيب المعروض للمستخدم."""
    if course.get("start") and course.get("count"):
        return list(range(int(course["start"]), int(course["start"]) + int(course["count"])))
    return sorted(int(k) for k in max_data.get("chapters", {}) if str(k).isdigit())


# ==========================================
# 🎨 شاشة الحل: التقدم + الفصول المحلولة + الوقت المتبقي + كارت الحساب
# ==========================================
DIAMONDS_PER_CHAPTER = 5          # تقدير: كل فصل = 5 ألماسات (بيتعرض بعلامة «≈» لأنه مش مقروء من المنصة)


def _bar(pct, cells=10):
    full = max(0, min(cells, pct * cells // 100))
    return "▬" * full + "▭" * (cells - full)


def _fmt_eta(sec):
    if sec is None:
        return "جاري الحساب…"
    if sec < 45:
        return "أقل من دقيقة"
    m = int(round(sec / 60.0))
    if m <= 1:
        return "حوالي دقيقة"
    if m == 2:
        return "حوالي دقيقتين"
    if m <= 10:
        return f"حوالي {m} دقائق"
    return f"حوالي {m} دقيقة"


def _quote(text, expandable=False):
    return f"<blockquote{' expandable' if expandable else ''}>{text}</blockquote>"


def _cap_lines(lines, limit=40):
    """بنقصّ القوايم الطويلة عشان رسالة تيليجرام ما تعدّيش 4096 حرف."""
    if len(lines) <= limit:
        return lines
    return [f"… و{len(lines) - limit} قبلهم"] + lines[-limit:]


def _run_kb():
    return _kbn([BT("stop_solve", "stop_run")], [BT("run_back", "n:home")])


def _qp_progress_text(mat, code, done, total, current, solved, review, eta):
    pct = min(100, int(done * 100 / total)) if total else 0
    head = (f"👤 كودك: <code>{html.escape(str(code))}</code>\n"
            f"📊 التقدم: {_bar(pct)} {pct}%\n"
            f"🎯 الآن: {html.escape(str(current))}")
    out = f"{T('running_title', mat=mat)}\n\n{_quote(head)}\n"
    if solved:
        lines = _cap_lines([f"✅ {html.escape(str(n))}" for n in solved])
        out += f"\n✅ <b>المحلولة</b>\n{_quote(chr(10).join(lines), expandable=len(lines) > 6)}\n"
    if review:
        lines = _cap_lines([f"⚠️ {html.escape(str(n))} — {html.escape(str(why))}" for n, why in review], 12)
        out += f"\n⚠️ <b>تحتاج مراجعة</b>\n{_quote(chr(10).join(lines), expandable=len(lines) > 4)}\n"
    out += f"\n{_quote('⏱ الوقت المتبقي: ' + _fmt_eta(eta))}"
    return out


def _qp_final_text(mat, code, done, total, review, stopped, details, trial_extra=""):
    """نتيجة صادقة: «تم الحل» = اللي اتأكد من المنصة بس؛ الباقي بيتعرض تحت «تحتاج مراجعة»."""
    stats = (f"👤 كودك: <code>{html.escape(str(code))}</code>\n"
             f"✅ تم الحل: {done}/{total}\n"
             f"⏳ المتبقي: {max(0, total - done)}\n"
             f"💎 الألماس (تقريباً): {done * DIAMONDS_PER_CHAPTER}")
    if stopped:
        verdict = f"⏹ <b>تم إيقاف الحل</b>\nاكتمل {done} من {total} قبل الإيقاف."
    elif total and done >= total and not review:
        verdict = T("done_title", mat=mat)
    else:
        verdict = f"🔄 <b>اكتمل {done} من {total}</b>\nالباقي هيكمل لما تشغّل الحل تاني."
    out = f"{verdict}\n\n{_quote(stats)}"
    if details:
        out += f"\n\n{_quote(details)}"
    return out + trial_extra


def _final_kb(done, total):
    return _kbn([BT("card_btn", f"card:{int(done)}:{int(total)}")], [BT("run_back", "n:home")])


def _send_account_card(cid, done, total):
    """زر «صورة الإنجاز»: بياخد لقطة حية من المنصة دلوقتي (لو جلسة الحل لسه صالحة)، وإلا بيعيد آخر لقطة
    حقيقية اتاخدت. مفيش صورة بديلة أو مرسومة."""
    kb = _kbn([BT("to_home", "n:home")])
    now = time.time()
    with _SHOT_CACHE_LOCK:
        live = [(plat, v) for plat, v in SHOT_SESSIONS.get(cid, {}).items() if v["exp"] > now][-3:]
        shots = list(SHOT_CACHE.get(cid, []))
    sent = False
    if live:
        try:
            bot.send_chat_action(cid, "upload_photo")
        except Exception:
            pass
    for plat, v in live:
        shot = _platform_screenshot(v["session"])
        if shot is None:
            continue
        try:
            m = bot.send_photo(cid, shot, parse_mode="HTML", reply_markup=kb,
                               caption=f"📸 <b>لقطة حية من المنصة</b> — {html.escape(plat)}\n🕒 {_ts(int(time.time()))}")
            _remember_shot(cid, {"platform": plat, "done": v["done"], "total": v["total"]}, m)
            sent = True
        except Exception as e:
            print(f"Live screenshot send error: {e}")
    if sent:
        return
    for i, sh in enumerate(shots):
        try:
            bot.send_photo(cid, sh["file_id"], parse_mode="HTML",
                           reply_markup=kb if i == len(shots) - 1 else None,
                           caption=(f"📸 <b>آخر لقطة من المنصة</b> — {html.escape(sh['platform'])}\n"
                                    f"🕒 {_ts(sh['ts'])}\n"
                                    + _quote(f"تم الحل ✅: {sh['done']}/{sh['total']}")))
            sent = True
        except Exception as e:
            print(f"Account screenshot resend error: {e}")
    if sent:
        return
    text = (f"{T('qp_account')}\n"
            + _quote(f"تم الحل ✅: {done}/{total}\n"
                     f"المتبقي ⏳: {max(0, total - done)}\n"
                     f"الألماس 💎 (تقريباً): {done * DIAMONDS_PER_CHAPTER}")
            + "\n📸 مقدرش آخد لقطة من المنصة دلوقتي.")
    try:
        bot.send_message(cid, text, reply_markup=kb, parse_mode="HTML")
    except Exception as e:
        print(f"Account card error: {e}")


# ==========================================
# 📸 لقطة شاشة حقيقية من المنصة بعد انتهاء كل منصة (مفيش صور مرسومة ولا وهمية)
# ==========================================
# لقطة شاشة حقيقية من المنصة نفسها (متصفح Chromium بدون واجهة عبر Playwright، اختياري).
# بدون Playwright أو لو فشلت اللقطة بيبعت البوت ملخص نصي بس، ومش بيبعت أي صورة بديلة.
SCREENSHOT_ENABLED = os.getenv("PLATFORM_SCREENSHOT", "1").strip().lower() not in ("0", "false", "no", "off")
SHOT_SLOTS = threading.BoundedSemaphore(_bounded_env_int("SCREENSHOT_CONCURRENCY", 3, 1, 16))
SHOT_TIMEOUT_MS = _bounded_env_int("SCREENSHOT_TIMEOUT_MS", 25000, 8000, 90000)
_SHOT_UA = ("Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/139.0.0.0 Mobile Safari/537.36")


def _needs_login(page):
    try:
        if any(k in page.url.lower() for k in ("login", "signin", "sign-in", "/auth")):
            return True
        pw = page.query_selector("input[type=password]")
        return bool(pw and pw.is_visible())
    except Exception:
        return False


def _browser_login(page, login):
    """دخول من جوه المتصفح بنفس طريقة الطالب (كود + كلمة مرور) لو حقن الجلسة ما اتقبلش."""
    for url in login.get("urls") or []:
        try:
            page.goto(url, wait_until="load", timeout=SHOT_TIMEOUT_MS)
        except Exception:
            pass
        page.wait_for_timeout(1500)
        try:
            pw = page.query_selector("input[type=password]")
            user = page.query_selector("input[type=text], input[type=tel], input[type=number], "
                                       "input[type=email], input:not([type])")
            if not pw or not user:
                continue
            user.fill(str(login["id"]))
            pw.fill(str(login["password"]))
            btn = page.query_selector("button[type=submit], input[type=submit]")
            if btn:
                btn.click()
            else:
                pw.press("Enter")
            try:
                page.wait_for_load_state("networkidle", timeout=10000)
            except Exception:
                pass
            page.wait_for_timeout(1500)
            if not _needs_login(page):
                return True
        except Exception:
            continue
    return False


def _platform_screenshot(sess):
    """يفتح صفحة المنصة بجلسة الطالب ويصوّرها. يرجّع BytesIO أو None (ولا يرمي أخطاء).
    الترتيب: (1) حقن الجلسة، (2) لو اترمينا على صفحة الدخول: دخول من جوه المتصفح، وبعدها نجرب كل رابط."""
    urls = [u for u in ((sess or {}).get("urls") or [(sess or {}).get("url")]) if u]
    if not SCREENSHOT_ENABLED or not sess or not urls or not (sess.get("cookies") or sess.get("login")):
        return None
    try:
        from playwright.sync_api import sync_playwright
        import io
    except Exception:
        return None                              # Playwright مش متثبت
    if not SHOT_SLOTS.acquire(timeout=90):       # ننتظر دور اللقطة (متصفح تقيل) بدل ما نرفض
        return None
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"])
            try:
                ctx = browser.new_context(viewport={"width": 430, "height": 932}, device_scale_factor=2,
                                          locale="ar-EG", user_agent=_SHOT_UA)
                if sess.get("cookies"):
                    ctx.add_cookies([{"name": c["name"], "value": c["value"], "domain": c["domain"],
                                      "path": "/", "secure": c.get("secure", True)} for c in sess["cookies"]])
                for key, val in (sess.get("local_storage") or {}).items():
                    ctx.add_init_script(f"try{{localStorage.setItem({json.dumps(key)},{json.dumps(val)})}}catch(e){{}}")
                page = ctx.new_page()
                logged_in_by_form = False
                for url in urls:
                    try:
                        page.goto(url, wait_until="load", timeout=SHOT_TIMEOUT_MS)
                    except Exception:
                        pass                      # الصفحة ممكن تفضل تحمّل؛ نصوّر اللي ظهر
                    page.wait_for_timeout(2000)
                    if _needs_login(page) and sess.get("login") and not logged_in_by_form:
                        logged_in_by_form = True
                        if _browser_login(page, sess["login"]):
                            try:
                                page.goto(url, wait_until="load", timeout=SHOT_TIMEOUT_MS)
                            except Exception:
                                pass
                            page.wait_for_timeout(2000)
                    if _needs_login(page):
                        continue                  # لسه صفحة دخول → نجرب الرابط اللي بعده
                    for _ in range(6):            # نستنى الصفحة (SPA) تتعرض بمحتوى فعلي
                        try:
                            if len(page.inner_text("body").strip()) > 20:
                                break
                        except Exception:
                            pass
                        page.wait_for_timeout(1000)
                    out = io.BytesIO(page.screenshot(type="png"))
                    out.name = "platform.png"
                    return out
                return None
            finally:
                browser.close()
    except Exception:
        logging.exception("Platform screenshot failed")
        return None
    finally:
        SHOT_SLOTS.release()


def _record_result(cid, platform, done, total, secs, lessons=0, review=0, stopped=False, session=None):
    """يحفظ ملخص آخر منصة اتحلت عشان يتبعت كصورة بعد انتهائها (الأرقام اللي المنصة أكدتها بس)."""
    try:
        USERS.setdefault(cid, {})["last_result"] = {
            "platform": str(platform), "done": int(done), "total": int(total), "secs": int(secs),
            "lessons": int(lessons), "review": int(review), "stopped": bool(stopped),
            "session": session,
        }
    except Exception:
        logging.exception("Could not record result for %s", cid)


SHOT_SESSIONS = {}       # cid -> {platform: {"session": {...}, "exp": ts}}  (في الذاكرة فقط، ينتهي بسرعة)
SHOT_SESSION_TTL = _bounded_env_int("SHOT_SESSION_TTL", 1800, 60, 7200)
SHOT_CACHE = {}          # cid -> [{"platform","file_id","ts","done","total"}] (لقطات حقيقية اتبعتت قبل كده)
_SHOT_CACHE_LOCK = threading.Lock()


def _remember_shot(cid, res, msg):
    try:
        fid = msg.photo[-1].file_id
    except Exception:
        return
    with _SHOT_CACHE_LOCK:
        items = [x for x in SHOT_CACHE.get(cid, []) if x["platform"] != res["platform"]]
        items.append({"platform": res["platform"], "file_id": fid, "ts": int(time.time()),
                      "done": res["done"], "total": res["total"]})
        SHOT_CACHE[cid] = items[-3:]
        while len(SHOT_CACHE) > 20000:            # سقف للذاكرة
            SHOT_CACHE.pop(next(iter(SHOT_CACHE)))


def _keep_shot_session(cid, res):
    """نحتفظ بجلسة اللقطة (توكن فقط، مش الباسورد) في الذاكرة دقايق عشان زر «صورة الإنجاز» ياخد لقطة حية."""
    sess = res.get("session")
    if not sess:
        return
    sess = {k: v for k, v in sess.items() if k != "login"}     # الباسورد ما يتحفظش بعد الحل
    if not sess.get("cookies"):
        return
    now = time.time()
    with _SHOT_CACHE_LOCK:
        for k in [k for k, v in SHOT_SESSIONS.items() if all(x["exp"] < now for x in v.values())]:
            SHOT_SESSIONS.pop(k, None)
        SHOT_SESSIONS.setdefault(cid, {})[res["platform"]] = {"session": sess, "exp": now + SHOT_SESSION_TTL,
                                                               "done": res["done"], "total": res["total"]}


def _deliver_result(cid):
    """بعد ما كل منصة تخلص: لقطة حقيقية من المنصة + ملخص. (لا تتبعت لو العملية اتوقفت أو مفيش فصل اتأكد.)"""
    res = USERS.get(cid, {}).pop("last_result", None)
    if not res or res.get("stopped") or res.get("done", 0) <= 0:
        return
    _keep_shot_session(cid, res)
    status = "✅ <b>اتحلت بالكامل</b>" if (res["done"] >= res["total"] and not res["review"]) else \
             f"⚠️ <b>اكتمل {res['done']} من {res['total']}</b>"
    summary = (_quote(f"📚 فصول مكتملة: {res['done']}/{res['total']}\n"
                      f"⏱ الوقت: {res['secs']} ثانية"))
    kb = _kbn([BT("to_home", "n:home")])
    try:
        shot = _platform_screenshot(res.get("session"))
        if shot is not None:
            m = bot.send_photo(cid, shot, reply_markup=kb, parse_mode="HTML",
                               caption=f"📸 <b>لقطة من المنصة بعد الحل</b> — {html.escape(res['platform'])}\n{status}\n{summary}")
            _remember_shot(cid, res, m)
            return
    except Exception:
        logging.exception("Could not send platform screenshot to %s", cid)
    # لا توجد لقطة حقيقية: ملخص نصي فقط (بدون أي صورة بديلة).
    try:
        bot.send_message(cid, f"🏁 <b>{html.escape(res['platform'])}</b>\n{status}\n{summary}",
                         reply_markup=kb, parse_mode="HTML")
    except Exception:
        logging.exception("Could not send result summary to %s", cid)


def parse_chapter_selection(raw, total):
    """تحويل إدخال مثل 1-5، 8، 10-12 إلى أرقام فصول (1-based)."""
    value = (raw or "").strip().lower()
    if value in {"الكل", "كل", "all", "*", "0"}:
        return list(range(1, total + 1))
    digit_map = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
    value = value.translate(digit_map)
    value = value.replace("،", ",").replace("؛", ",").replace("–", "-").replace("—", "-")
    parts = [part.strip() for part in value.split(",") if part.strip()]
    if not parts:
        raise ValueError("اكتب أرقام الفصول أو كلمة الكل.")
    selected = set()
    for part in parts:
        match = re.fullmatch(r"(\d+)\s*(?:-\s*(\d+))?", part)
        if not match:
            raise ValueError("صيغة غير صحيحة. مثال: 1-5، 8، 10-12")
        first = int(match.group(1))
        last = int(match.group(2) or first)
        if first < 1 or last < first or last > total:
            raise ValueError(f"أرقام الفصول لازم تكون من 1 إلى {total}.")
        selected.update(range(first, last + 1))
    return sorted(selected)


def run_qureo_tool(cid_tg, message_id, STUDENT_ID, PASSWORD, course, platform_name, selected_chapters=None):
    _started_at = time.monotonic()
    json_file = course["file"]
    _plan = user_plan(cid_tg)
    _limit = _plan[1] if _plan[0] == "trial" else None   # محاولة مجانية = عدد فصول محدود
    max_data = load_json(json_file)
    # رقم الكورس: من الملف نفسه لو موجود، وإلا من سجل المواد
    content_id = (max_data.get("content_id") or (max_data.get("section") or {}).get("course_id")
                  or course.get("content_id"))
    if not max_data:
        try: bot.edit_message_text(f"❌ ملف {json_file} مش موجود!", cid_tg, message_id)
        except: pass
        return

    try: bot.edit_message_text(f"⏳ جاري تسجيل الدخول لـ {platform_name}...", cid_tg, message_id)
    except: pass

    s = direct_session()
    register_run_session(cid_tg, s)
    # إعادة المحاولة للقراءات فقط؛ لا نكرر إرسال إجابة PUT/POST تلقائيًا.
    retry_policy = Retry(
        total=3, connect=3, read=2, status=2,
        backoff_factor=0.35,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset({"GET", "HEAD", "OPTIONS"}),
        respect_retry_after_header=True,
    )
    adapter = HTTPAdapter(max_retries=retry_policy, pool_connections=8, pool_maxsize=8)
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    _orig_req = s.request
    def _raw_request(method, url, **kw):
        kw.setdefault("timeout", (12, 35))
        return _orig_req(method, url, **kw)
    s.request = _raw_request
    s.headers.update({
        "authority": "me-tp.qureo.education",
        "content-type": "application/json",
        "origin": QUREO_BASE,
        "referer": f"{QUREO_BASE}/",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/139.0.0.0 Safari/537.36"
    })
    lh = s.headers.copy()
    lh["origin"] = QUREO_PORTAL
    lh["referer"] = f"{QUREO_PORTAL}/"

    def _login_again():
        """تجديد الجلسة عند انتهاء التوكن؛ لا يعيد أي عملية كتابة تلقائيًا."""
        try:
            s.cookies.clear()
            rlogin = _raw_request(
                "POST", f"{QUREO_PORTAL}/oauth2/password-login",
                json={"student_id": STUDENT_ID, "password": PASSWORD}, headers=lh,
                timeout=(12, 35)
            )
            if rlogin.status_code != 200:
                return False
            fresh = s.cookies.get("egy_student_access_token")
            if not fresh:
                return False
            s.headers["authorization"] = f"Bearer {fresh}"
            s.cookies.set("student_selected_content_id", content_id, domain="me-tp.qureo.education")
            if _current_chapter[0] is not None:
                s.cookies.set("_cf_s_path", f"/contents/chapter/{_current_chapter[0]}", domain="me-tp.qureo.education")
            return True
        except Exception:
            return False

    _current_chapter = [None]
    _refreshing = [False]
    _relogin_count = [0]
    def _authenticated_request(method, url, **kw):
        kw.setdefault("timeout", (12, 35))
        response = _raw_request(method, url, **kw)
        if response.status_code == 401 and not _refreshing[0] and _relogin_count[0] < 3:
            _refreshing[0] = True
            _relogin_count[0] += 1
            try:
                refreshed = _login_again()
            finally:
                _refreshing[0] = False
            # إعادة GET فقط؛ إعادة PUT/POST قد تكرر إجابة أو عملية على المنصة.
            if refreshed and str(method).upper() in {"GET", "HEAD", "OPTIONS"}:
                response = _raw_request(method, url, **kw)
        return response

    try:
        r = _raw_request("POST", f"{QUREO_PORTAL}/oauth2/password-login",
                         json={"student_id": STUDENT_ID, "password": PASSWORD}, headers=lh)
        _login_code = r.status_code
    except requests.Timeout:
        _login_code = "timeout"
    except requests.ConnectionError:
        _login_code = "connection"
    except Exception:
        _login_code = "unknown"
    token = s.cookies.get("egy_student_access_token")

    if not token:
        if _login_code in (400, 401):
            _login_reason = "كود الطالب أو كلمة المرور غير صحيحين. راجع البيانات وحاول مرة تانية."
        elif _login_code == 403:
            _login_reason = "المنصة رفضت تسجيل الدخول لهذا الحساب. تأكد أن الحساب مفعل وأن بياناته صحيحة."
        elif _login_code == 429:
            _login_reason = "محاولات تسجيل الدخول كثيرة حاليًا. استنى شوية وجرب تاني."
        elif isinstance(_login_code, int) and _login_code >= 500:
            _login_reason = "منصة Qureo فيها عطل مؤقت. حاول بعد شوية."
        elif _login_code == "timeout":
            _login_reason = "الاتصال بمنصة Qureo اتأخر وانتهت المهلة. جرّب تاني بعد قليل."
        elif _login_code == "connection":
            _login_reason = "مش قادرين نوصل لمنصة Qureo حاليًا. افحص الإنترنت وحاول تاني."
        else:
            _login_reason = "تعذر تأكيد تسجيل الدخول. راجع البيانات وحاول مرة تانية، ولو استمرت المشكلة تواصل مع الدعم."
        with DB_LOCK:
            DB["login_failed"] = int(DB.get("login_failed", 0) or 0) + 1
            DB["failed"] = int(DB.get("failed", 0) or 0) + 1
            save_db(DB)
        try: bot.edit_message_text(T("login_fail", reason=html.escape(_login_reason)), cid_tg, message_id, parse_mode="HTML")
        except: pass
        return

    s.headers["authorization"] = f"Bearer {token}"
    s.cookies.set("student_selected_content_id", content_id, domain="me-tp.qureo.education")
    s.request = _authenticated_request

    def set_chapter_path(cid):
        _current_chapter[0] = cid
        s.cookies.set("_cf_s_path", f"/contents/chapter/{cid}", domain="me-tp.qureo.education")

    def check_status(cid):
        set_chapter_path(cid)
        try:
            res = s.get(f"{QUREO_BASE}/api/study/students/chapters/{cid}")
            if res.status_code == 200:
                data = res.json()
                best = int(data.get('best_correct_count') or 0)
                return best, bool(data.get('completed_at')), True
            if res.status_code == 404:
                return 0, False, True
            return 0, False, False
        except Exception:
            return 0, False, False

    def _run_was_requested_to_stop():
        # لا نعتبر أي تغيير عارض في running إيقافًا بطلب المستخدم؛
        # الإيقاف لا يُسجل إلا من زر الإيقاف أو أمر إيقاف الأدمن.
        return bool(USERS.get(cid_tg, {}).get("stop_requested", False))

    def _lecture_is_already_complete(lecture):
        """لا نعتبر الدرس مكتملًا إلا لو حالة المنصة صرّحت بذلك صراحةً."""
        if not isinstance(lecture, dict):
            return False
        if lecture.get("is_completed") is True or lecture.get("completed") is True:
            return True
        if lecture.get("completed_at"):
            return True
        return str(lecture.get("status", "")).strip().lower() in {
            "completed", "complete", "done", "finished"
        }

    def _request_succeeded(response):
        return response is not None and response.status_code in (200, 201, 204)

    # ----- أدوات الكتابة على المنصة (إعادة محاولة محدودة لأخطاء الشبكة المؤقتة فقط) -----
    lessons_done_ids = set()   # دروس أكملناها بنجاح في الجولة دي (عشان ما نعيدهاش)
    lecture_new = set()        # دروس البوت أكملها فعلاً
    lecture_pre = set()        # دروس المنصة قالت إنها مكتملة قبل البوت

    def _why(res):
        if res is None:
            return "انقطاع/لا رد"
        detail = ""
        try:
            raw = (res.text or "").strip()
            if raw and not raw.lstrip().startswith("<"):
                detail = ": " + re.sub(r"\s+", " ", raw)[:70]
        except Exception:
            pass
        return f"HTTP {res.status_code}{detail}"

    def _write(method, url, payload, tries=3):
        """PUT/POST مع إعادة محاولة لـ 429/5xx/انقطاع فقط. الطلبات دي idempotent:
        نفس الإجابة أو نفس إكمال الدرس لا يتكرر أثره على المنصة."""
        last = None
        for attempt in range(tries):
            if _run_was_requested_to_stop():
                return last
            try:
                res = s.request(method, url, json=payload)
            except requests.RequestException:
                res = None
            last = res
            code = res.status_code if res is not None else None
            retryable = (res is None or code in (429, 500, 502, 503, 504)
                         or (code == 401 and attempt == 0))
            if not retryable:
                return res
            if attempt < tries - 1:
                delay = 0.4 * (attempt + 1)
                if code == 429:
                    try:
                        delay = min(5.0, max(delay, float(res.headers.get("Retry-After", delay))))
                    except (TypeError, ValueError):
                        pass
                time.sleep(delay)
        return last

    def solve_lectures(cid):
        """يكمّل كل دروس الفصل بالترتيب. الدرس اللي يفشل يتعاد في لفات تانية (ممكن يتفتح بعد اللي قبله)."""
        set_chapter_path(cid)
        out = {"failed": 0, "status": 200, "total": 0, "fails": []}
        if _run_was_requested_to_stop():
            out["status"] = -2
            return out
        try:
            r = s.get(f"{QUREO_BASE}/api/study/chapters/{cid}")
        except requests.RequestException:
            out.update(failed=1, status=0, fails=[("الفصل", "انقطاع/لا رد")])
            return out
        if r.status_code != 200:
            out.update(failed=1, status=r.status_code, fails=[("الفصل", f"HTTP {r.status_code}")])
            return out
        try:
            lectures = _extract_lectures(r.json())
        except (ValueError, TypeError):
            lectures = None
        if lectures is None:
            out.update(failed=1, status=200, fails=[("الفصل", "رد غير مفهوم")])
            return out
        out["total"] = len(lectures)

        pending, malformed = [], 0
        for lec in lectures:
            if not isinstance(lec, dict) or lec.get("id") is None:
                malformed += 1
                continue
            lid = lec["id"]
            if lid in lessons_done_ids:
                continue
            if _lecture_is_already_complete(lec):
                lessons_done_ids.add(lid)
                if lid not in lecture_new:
                    lecture_pre.add(lid)
                continue
            pending.append(lid)

        reasons = {}

        def _do_lecture(lid):
            first = _write("PUT", f"{QUREO_BASE}/api/study/students/lectures/{lid}", {})
            if _is_already_done(first):
                return True, "pre"                  # اتكمل قبل كده على المنصة
            first_code = first.status_code if first is not None else None
            # التجهيز لازم ينجح أو يرد برفض "تحقق/موجود بالفعل"؛ مع 403/5xx ما نبعتش الإكمال.
            if first_code in (200, 201, 204, 400, 409, 422):
                second = _write("PUT", f"{QUREO_BASE}/api/study/students/lectures/{lid}/complete", {})
                if _request_succeeded(second):
                    return True, ""
                if _is_already_done(second):
                    return True, "pre"              # {"already_completed": true}
                return False, f"الإكمال {_why(second)}"
            return False, f"التجهيز {_why(first)}"

        for sweep in range(3):
            if not pending:
                break
            if _run_was_requested_to_stop():
                out["status"] = -2
                return out
            if sweep == 0 and len(pending) > 2:
                # أول لفة بالتوازي للسرعة؛ أي درس رفضته المنصة بسبب الترتيب بيتعاد تسلسليًا بعدها.
                results = _run_parallel(pending, _do_lecture, _answer_parallel(), _run_was_requested_to_stop)
            else:
                results = []
                for lid in pending:
                    if _run_was_requested_to_stop():
                        break
                    results.append(_do_lecture(lid))
                results += [None] * (len(pending) - len(results))
            still, progressed = [], False
            for lid, res in zip(pending, results):
                if res is None:
                    still.append(lid)
                    continue
                ok_, why_ = res if isinstance(res, tuple) else (False, "؟")
                if ok_:
                    lessons_done_ids.add(lid)
                    (lecture_pre if why_ == "pre" else lecture_new).add(lid)
                    reasons.pop(lid, None)
                    progressed = True
                else:
                    reasons[lid] = why_
                    still.append(lid)
            pending = still
            if _run_was_requested_to_stop():
                out["status"] = -2
                return out
            if not progressed:
                break

        out["failed"] = len(pending) + malformed
        out["fails"] = [(lid, reasons.get(lid, "؟")) for lid in pending]
        if malformed:
            out["fails"].append(("بيانات", f"{malformed} عنصر درس غير مفهوم"))
        return out

    def solve_chapter(cid):
        """يحل اختبار فصل واحد بالإجابات المحفوظة. يرجّع dict فيه حالة واضحة."""
        set_chapter_path(cid)
        out = {"ok": False, "best": 0, "total": 0, "completed": False, "blocked": None,
               "no_answer": 0, "write_fail": 0, "error": None, "pre_perfect": False}
        try:
            r = s.get(f"{QUREO_BASE}/api/study/chapters/{cid}/test")
        except requests.RequestException:
            out["error"] = "تعذر الاتصال بالمنصة"
            return out

        if r.status_code == 403:
            # فحص قراءة المحتوى فقط: لا نحاول تجاوز صلاحيات الحساب.
            out["blocked"] = "hidden"
            try:
                probe = s.get(f"{QUREO_BASE}/api/study/chapters/{cid}")
                if probe.status_code == 200:
                    out["blocked"] = "test"      # المحتوى ظاهر لكن طلب الاختبار مرفوض
            except requests.RequestException:
                pass
            return out
        if r.status_code != 200:
            out["error"] = f"HTTP {r.status_code}"
            return out

        try:
            qs_data = r.json()
        except (ValueError, TypeError):
            out["error"] = "رد الاختبار غير مفهوم"
            return out
        if not isinstance(qs_data, list) or not qs_data:
            out["error"] = "الاختبار فاضي"
            return out
        question_count = sum(
            1 for entry in qs_data
            if isinstance(entry, dict)
            and isinstance(entry.get('question'), dict)
            and entry['question'].get('id') is not None
            and entry['question'].get('type') in ('choice', 'description')
        )
        if question_count == 0:
            out["error"] = "مفيش أسئلة قابلة للحل"
            return out
        out["total"] = question_count

        best_before, completed_before, status_ok = check_status(cid)
        if not status_ok:
            out["error"] = "تعذر قراءة حالة الفصل"
            return out
        out["best"], out["completed"] = best_before, completed_before
        # لا نتخطى فصلًا لمجرد وجود completed_at؛ لازم تكون الدرجة Perfect.
        if best_before >= question_count:
            out.update(ok=True, pre_perfect=True)
            return out

        # نحتفظ بالتقدم الجزئي؛ نعيد التهيئة فقط لو مفيش أي إجابات سابقة.
        if best_before <= 0:
            init_res = _write("PUT", f"{QUREO_BASE}/api/study/students/chapters/{cid}/test", {})
            if (init_res is None or init_res.status_code not in (200, 201, 204)) and not _is_already_done(init_res):
                out["error"] = f"تعذر بدء الاختبار ({_why(init_res)})"
                return out

        chapter_answers = max_data.get('chapters', {}).get(str(cid), {}).get('answers', {})
        if not chapter_answers:
            chapter_answers = max_data.get('chapters', {}).get(str(cid), {}).get('questions', {})

        tasks, meta = [], []
        chapter_questions = max_data.get('chapters', {}).get(str(cid), {}).get('questions', {})

        def _choice_ids(raw):
            ids = []
            for ch in raw or []:
                v = ch.get("id") if isinstance(ch, dict) else ch
                try:
                    ids.append(int(v))
                except (TypeError, ValueError):
                    pass
            return ids

        for q in qs_data:
            if not isinstance(q, dict) or not isinstance(q.get('question'), dict):
                continue
            q_info = q['question']
            if q_info.get('id') is None or q_info.get('type') not in ('choice', 'description'):
                continue
            q_id = str(q_info['id'])
            q_type = q_info['type']

            item = chapter_answers.get(q_id, {})
            if isinstance(item, dict):
                ans = item.get('answer')
            elif isinstance(item, (tuple, list)):
                ans = item[1] if len(item) > 1 else None
            else:
                ans = item
            if ans is None:
                # لا نرسل تخمينًا عشوائيًا؛ السؤال بدون إجابة محفوظة يفضل غير محسوم.
                out["no_answer"] += 1
                continue

            # نص الإجابة كما هو محفوظ؛ المسافات والسطور قد تكون جزءًا من الإجابة الصحيحة.
            if q_type == 'description':
                url = f"{QUREO_BASE}/api/study/students/test-questions/{q_id}/answer/description"
                url_rev = f"{QUREO_BASE}/api/study/students/review-questions/{q_id}/answer/description"
                payload = {"answer_code": str(ans)}
            else:
                url = f"{QUREO_BASE}/api/study/students/test-questions/{q_id}/answer/choice"
                url_rev = f"{QUREO_BASE}/api/study/students/review-questions/{q_id}/answer/choice"
                try:
                    payload = {"choice_id": int(ans)}
                except (TypeError, ValueError):
                    out["no_answer"] += 1
                    continue
                dq = chapter_questions.get(q_id) if isinstance(chapter_questions, dict) else None
                alts = _choice_ids(q_info.get('choices')) or _choice_ids(dq.get('choices') if isinstance(dq, dict) else None)
                meta.append({"url": url, "cur": payload["choice_id"],
                             "alts": [a for a in alts if a != payload["choice_id"]],
                             "verified": (item.get('verified') if isinstance(item, dict) else None)})
            tasks.append((url, url_rev, payload))

        def _submit(task):
            url, url_rev, payload = task
            res = _write("PUT", url, payload)
            if (res is not None and res.status_code in (200, 201, 204)) or _is_already_done(res):
                return True
            # بعض إصدارات المنصة تعرض عنصر المراجعة بمسار منفصل (404/405 فقط).
            if res is not None and res.status_code in (404, 405):
                res2 = _write("PUT", url_rev, payload)
                return res2 is not None and res2.status_code in (200, 201, 204)
            return False

        results = _run_parallel(tasks, _submit, ANSWER_PARALLEL, _run_was_requested_to_stop)
        failed_tasks = [t for t, ok in zip(tasks, results) if not ok]
        if failed_tasks and not _run_was_requested_to_stop():
            # محاولة تانية تسلسلية للأسئلة اللي فشل إرسالها (غالبًا ضغط مؤقت).
            time.sleep(0.5)
            failed_tasks = [t for t in failed_tasks if not _submit(t)]
        out["write_fail"] = len(failed_tasks)

        best, is_completed, status_ok = check_status(cid)
        # نعتمد على الدرجة الفعلية التي سجلتها المنصة، وليس مجرد HTTP 200.
        out.update(best=best, completed=is_completed, ok=(status_ok and best >= question_count))

        # دقة: لو الدرجة مش كاملة، نجرّب بدائل الاختيارات (غير الموثّقة الأول) ونحتفظ بالبديل
        # بس لو درجة المنصة نفسها زادت؛ غير كده نرجّع الإجابة الأصلية.
        if status_ok and best < question_count and meta and not _run_was_requested_to_stop():
            budget, fails = 40, 0
            for m in sorted(meta, key=lambda x: x["verified"] is True):
                if best >= question_count or budget <= 0 or fails >= 3 or _run_was_requested_to_stop():
                    break
                for alt in m["alts"]:
                    if budget <= 0 or fails >= 3 or _run_was_requested_to_stop():
                        break
                    res_alt = _write("PUT", m["url"], {"choice_id": alt})
                    if res_alt is None or res_alt.status_code not in (200, 201, 204):
                        fails += 1
                        continue
                    b2, c2, ok2 = check_status(cid)
                    budget -= 1
                    if ok2 and b2 > best:
                        best, m["cur"] = b2, alt
                        out.update(best=b2, completed=c2, ok=(b2 >= question_count))
                        break
                    _write("PUT", m["url"], {"choice_id": m["cur"]})      # رجّع الإجابة الأصلية
        return out

    all_chapter_ids = qureo_chapter_ids(course, max_data)
    requested_chapters = selected_chapters or USERS.get(cid_tg, {}).get("selected_chapters")
    if requested_chapters:
        allowed = set(all_chapter_ids)
        chapter_ids = [int(ch) for ch in requested_chapters if int(ch) in allowed]
    else:
        chapter_ids = all_chapter_ids
    if not chapter_ids:
        try: bot.edit_message_text("❌ لم يتم تحديد فصول صالحة للحل.", cid_tg, message_id)
        except Exception: pass
        return
    chapter_positions = {chapter_id: index + 1 for index, chapter_id in enumerate(all_chapter_ids)}
    if _limit:
        chapter_ids = chapter_ids[:int(_limit)]
    total_chapters = len(chapter_ids)

    recs = {c: {"perfect": False, "lessons_ok": False, "best": 0, "total": 0, "blocked": None,
                "lessons_fail": 0, "lesson_fails": [], "note": "", "stuck": False,
                "attempts": 0, "touched": False, "pre_perfect": False}
            for c in chapter_ids}

    def _is_full(rec):
        return rec["perfect"] and rec["lessons_ok"]

    def _sig(rec):
        return (rec["best"], rec["perfect"], rec["lessons_ok"], rec["lessons_fail"])

    activities = []
    last_update = [0.0]
    run_started = time.monotonic()

    def _show_progress(chapter_number, pass_no, force=False):
        if not force and time.time() - last_update[0] <= _progress_interval():
            return
        full = sum(1 for r in recs.values() if _is_full(r))
        eta = ((time.monotonic() - run_started) / full) * (total_chapters - full) if full else None
        solved_list = [f"فصل {chapter_positions.get(c, 0)}" for c in chapter_ids if _is_full(recs[c])]
        review_list = []          # المستخدم يشوف المحلول بس؛ التفاصيل للمالك
        label = (f"الفصل {chapter_number} (مكتمل {full} من {total_chapters}"
                 + (f" • جولة {pass_no}" if pass_no > 1 else "") + ")")
        try:
            bot.edit_message_text(
                _qp_progress_text(platform_name, STUDENT_ID, full, total_chapters, label,
                                  solved_list, review_list, eta),
                cid_tg, message_id, parse_mode="HTML", reply_markup=_run_kb())
        except Exception:
            pass
        last_update[0] = time.time()

    def process_chapter(cid, rec):
        """فصل واحد: الاختبار ← الدروس. لو الاختبار مرفوض والدروس مقروءة نكمّل الدروس ونعيد الاختبار."""
        t = solve_chapter(cid)
        if _run_was_requested_to_stop():
            return
        rec["blocked"] = t["blocked"]
        if t["blocked"] == "hidden":
            rec["note"] = "المنصة رفضت فتح الفصل (HTTP 403)"
            return
        lec = solve_lectures(cid)
        if _run_was_requested_to_stop() or lec["status"] == -2:
            return
        if t["blocked"] == "test" and lec["failed"] == 0:
            t2 = solve_chapter(cid)          # بعد إكمال الدروس ممكن الاختبار يتفتح
            if _run_was_requested_to_stop():
                return
            if t2["blocked"] is None:
                t, rec["blocked"] = t2, None
        reached = t["blocked"] is None and not t["error"]
        if reached:
            rec["touched"] = True
            rec["best"], rec["total"], rec["perfect"] = t["best"], t["total"], t["ok"]
            if t["pre_perfect"] and not rec.get("visited"):
                rec["pre_perfect"] = True
            rec["visited"] = True
        rec["lessons_fail"] = lec["failed"]
        rec["lesson_fails"] = lec["fails"]
        rec["lessons_ok"] = lec["status"] == 200 and lec["failed"] == 0
        notes = []
        if t["blocked"] == "test":
            notes.append("طلب الاختبار مرفوض 403")
        elif t["error"]:
            notes.append(t["error"])
        elif not t["ok"]:
            notes.append(f"الاختبار {t['best']}/{t['total']}")
        if t.get("no_answer"):
            notes.append(f"{t['no_answer']} سؤال بدون إجابة محفوظة")
        if t.get("write_fail"):
            notes.append(f"{t['write_fail']} إجابة لم تُسجل")
        if lec["failed"]:
            why = lec["fails"][0][1] if lec["fails"] else "؟"
            notes.append(f"{lec['failed']} درس لم يكتمل ({why})")
        rec["note"] = "؛ ".join(notes)

    MAX_PASSES = 4
    MAX_ROUNDS = 3          # بعد ما الجولات تخلص: استراحة قصيرة وإعادة محاولة للناقص (ضغط/تأخير مؤقت من المنصة)
    passes_run = 0
    for round_no in range(1, MAX_ROUNDS + 1):
        if round_no > 1:
            if _run_was_requested_to_stop() or all(_is_full(r) for r in recs.values()):
                break
            time.sleep(3 * (round_no - 1))
            for r_ in recs.values():
                if not _is_full(r_):
                    r_["stuck"], r_["attempts"] = False, 0
        for pass_no in range(1, MAX_PASSES + 1):
            if _run_was_requested_to_stop():
                break
            passes_run += 1
            progressed = False
            blocked_here = None
            for idx, cid in enumerate(chapter_ids):
                if _run_was_requested_to_stop():
                    break
                rec = recs[cid]
                if _is_full(rec) or rec["stuck"]:
                    continue
                number = chapter_positions.get(cid, idx + 1)
                _show_progress(number, pass_no)
                before = _sig(rec)
                process_chapter(cid, rec)
                if _run_was_requested_to_stop():
                    activities.append(f"⏹ توقف أثناء معالجة فصل {number}")
                    break
                rec["attempts"] += 1
                changed = _sig(rec) != before
                progressed = progressed or changed
                if _is_full(rec):
                    activities.append(f"✅ فصل {number} (Perfect + كل الدروس)")
                else:
                    activities.append(f"⚠️ فصل {number} ({rec['note'] or 'لم يكتمل'})")
                if rec["blocked"]:
                    # الفصول اللي بعده هتترفض كمان؛ نرجع نكمّل الناقص قبله بدل ما نكمل على عمى.
                    blocked_here = cid
                    break
                if not _is_full(rec) and not changed and rec["attempts"] >= 2:
                    rec["stuck"] = True
            if _run_was_requested_to_stop():
                break
            remaining = [c for c in chapter_ids if not _is_full(recs[c]) and not recs[c]["stuck"]]
            if blocked_here is None:
                if not remaining:
                    break
                continue
            if not progressed:
                break          # اتقفل ومفيش أي تحسن في الجولة دي → القيد من المنصة/الحساب


    was_stopped = bool(USERS.get(cid_tg, {}).get('stop_requested', False))
    n_full = sum(1 for r in recs.values() if _is_full(r))
    n_pre_perfect = sum(1 for r in recs.values() if r["pre_perfect"])
    attempted_chapters = sum(1 for r in recs.values() if r["touched"])
    locked = [c for c in chapter_ids if recs[c]["blocked"]]
    fail_count = total_chapters - n_full
    lessons_failed = sum(r["lessons_fail"] for r in recs.values())

    if not was_stopped:
        with DB_LOCK:
            if fail_count == 0 and attempted_chapters > 0:
                DB["success"] = int(DB.get("success", 0) or 0) + 1
            else:
                DB["failed"] = int(DB.get("failed", 0) or 0) + 1
            save_db(DB)
        bump_user(cid_tg, fail_count == 0 and attempted_chapters > 0, attempted_chapters)
        # لا نستهلك فرصة مجانية/مدفوعة إذا كانت كل الفصول مرفوضة من صلاحيات المنصة.
        if attempted_chapters > 0:
            consume_attempt(cid_tg, _plan)

    review_final = []
    for c in chapter_ids:
        if _is_full(recs[c]):
            continue
        why = _friendly_reason(recs[c]) if recs[c]["attempts"] else "هيتكمل بعد اللي قبله"
        review_final.append((f"فصل {chapter_positions.get(c, 0)}", why))

    secs = int(time.monotonic() - _started_at)
    _details = f"⏱ وقت التنفيذ: {secs} ثانية\n📖 دروس أكملها البوت: {len(lecture_new)}"
    if fail_count and not was_stopped:
        _details += "\n🔄 اضغط «ابدأ حل حسابك» تاني بعد دقيقة وهيكمل الباقي."
        # التفاصيل التقنية للمالك بس، مش للمستخدم
        _tech = [f"فصل {chapter_positions.get(c, 0)}: {recs[c]['note'] or 'لم يكتمل'}"
                 for c in chapter_ids if recs[c]["attempts"] and not _is_full(recs[c])][:8]
        _diag_owner(f"🔧 <b>تشخيص (للمالك)</b> {html.escape(platform_name)} — كود {str(STUDENT_ID)[:3]}***\n"
                    f"مكتمل {n_full}/{total_chapters} | جولات {passes_run} | 403: {len(locked)} | دروس فاشلة: {lessons_failed}\n"
                    + "\n".join(html.escape(x) for x in _tech))
    _shot_session = None
    try:
        _host = urlparse(QUREO_BASE).hostname
        _tok = s.cookies.get("egy_student_access_token") or ""
        if _host:
            _shot_session = {
                "urls": [u for u in (os.getenv("QUREO_SHOT_URL"), f"{QUREO_BASE}/", f"{QUREO_PORTAL}/") if u],
                "cookies": ([{"name": "egy_student_access_token", "value": _tok, "domain": _host},
                             {"name": "student_selected_content_id", "value": str(content_id), "domain": _host}] if _tok else []),
                "login": {"id": STUDENT_ID, "password": PASSWORD,
                          "urls": [f"{QUREO_PORTAL}/", f"{QUREO_BASE}/login", f"{QUREO_BASE}/"]},
            }
    except Exception:
        _shot_session = None
    _record_result(cid_tg, platform_name, n_full, total_chapters, secs,
                   lessons=len(lecture_new) + len(lecture_pre), review=len(review_final), stopped=was_stopped,
                   session=_shot_session)
    try: bot.edit_message_text(
        _qp_final_text(platform_name, STUDENT_ID, n_full, total_chapters, review_final,
                       was_stopped, _details, trial_footer(_plan)),
        cid_tg, message_id, parse_mode="HTML", reply_markup=_final_kb(n_full, total_chapters))
    except Exception: pass

# ==========================================
# 🧠 محرك SPX (الثالثة) - اللفة الرئيسية
# ==========================================
def run_spx_tool(cid_tg, message_id, login_id, password, course=None):
    _plan = user_plan(cid_tg)
    _limit = _plan[1] if _plan[0] == "trial" else None   # محاولة مجانية = عدد عناصر محدود
    _done_items = 0
    _started_at = time.monotonic()
    course = course or {}
    solver = SPXSolver(login_id, password, course.get("subject"),
                       load_json(course["study"]) if course.get("study") else None,
                       load_json(course["answers"]) if course.get("answers") else None)
    register_run_session(cid_tg, solver.s)
    if not solver.login():
        try: bot.edit_message_text("❌ تعذر تسجيل الدخول للثقافة المالية. راجع كود الطالب وكلمة المرور، أو حاول بعد قليل إذا كانت المنصة متوقفة.", cid_tg, message_id, parse_mode="HTML")
        except: pass
        with DB_LOCK:
            DB["login_failed"] = int(DB.get("login_failed", 0) or 0) + 1
            DB["failed"] = int(DB.get("failed", 0) or 0) + 1
            save_db(DB)
        return

    activities = ["🚀 بدء..."]
    solved_titles, review, item_secs = [], [], []
    _prev_t = None
    last_update_time = 0
    fail_count = 0

    completed, total = 0, 0                  # قيم ابتدائية للأمان
    attempts, skip_ids, seen_ids = {}, set(), set()
    review_map = {}                          # id -> (العنوان, السبب) للعناصر اللي لسه ناقصة
    final_round = False

    def _why_failed(itype, res):
        sv, tt = int(res.get("solved") or 0), int(res.get("total") or 0)
        if itype == "test":
            return f"الاختبار لم ينجح ({sv}/{tt})" if tt else "تعذر بدء الاختبار"
        if itype == "chapter":
            return f"{sv}/{tt} سؤال" if tt else "تعذر قراءة أسئلة الفصل"
        return "لم يكتمل تأكيد الحل"

    while USERS.get(cid_tg, {}).get('running') and not USERS.get(cid_tg, {}).get('stop_requested'):
        item, completed, total = solver.find_next(skip_ids)
        if item == "DONE":
            break
        if item == "STUCK":
            # كل اللي فاضل اتعثر: نجرب دورة أخيرة ليهم، وبعدها نوقف ونقول السبب بدل ما نخمّن.
            if final_round:
                break
            final_round = True
            for k in list(skip_ids):
                attempts[k] = 1
            skip_ids.clear()
            continue
        if not item:
            fail_count += 1
            activities.append("⚠️ تعذر قراءة فصول المنصة؛ أوقفنا العملية بدل إعلان اكتمال وهمي")
            break

        item_title = item.get('title', '')
        itype = item.get('item_type')
        item_id = item.get('id')
        attempts[item_id] = attempts.get(item_id, 0) + 1

        if itype == "chapter":
            res = solver.solve_chapter(item_id)
        elif itype == "review":
            res = solver.solve_review(item_id)
        elif itype == "test":
            res = solver.solve_test(item_id)
        else:
            res = {"ok": False, "solved": 0, "total": 0}

        if res.get('ok', False):
            activities.append(f"✅ {item_title[:20]}")
            solved_titles.append(item_title[:28])
            review_map.pop(item_id, None)
        else:
            activities.append(f"⚠️ {item_title[:20]} — لم يكتمل تأكيد الحل")
            review_map[item_id] = (item_title[:28], _why_failed(itype, res))
            if attempts[item_id] >= 3:
                skip_ids.add(item_id)        # نكمل باقي المنهج ونرجع له في الدورة الأخيرة
            else:
                time.sleep(0.5 * attempts[item_id])
        if item_id not in seen_ids:
            seen_ids.add(item_id)
            if _prev_t is not None:
                item_secs.append(time.time() - _prev_t)
            _prev_t = time.time()
            _done_items += 1
            if _limit and _done_items >= int(_limit):
                break

        if time.time() - last_update_time > _progress_interval():
            _prog_done = max(int(completed or 0), _done_items)      # المعالَج فعلاً في التشغيل ده (مش رقم قديم)
            _eta = (sum(item_secs) / len(item_secs)) * max(0, total - _prog_done) if item_secs and total else None
            try: bot.edit_message_text(
                _qp_progress_text("الثقافة المالية", login_id, _prog_done, total, item_title[:40],
                                  solved_titles, [], _eta),
                cid_tg, message_id, parse_mode="HTML", reply_markup=_run_kb())
            except Exception: pass
            last_update_time = time.time()

    review = list(review_map.values())
    fail_count += len(review)

    was_stopped = bool(USERS.get(cid_tg, {}).get('stop_requested', False))
    if not was_stopped and _done_items == 0:
        fail_count += 1
        activities.append("⚠️ لم يبدأ حل أي عنصر؛ لم يتم خصم محاولة")
    if not was_stopped:
        with DB_LOCK:
            if fail_count == 0 and _done_items > 0:
                DB["success"] = int(DB.get("success", 0) or 0) + 1
            else:
                DB["failed"] = int(DB.get("failed", 0) or 0) + 1
            save_db(DB)
        bump_user(cid_tg, fail_count == 0 and _done_items > 0, _done_items)
        # لا تخصم محاولة إذا لم يبدأ حل أي عنصر فعليًا.
        if _done_items > 0:
            consume_attempt(cid_tg, _plan)

    _total = total if total and total > 0 else max(_done_items, 1)
    _done_n = min(_total, max(int(completed or 0), len(solved_titles))) if total and total > 0 else len(solved_titles)
    _details = (f"⏱ وقت التنفيذ: {int(time.monotonic() - _started_at)} ثانية\n"
                f"📚 عناصر تمت معالجتها: {_done_items}\n"
                f"⚠️ عناصر تحتاج مراجعة: {fail_count}")
    _shot_session = None
    try:
        _host = urlparse(BASE).hostname
        if _host:
            _shot_session = {
                "urls": [u for u in (os.getenv("SPX_SHOT_URL"), f"{BASE}/") if u],
                "cookies": ([{"name": "learning_token", "value": solver.token, "domain": _host}] if solver.token else []),
                "local_storage": ({"token": solver.token, "learning_token": solver.token} if solver.token else {}),
                "login": {"id": login_id, "password": password, "urls": [f"{BASE}/login", f"{BASE}/"]},
            }
    except Exception:
        _shot_session = None
    _record_result(cid_tg, "الثقافة المالية", _done_n, _total, int(time.monotonic() - _started_at),
                   lessons=_done_items, review=len(review), stopped=was_stopped, session=_shot_session)
    try: bot.edit_message_text(
        _qp_final_text("الثقافة المالية", login_id, _done_n, _total, review, was_stopped, _details,
                       trial_footer(_plan)),
        cid_tg, message_id, parse_mode="HTML", reply_markup=_final_kb(_done_n, _total))
    except Exception: pass

# ==========================================
# 🎨 الواجهة (الأزرار)
# ==========================================
# ==========================================
# 📚 المراحل والأنواع والمواد
# ==========================================
GRADES = {"g1": "أولى", "g2": "تانية"}
TYPES = {"gen": "عام"}
GRADE_TITLES = {"g1": "الصف الأول الثانوي", "g2": "الصف الثاني الثانوي"}
GRADE_SUBJECTS = {"g1": ["js"], "g2": ["py", "js", "spx"]}          # ترتيب الحل
SUBJECT_LINES = {
    "py":  "بايثون (Python) – منصة كيريو",
    "js":  "جافا سكريبت (JavaScript) – منصة كيريو",
    "spx": "الثقافة المالية (Financial Literacy) – منصة سبريكس",
}
SUBJECT_NAMES = {"py": "Python", "js": "JavaScript", "spx": "الثقافة المالية"}
SYSTEMS = {"lugat": "لغات", "gov": "حكومي", "azhar": "أزهري"}
SYSTEM_ORDER = ["lugat", "gov", "azhar"]
# الصفوف المتاحة لكل نظام (الأزهري: الأول الثانوي بس). الأول في القايمة بيظهر فوق.
SYSTEM_GRADES = {"lugat": ["g2", "g1"], "gov": ["g2", "g1"], "azhar": ["g1"]}
MATERIALS = {
    "js":  {"name": "JavaScript"},
    "py":  {"name": "Python"},
    "spx": {"name": "الثقافة المالية"},
}

# سجل المواد: (المرحلة, المادة) — ولو النوع (عام/خاص) ليه ملف مختلف تضيف (المرحلة, النوع, المادة)
#   kind=qureo → ملف إجابات بصيغة max.json (chapters → questions → answer)
#   kind=spx   → ملف study_data (levels → questions)
# تانية: الثلاث مواد. أولى: "عام" = حل منصة أولى (أول 42 فصل من كورس الجافا) — مفيش بايثون ولا ثقافة مالية لأولى.
COURSES = {
    ("g2", "js"):  {"kind": "qureo", "content_id": "javascript_ar", "file": "javascript_final_db.json", "start": 90001, "count": 54},
    ("g2", "py"):  {"kind": "qureo", "content_id": "python_short_ar", "file": "max.json", "start": 511001, "count": 25},
    ("g2", "spx"): {"kind": "spx", "subject": SUBJECT, "study": "study_data.json", "answers": "answers_by_level.json"},
    ("g1", "js"):  {"kind": "qureo", "content_id": "javascript_ar", "file": "javascript_final_db.json", "start": 90001, "count": 42,
                    "name": "عام"},
}


def get_course(grade, typ, mat, system=None):
    """الإجابات بتتاخد بالترتيب: (النظام,الصف,النوع,المادة) ← (النظام,الصف,المادة) ← (الصف,النوع,المادة) ← (الصف,المادة).
    يعني الأزهر/صنايع/لغات بتحل من نفس إجابات تانية/أولى إلا لو ضفت مفتاح خاص بيها في COURSES."""
    for k in ((system, grade, typ, mat), (system, grade, mat), (grade, typ, mat), (grade, mat)):
        if k in COURSES:
            return COURSES[k]
    return None


def grade_courses(g, system=None):
    """مواد السنة الجاهزة والمفتوحة بالترتيب: [(المادة, الكورس), ...]"""
    out = []
    for m in GRADE_SUBJECTS.get(g, []):
        c = get_course(g, "gen", m, system)
        if c is None or not course_enabled(g, m) or not course_ready(c):
            continue
        out.append((m, c))
    return out


def system_enabled(system):
    return system not in (DB["settings"].get("system_off") or [])


def system_grades(system):
    """الصفوف اللي ليها مواد جاهزة في النظام ده."""
    return [g for g in SYSTEM_GRADES.get(system, []) if grade_courses(g, system)]


def course_name(course, mat):
    return (course or {}).get("name") or MATERIALS[mat]["name"]


def course_ready(c):
    """المادة جاهزة لو ملف إجاباتها موجود جنب البوت."""
    if not c:
        return False
    f = c.get("file") or c.get("study")
    return bool(f) and os.path.exists(f) and os.path.getsize(f) > 2


def course_enabled(grade, mat):
    return f"{grade}:{mat}" not in (DB["settings"].get("course_off") or [])


# ==========================================
# 📝 كل نصوص البوت (الأدمن يعدلها من اللوحة)
# ==========================================
# key: (الاسم في اللوحة, النص الأصلي, المتغيرات المتاحة)
LINE = "━━━━━━━━━━━━━━━━━━━━"
TEXTS = {
    "welcome": ("🏠 الترحيب (مستخدم عادي)",
                "👋 <b>أهلاً بيك يا {name}</b>\n\n🤖 <b>بوت كيريو بيحل فصولك على المنصة لوحده</b>\n\n<blockquote>⚡ يحل الفصول أوتوماتيك وإنت مرتاح\n📋 حل الباقي كله، أو من الأول، أو لحد فصل تختاره\n📊 بتتابع الحل فصل بفصل لحظة بلحظة</blockquote>\n\n<b>{plan}</b>\n\n⬇️ <b>اختار من تحت</b>",
                ["name", "plan"]),
    "welcome_vip": ("🏠 الترحيب (VIP)",
                    "👋 <b>أهلاً بيك يا {name}</b>\n\n🤖 <b>بوت كيريو بيحل فصولك على المنصة لوحده</b>\n\n<blockquote>⚡ يحل الفصول أوتوماتيك وإنت مرتاح\n📋 حل الباقي كله، أو من الأول، أو لحد فصل تختاره\n📊 بتتابع الحل فصل بفصل لحظة بلحظة</blockquote>\n\n<b>{plan}</b>\n\n⬇️ <b>اختار من تحت</b>",
                    ["name", "plan"]),
    "welcome_owner": ("🏠 الترحيب (المالك)",
                      "👋 <b>أهلاً بيك يا {name}</b>\n\n🤖 <b>بوت كيريو بيحل فصولك على المنصة لوحده</b>\n\n<blockquote>⚡ يحل الفصول أوتوماتيك وإنت مرتاح\n📋 حل الباقي كله، أو من الأول، أو لحد فصل تختاره\n📊 بتتابع الحل فصل بفصل لحظة بلحظة</blockquote>\n\n<b>{plan}</b>\n\n⬇️ <b>اختار من تحت</b>",
                      ["name", "plan"]),
    "pick_system": ("🏫 اختيار النظام",
                    "🏫 <b>انت في أنهي نظام؟</b>\n\n"
                    "📌 <b>حل حسابك في 4 خطوات:</b>\n"
                    "<blockquote>1. اختار نظامك من تحت\n"
                    "2. اختار سنتك\n"
                    "3. ابعت كودك، وبعده كلمة المرور\n"
                    "4. دوس «▶️ حل تلقائي» والبوت يحل كل موادك لوحده</blockquote>\n\n"
                    "⬇️ <b>اختار نظامك</b>", []),
    "pick_grade": ("🎓 اختيار السنة",
                   "🎓 <b>انت في سنة كام؟</b>\n"
                   "🏫 النظام: <b>{system}</b>\n\n"
                   "📌 <b>حل حسابك في 3 خطوات:</b>\n"
                   "<blockquote>1. اختار سنتك من تحت\n"
                   "2. ابعت كودك، وبعده كلمة المرور\n"
                   "3. دوس «▶️ حل تلقائي» والبوت يحل كل موادك لوحده</blockquote>\n\n"
                   "⬇️ <b>اختار سنتك</b>", ["system"]),
    "ask_id2": ("🪪 المواد وطلب الكود",
                "🎓 <b>{grade}</b>\n\n"
                "🎓 <b>المواد اللي البوت هيحلها لك بالترتيب:</b>\n"
                "<blockquote>{subjects}</blockquote>\n\n"
                "✏️ <b>الخطوة 3: ابعت كودك</b>\n"
                "<blockquote>الكود = الأرقام اللي بتدخل بيها على منصة كيريو\n"
                "💡 مثال: <code>463942926</code></blockquote>",
                ["grade", "subjects"]),
    "ask_pass": ("🔑 طلب كلمة المرور", "🔑 <b>تمام، دلوقتي ابعت كلمة المرور</b>", []),
    "saved": ("💾 بعد حفظ البيانات",
              "✅ <b>تم حفظ بياناتك</b>\n\n"
              "⬇️ <b>دوس «▶️ حل تلقائي» والبوت يحل كل موادك لوحده</b>", []),
    "trial_note": ("🎁 ملاحظة المحاولة المجانية", "🎁 <i>محاولة مجانية: هيتم حل {chapters} فصول فقط.</i>", ["chapters"]),
    "soon": ("🔜 المادة قيد التجهيز",
             "🔜 <b>{mat}</b>\n\nالمواد دي لسه بتتجهز وهتتفتح قريباً.\nكلّم {owner} لمعرفة الموعد.",
             ["mat", "owner"]),
    "cancelled": ("↩️ رسالة الإلغاء", "↩️ تم الإلغاء. ابعت /start للبدء من جديد.", []),
    "expired": ("⌛ انتهاء الجلسة", "⚠️ الجلسة انتهت، يرجى إرسال /start من جديد.", []),
    "banned": ("🚫 رسالة الحظر", "🚫 <b>عذراً، أنت محظور من استخدام البوت.</b>", []),
    "maintenance": ("🛠 رسالة الصيانة", "🛠 <b>البوت تحت الصيانة حاليًا، جرب بعد شوية.</b>", []),
    "subscribe": ("📢 رسالة الاشتراك الإجباري",
                  "⚠️ <b>عذراً عزيزي،</b>\n\nللاستفادة من البوت، يجب عليك الاشتراك في قناتنا أولاً.\n\n⬇️ اضغط على اشترك ثم تحقق:", []),
    "alert_banned": ("🚫 تنبيه الحظر (منبثق)", "🚫 أنت محظور من استخدام البوت.", []),
    "alert_maint": ("🛠 تنبيه الصيانة (منبثق)", "🛠 البوت تحت الصيانة حاليًا، جرب بعد شوية.", []),
    "alert_sub": ("📢 تنبيه الاشتراك (منبثق)", "⚠️ لازم تشترك في القناة الأول عشان تستخدم البوت.", []),
    "sub_ok": ("✅ تم التحقق من الاشتراك", "✅ تم التحقق بنجاح!", []),
    "sub_fail": ("❌ لم يشترك", "❌ أنت لم تشترك في القناة بعد!", []),
    "busy": ("⏳ في عملية شغالة", "⏳ في عملية شغالة بالفعل", []),
    "busy_server": ("⏳ البوت مشغول", "⏳ البوت مشغول دلوقتي، جرب بعد دقيقة.", []),
    "data_missing": ("⚠️ بيانات ناقصة", "⚠️ البيانات ناقصة. ابعت /start من جديد.", []),
    "started": ("🚀 بدء الحل (منبثق)", "🚀 بدأ الحل!", []),
    "stopping": ("⏹ إيقاف الحل", "⏹ جاري إيقاف العملية عند أقرب نقطة آمنة...", []),
    "started_trial": ("🎁 بدء التجربة المجانية (منبثق)", "🎁 تجربة مجانية: حل {chapters} فصول فقط", ["chapters"]),
    "login_fail": ("❌ تعذر تسجيل الدخول (Qureo)", "❌ {reason}", ["reason"]),
    "login_fail_spx": ("❌ فشل الدخول (الثقافة المالية)", "❌ فشل الدخول للثقافة المالية!", []),
    "running_title": ("⏳ عنوان أثناء الحل", "⏳ <b>جاري حل {mat}…</b>", ["mat"]),
    "qp_account": ("📷 عنوان كارت الحساب", "📷 <b>حسابك على المنصة</b>", []),
    "done_title": ("🎉 عنوان بعد الانتهاء", "🎉 <b>تم إنهاء {mat}!</b>", ["mat"]),
    "send_result": ("📸 طلب صورة النتيجة", "📸 <b>أرسل صورة النتيجة لـ</b> {owner}", ["owner"]),
    "trial_footer": ("🎁 ذيل المحاولة المجانية",
                     f"\n{LINE}\n🎁 <b>دي كانت محاولتك المجانية ({{chapters}} فصول فقط).</b>\nلحل باقي المادة تواصل مع {{owner}} لتفعيل حسابك.",
                     ["chapters", "owner"]),
    "stats_title": ("📊 عنوان إحصائياتي", "📊 <b>إحصائياتي</b>", []),
    "contest_title": ("🎉 عنوان المسابقة", "🎉 <b>مسابقة Hamo</b>", []),
    "contest_extra": ("🎉 نص المسابقة (الجوايز/الشروط)",
                      "الترتيب بعدد مرات الحل الناجحة. للتفاصيل والجوايز تواصل مع {owner}.", ["owner"]),
    "contest_empty": ("🎉 المسابقة فاضية", "لسه مفيش متصدرين — كون أول واحد! 🔥", []),
    "invite": ("🎁 شاشة ادعي صحابك",
               "🎁 <b>ادعي صحابك واكسب</b>\n\n"
               "<blockquote>كل صاحب يدخل من رابطك = فرصة واحدة ليك</blockquote>\n\n"
               "🔗 <b>رابطك (دوس عليه يتنسخ):</b>\n"
               "<code>{link}</code>\n\n"
               "📌 <b>إزاي؟</b>\n"
               "<blockquote>1. دوس «📤 شارك رابطك» وابعته لصحابك\n"
               "2. صاحبك يفتح البوت من الرابط ويشترك في القناة\n"
               "3. أول ما يدخل بتوصلك رسالة والمكافأة بتتضاف لرصيدك</blockquote>\n\n"
               "👥 <b>دعيت لحد دلوقتي:</b> {count}\n\n"
               "⚠️ <b>صاحبك بيتحسب مرة واحدة بس، ولازم يكون أول مرة يدخل البوت.</b>",
               ["link", "count"]),
    "invite_joined": ("🎉 رسالة وصول صاحب جديد",
                      "🎉 <b>صاحبك {friend} دخل من رابطك!</b>\n🎁 اتضافت لك فرصة واحدة لرصيدك.", ["friend"]),
    "help": ("💡 شاشة التعليمات",
             "💡 <b>التعليمات</b>\n\n"
             "<blockquote>1. دوس «🎓 ابدأ حل حسابك» واختار نظامك وسنتك\n"
             "2. ابعت كودك، وبعده كلمة المرور بتاعة منصة كيريو\n"
             "3. دوس «▶️ حل تلقائي» والبوت يحل كل موادك لوحده\n"
             "4. تقدر توقف الحل في أي وقت من زر «⏹ إيقاف الحل»</blockquote>\n\n"
             "💬 <b>لأي مشكلة كلّم</b> {owner}", []),
    "balance": ("💎 شاشة رصيدي",
                "💎 <b>رصيدي</b>\n\n"
                "<blockquote>{plan}\n🎁 فرص الدعوات: {count}</blockquote>\n\n"
                "⬇️ <b>عايز فرص أكتر؟ ادعي صحابك أو اشترك</b>", ["plan", "count"]),
}

SAMPLE_VARS = {"link": "https://t.me/YourBot?start=r123456", "count": "0", "friend": "محمد",
               "grade": "الصف الأول الثانوي – حكومي", "subjects": "1. جافا سكريبت (JavaScript) – منصة كيريو",
               "system": "حكومي", "name": "أحمد", "plan": "🎁 معاك محاولة مجانية", "grade": "أولى", "type": "عام",
               "mat": "عام", "chapters": "3", "code": "401", "reason": "كود الطالب أو كلمة المرور غير صحيحين."}


def owner_un():
    u = (DB["settings"].get("owner_username") or OWNER_USERNAME or "").strip()
    return u if u.startswith("@") else "@" + u


def owner_tg():
    return owner_un().lstrip("@")


def T(key, **kw):
    s = (DB["settings"].get("texts") or {}).get(key) or TEXTS[key][1]
    kw.setdefault("owner", owner_un())
    for k, v in kw.items():
        s = s.replace("{" + k + "}", str(v))
    return s


def render_sample(s):
    vals = dict(SAMPLE_VARS, owner=owner_un())
    for k, v in vals.items():
        s = s.replace("{" + k + "}", str(v))
    return s


# ==========================================
# 🔘 كل أزرار البوت (الاسم واللون والإخفاء من اللوحة)
# ==========================================
# key: (المجموعة, الاسم الأصلي, اللون الأصلي: success=أخضر primary=أزرق danger=أحمر ""=بدون)
BUTTONS = {
    "home_start":   ("home", "ابدأ حل حسابك 🎓", "success"),
    "home_account": ("home", "حسابي 👤", "primary"),
    "home_sub":     ("home", "اشترك 💳", "danger"),
    "home_balance": ("home", "رصيدي 💎", "danger"),
    "home_invite":  ("home", "ادعي صحابك 🎁", ""),
    "home_help":    ("home", "التعليمات 💡", ""),
    "back":         ("nav", "رجوع ⬅️", ""),
    "cancel":       ("nav", "الغاء ❌", "danger"),
    "sys_lugat":    ("grade", "لغات (إنجليزي) 🌍", "success"),
    "sys_gov":      ("grade", "حكومي (عربي) 🏛", "success"),
    "sys_azhar":    ("grade", "أزهري 🕌", "success"),
    "grade_g1":     ("grade", "الصف الأول الثانوي 1️⃣", "success"),
    "grade_g2":     ("grade", "الصف الثاني الثانوي 2️⃣", "success"),
    "start_solve":  ("flow", "حل تلقائي ▶️", "success"),
    "method_auto":  ("flow", "حل تلقائي ▶️", "success"),
    "method_pick":  ("flow", "اختار المادة بنفسك 📋", "primary"),
    "stop_solve":   ("flow", "إيقاف الحل ⊗", "danger"),
    "run_back":     ("nav", "رجوع ⬅️", ""),
    "to_home":      ("nav", "القائمة الرئيسية 🏠", ""),
    "card_btn":     ("flow", "صورة الإنجاز 📷", "primary"),
    "invite_share": ("flow", "شارك رابطك 📤", "success"),
    "sub_join":     ("flow", "اشترك في القناة 📢", "primary"),
    "sub_check":    ("flow", "تحقق من الاشتراك ✅", "success"),
    "buy_owner":    ("flow", "👨‍💻 OWNER (شراء الأداة)", "success"),
    "buy_stats":    ("flow", "حسابي 👤", "primary"),
}
BTN_GROUPS = {"home": "🏠 الرئيسية", "nav": "↩️ التنقل", "grade": "📚 النظام والسنة",
              "flow": "🚀 الحل والاشتراك"}


def btn_override(key):
    return (DB["settings"].get("btn") or {}).get(key, {})


def btn_label(key):
    return btn_override(key).get("l") or BUTTONS[key][1]


def btn_style(key):
    ov = btn_override(key)
    return ov["s"] if "s" in ov else BUTTONS[key][2]


def BT(key, data=None, url=None, force=False):
    """زر من السجل: بيطبق الاسم/اللون/الإخفاء اللي الأدمن ظابطهم. بيرجّع None لو مخفي."""
    if btn_override(key).get("h") and not force:
        return None
    return _b(btn_label(key), data, url=url, style=btn_style(key) or None)


def _kbn(*rows):
    """زي _kb بس بيتجاهل الأزرار المخفية (None) والصفوف الفاضية."""
    k = types.InlineKeyboardMarkup()
    for r in rows:
        r = [b for b in r if b is not None]
        if r:
            k.row(*r)
    return k


# ==========================================
# 📊 إحصائيات المستخدمين + المسابقة
# ==========================================
def bump_user(cid, ok, chapters=0):
    """بتتنده عند انتهاء كل مادة: نجاح المادة + عدد الفصول/العناصر اللي اتحلت."""
    try:
        with DB_LOCK:
            u = DB["ustats"].setdefault(str(cid), {"runs": 0, "ok": 0})
            if ok:
                u["ok"] = u.get("ok", 0) + 1
            u["chapters"] = u.get("chapters", 0) + max(0, int(chapters or 0))
            save_db(DB)
    except Exception:
        pass


def bump_run(cid, accounts=0, runs=1):
    """مرة تشغيل واحدة لكل ضغطة «حل تلقائي»، وحساب واحد لو اتحل منه حاجة."""
    try:
        with DB_LOCK:
            u = DB["ustats"].setdefault(str(cid), {"runs": 0, "ok": 0})
            u["runs"] = u.get("runs", 0) + int(runs)
            u["accounts"] = u.get("accounts", 0) + int(accounts or 0)
            save_db(DB)
    except Exception:
        pass


def contest_rows():
    rows = [(int(v.get("ok", 0)), k) for k, v in DB["ustats"].items() if int(v.get("ok", 0)) > 0]
    rows.sort(key=lambda r: (-r[0], r[1]))
    return rows


def stats_text(cid, name):
    u = DB["ustats"].get(str(cid), {"runs": 0, "ok": 0})
    rows = contest_rows()
    rank = next((n for n, (_, k) in enumerate(rows, 1) if k == str(cid)), None)
    return (f"{T('stats_title')}\n"
            f"{LINE}\n"
            f"👤 الاسم: <b>{html.escape(name or '—')}</b>\n"
            f"{plan_text(cid)}\n"
            f"🔁 مرات التشغيل: <b>{u.get('runs', 0)}</b>\n"
            f"✅ مرات الحل الناجحة: <b>{u.get('ok', 0)}</b>\n"
            f"🏆 ترتيبك في المسابقة: <b>{('#' + str(rank)) if rank else '—'}</b>")


def contest_text():
    rows = contest_rows()[:10]
    medals = ["🥇", "🥈", "🥉"]
    lines = []
    for n, (ok, k) in enumerate(rows, 1):
        nm = html.escape((DB["info"].get(k, {}).get("name") or "مجهول")[:18])
        lines.append(f"{medals[n - 1] if n <= 3 else str(n) + '.'} {nm} — <b>{ok}</b>")
    board = "\n".join(lines) if lines else T("contest_empty")
    return (f"{T('contest_title')}\n"
            f"{LINE}\n"
            f"🏆 <b>المتصدرين:</b>\n{board}\n"
            f"{LINE}\n{T('contest_extra')}")


# ==========================================
# 🎨 الواجهة (الأزرار)
# ==========================================
# ---------- يوزر البوت + رابط الدعوة ----------
_BOT_UN = [None]


def bot_username():
    if _BOT_UN[0]:
        return _BOT_UN[0]
    un = DB["settings"].get("bot_username")
    if not un:
        try:
            un = bot.get_me().username
            with DB_LOCK:
                DB["settings"]["bot_username"] = un
                save_db(DB)
        except Exception:
            un = ""
    _BOT_UN[0] = un or ""
    return _BOT_UN[0]


def invite_link(cid):
    return f"https://t.me/{bot_username()}?start=r{cid}"


def invite_count(cid):
    r = DB["refs"].get(str(cid)) or {}
    return int(r.get("done", 0) or 0) if isinstance(r, dict) else 0


def _fmt_date(ts):
    try:
        from datetime import datetime
        try:
            from zoneinfo import ZoneInfo
            return datetime.fromtimestamp(ts, ZoneInfo("Africa/Cairo")).strftime("%d/%m/%Y")
        except Exception:
            return datetime.fromtimestamp(ts).strftime("%d/%m/%Y")
    except Exception:
        return "—"


def account_text(cid, name):
    u = DB["ustats"].get(str(cid)) or {}
    joined = (DB["info"].get(str(cid)) or {}).get("joined") or int(time.time())
    n = invite_count(cid)
    return (
        "👤 <b>حسابك</b>\n\n"
        f"<blockquote>🧑‍💻 الاسم: {html.escape(name or '—')}\n"
        f"📅 معانا من: {_fmt_date(joined)}\n"
        f"{plan_text(cid)}</blockquote>\n\n"
        "📊 <b>إحصائياتك</b>\n\n"
        f"<blockquote>▶️ مرات التشغيل: {u.get('runs', 0)}\n"
        f"✅ الحل الناجح: {u.get('ok', 0)}\n"
        f"📋 حسابات اتحلت: {u.get('accounts', 0)}\n"
        f"📚 فصول اتحلت: {u.get('chapters', 0)}</blockquote>\n\n"
        "🎁 <b>الدعوات</b>\n\n"
        f"<blockquote>👥 دعوات ناجحة: {n}\n"
        f"⭐ كسبت منها: {(str(n) + ' فرصة') if n else 'لسه'}</blockquote>"
    )


def kb_account():
    return _kbn([None if free_mode_on() else BT("home_sub", "n:sub"), BT("home_invite", "n:invite")],
                [BT("back", "b:n:home")])


def kb_home():
    # الصف الأول بيظهر على اليمين في واجهة العربي
    return _kbn(
        [BT("home_start", "n:start")],
        [BT("home_account", "n:account")],
        [None if free_mode_on() else BT("home_sub", "n:sub"), BT("home_balance", "n:balance")],
        [BT("home_invite", "n:invite"), BT("home_help", "n:help")],
    )


def kb_systems():
    rows = [[BT(f"sys_{sy}", f"sy:{sy}")] for sy in SYSTEM_ORDER if system_enabled(sy)]
    rows.append([BT("back", "b:n:home")])
    return _kbn(*rows)


def kb_grades(system):
    rows = [[BT(f"grade_{g}", f"g:{system}:{g}")] for g in system_grades(system)]
    rows.append([BT("back", "b:n:start")])
    return _kbn(*rows)


def _send_media(cid, mtype, src, caption, kb):
    """بيبعت صورة/فيديو/GIF. الكابشن الطويل (>1000) بيتبعت رسالة لوحده بعد الميديا."""
    short = len(caption) <= 1000
    kw = dict(caption=caption, reply_markup=kb, parse_mode="HTML") if short else {}
    fn = {"photo": bot.send_photo, "video": bot.send_video}.get(mtype, bot.send_animation)
    m = fn(cid, src, **kw)
    if not short:
        bot.send_message(cid, caption, reply_markup=kb, parse_mode="HTML")
    return m


WELCOME_VIDEO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "welcome.mp4")


def _send_default_welcome_video(cid, caption, kb):
    """فيديو الترحيب الجاهز (welcome.mp4): بيترفع مرة وبعدها بيتبعت بالـ file_id."""
    st = DB["settings"]
    key = str(os.path.getsize(WELCOME_VIDEO))
    fid = st.get("welcome_video_fid") if st.get("welcome_video_key") == key else None
    if fid:
        try:
            return _send_media(cid, "video", fid, caption, kb)
        except Exception as e:
            print(f"Welcome cached video file_id failed, re-uploading: {e}")
    with open(WELCOME_VIDEO, "rb") as f:
        m = _send_media(cid, "video", f, caption, kb)
    try:
        with DB_LOCK:
            st["welcome_video_fid"] = m.video.file_id
            st["welcome_video_key"] = key
            save_db(DB)
    except Exception:
        pass
    return m


def send_home(cid, name, is_vip=False):
    key = "welcome_owner" if is_owner(cid) else ("welcome_vip" if is_vip else "welcome")
    caption = T(key, name=html.escape(name or ""), plan=plan_text(cid))
    kb = kb_home()
    media = DB["settings"].get("welcome_media")          # None = الصورة الجاهزة | {"type": "none"} = نص بس
    mtype = (media or {}).get("type", "default")
    if mtype != "none":
        try:
            if media is None or mtype == "default":
                if os.path.exists(WELCOME_VIDEO):
                    _send_default_welcome_video(cid, caption, kb)      # الافتراضي = فيديو الترحيب
                    return
            else:
                _send_media(cid, mtype, media["id"], caption, kb)
                return
        except Exception as e:
            print(f"Welcome media error: {e}")
    try:
        bot.send_message(cid, caption, reply_markup=kb, parse_mode="HTML")
    except Exception as e2:
        print(f"Msg Error: {e2}")


def _ref_from_payload(text):
    """/start r123456  →  123456"""
    try:
        parts = (text or "").split(maxsplit=1)
        if len(parts) == 2 and parts[1].startswith("r") and parts[1][1:].isdigit():
            return int(parts[1][1:])
    except Exception:
        pass
    return None


def _process_referral(cid, name):
    """بتتنده بعد ما الصاحب يعدّي بوابة الاشتراك لأول مرة. بتحسب الدعوة مرة واحدة بس."""
    k = str(cid)
    with DB_LOCK:
        inviter = DB["ref_pending"].pop(k, None)
        if not inviter or k in DB["ref_by"]:
            save_db(DB)
            return
        inviter = int(inviter)
        if inviter == int(cid) or inviter not in DB["users"]:
            save_db(DB)
            return
        DB["ref_by"][k] = inviter
        r = DB["refs"].setdefault(str(inviter), {"done": 0, "ids": []})
        r["done"] = int(r.get("done", 0) or 0) + 1
        r.setdefault("ids", []).append(int(cid))
        cur = DB["credits"].get(str(inviter))
        if cur != "max":
            DB["credits"][str(inviter)] = (cur if isinstance(cur, int) else 0) + 1     # فرصة لكل دعوة
        save_db(DB)
    try:
        bot.send_message(inviter, T("invite_joined", friend=html.escape(name or "—")), parse_mode="HTML")
    except Exception:
        pass


def cmd_start_for(cid, name, chat=None, ref=None):
    # ⭐ التأكد إن الشخص مش محظور
    if DB.get("banned", {}).get(str(cid)):
        try: bot.send_message(cid, T("banned"), parse_mode="HTML")
        except Exception: pass
        return

    if DB["settings"].get("maintenance") and not is_admin(cid):
        try: bot.send_message(cid, T("maintenance"), parse_mode="HTML")
        except Exception: pass
        return

    is_new = cid not in DB["users"]
    if ref and is_new and ref != cid:
        with DB_LOCK:
            DB["ref_pending"][str(cid)] = ref        # تتحسب بعد الاشتراك في القناة
            save_db(DB)

    if not is_owner(cid) and not check_subscription(cid):
        send_subscribe_msg(cid)
        return

    if chat is not None:
        track_user(chat)
    _old_user_state = USERS.get(cid, {})
    USERS[cid] = {
        "running": bool(_old_user_state.get("running")),
        "stop_requested": bool(_old_user_state.get("stop_requested", False)),
    }   # نحافظ على حالة الحل والإيقاف أثناء /start
    if cid not in DB["users"]:
        DB["users"].append(cid)
        save_db(DB)

    is_vip = (DB.get("credits", {}).get(str(cid)) == "max")
    send_home(cid, name, is_vip)
    if is_new:
        _process_referral(cid, name)


@bot.message_handler(commands=["start"])
def cmd_start(msg):
    cmd_start_for(msg.chat.id, msg.from_user.first_name, msg.chat, _ref_from_payload(msg.text))


@bot.message_handler(commands=["cmds"])
def cmd_owner_commands(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    text = (
        f"👑 <b>أوامر المالك</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"🎛 <code>/admin</code> - لوحة التحكم الكاملة\n"
        f"📊 <code>/cmd</code> - الإحصائيات\n"
        f"➕ <code>/solve [ID] [العدد]</code> - إضافة فرص\n"
        f"💎 <code>/vip [ID]</code> - تفعيل VIP\n"
        f"❌ <code>/unvip [ID]</code> - إزالة VIP\n"
        f"🔄 <code>/reset [ID]</code> - تصفير الفرص\n"
        f"🚫 <code>/ban [ID]</code> - حظر مستخدم\n"
        f"📢 <code>/broadcast [رسالتك]</code> - إذاعة\n"
    )
    bot.send_message(cid, text, parse_mode="HTML")

@bot.message_handler(commands=["vip"])
def cmd_owner_vip(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    try:
        args = msg.text.replace("/vip", "").strip().split()
        if len(args) < 1:
            bot.reply_to(msg, "⚠️ <b>الاستخدام الصحيح:</b>\n<code>/vip 8549348815</code>", parse_mode="HTML")
            return
        target_id = args[0]
        if "credits" not in DB: DB["credits"] = {}
        DB["credits"][target_id] = "max"
        DB.setdefault("vip_until", {}).pop(target_id, None)
        save_db(DB)
        bot.reply_to(msg, f"💎 تم تفعيل <b>العضوية اللانهائية (VIP)</b> للطالب <code>{target_id}</code>.", parse_mode="HTML")
    except Exception as e:
        bot.reply_to(msg, f"⚠️ خطأ: {e}")

@bot.message_handler(commands=["unvip"])
def cmd_owner_unvip(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    try:
        args = msg.text.replace("/unvip", "").strip().split()
        if len(args) < 1: return
        target_id = args[0]
        if "credits" in DB and target_id in DB["credits"]:
            del DB["credits"][target_id]
            save_db(DB)
            bot.reply_to(msg, f"✅ تم إزالة الـ VIP من الطالب <code>{target_id}</code>.", parse_mode="HTML")
        else:
            bot.reply_to(msg, f"⚠️ هذا الطالب ليس VIP بالفعل.")
    except Exception as e:
        bot.reply_to(msg, f"⚠️ خطأ: {e}")

@bot.message_handler(commands=["ban"])
def cmd_owner_ban(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    try:
        args = msg.text.replace("/ban", "").strip().split()
        if len(args) < 1: return
        target_id = args[0]
        if "banned" not in DB: DB["banned"] = {}
        DB["banned"][target_id] = True
        save_db(DB)
        bot.reply_to(msg, f"🚫 تم حظر الطالب <code>{target_id}</code> من استخدام البوت.", parse_mode="HTML")
    except Exception as e:
        bot.reply_to(msg, f"⚠️ خطأ: {e}")

@bot.message_handler(commands=["reset"])
def cmd_owner_reset(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    try:
        args = msg.text.replace("/reset", "").strip().split()
        if len(args) < 1: return
        target_id = args[0]
        if "credits" not in DB: DB["credits"] = {}
        DB["credits"][target_id] = 0
        save_db(DB)
        bot.reply_to(msg, f"🔄 تم تصفير فرص الطالب <code>{target_id}</code>.", parse_mode="HTML")
    except Exception as e:
        bot.reply_to(msg, f"⚠️ خطأ: {e}")

@bot.message_handler(commands=["solve"])
def cmd_owner_add_credit(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    try:
        args = msg.text.replace("/solve", "").strip().split()
        if len(args) < 2:
            bot.reply_to(msg, "⚠️ <b>الاستخدام الصحيح:</b>\n<code>/solve 8549348815 10</code>", parse_mode="HTML")
            return
        target_id = args[0]
        amount = int(args[1])
        if "credits" not in DB: DB["credits"] = {}
        if DB["credits"].get(target_id) == "max":
            bot.reply_to(msg, f"⚠️ هذا الطالب VIP بالفعل.")
            return
        if target_id not in DB["credits"]: DB["credits"][target_id] = 0
        DB["credits"][target_id] += amount
        save_db(DB)
        bot.reply_to(msg, f"✅ تم إضافة <code>{amount}</code> فرصة للطالب <code>{target_id}</code>.", parse_mode="HTML")
    except ValueError:
        bot.reply_to(msg, "⚠️ <b>الاستخدام الصحيح:</b>\n<code>/solve 8549348815 10</code>", parse_mode="HTML")
    except Exception as e:
        bot.reply_to(msg, f"⚠️ خطأ: {e}")

@bot.message_handler(commands=["cmd"])
def cmd_owner_stats(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    db = load_db()
    text = (
        f"👑 <b>لوحة تحكم البوت</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 إجمالي المستخدمين: <code>{len(db.get('users', []))}</code>\n"
        f"✅ عمليات ناجحة: <code>{db.get('success', 0)}</code>\n"
        f"❌ عمليات فاشلة: <code>{db.get('failed', 0)}</code>\n"
    )
    bot.send_message(cid, text, parse_mode="HTML")

@bot.message_handler(commands=["broadcast"])
def cmd_owner_broadcast(msg):
    cid = msg.chat.id
    if not is_owner(cid): return
    text_to_send = msg.text.replace("/broadcast", "").strip()
    if not text_to_send:
        bot.reply_to(msg, "⚠️ <b>الاستخدام:</b> <code>/broadcast رسالتك هنا</code>", parse_mode="HTML")
        return
    db = load_db()
    users = db.get("users", [])
    if not users:
        bot.reply_to(msg, "⚠️ مفيش مستخدمين مسجلين.")
        return
    sent_count = 0
    failed_count = 0
    status_msg = bot.reply_to(msg, f"⏳ جاري الإرسال لـ {len(users)} مستخدم...")
    for user_id in users:
        try:
            bot.send_message(user_id, f"📢 <b>رسالة إدارية:</b>\n\n{text_to_send}", parse_mode="HTML")
            sent_count += 1
            time.sleep(0.05)
        except: failed_count += 1
    bot.edit_message_text(
        f"✅ <b>تمت الإذاعة!</b>\n\n📤 تم الإرسال لـ: <code>{sent_count}</code>\n🚫 فشل الإرسال لـ: <code>{failed_count}</code>",
        chat_id=cid, message_id=status_msg.message_id, parse_mode="HTML"
    )

# ==========================================
# 🎛 لوحة الأدمن (Admin Panel)  —  /admin
# ==========================================
from datetime import datetime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo
    _TZ = ZoneInfo("Africa/Cairo")
except Exception:
    _TZ = timezone(timedelta(hours=2))

AP_PAGE_SIZE = 8          # عدد المستخدمين في الصفحة
AP_BC_WORKERS = 1         # خيط واحد لتقليل استهلاك موارد الاستضافة
AP_BC_DELAY = 0.2         # تأخير كل خيط (≈ 25 رسالة/ثانية)
AP_STATE = {}             # uid -> حالة انتظار إدخال نصي من الأدمن
AP_PENDING = {}           # uid -> رسالة إذاعة منتظرة التأكيد
AP_BC = {"running": False, "stop": False}
AP_ALL_TYPES = ["text", "photo", "video", "document", "audio", "voice",
                "animation", "sticker", "video_note"]


def _esc(s):
    return html.escape(str(s or ""))


def _ts(t):
    if not t:
        return "—"
    return datetime.fromtimestamp(t, _TZ).strftime("%Y-%m-%d %H:%M")


_STYLE_EMOJI = {"success": "🟢", "danger": "🔴", "primary": "🔵"}


class _StyledBtn(types.InlineKeyboardButton):
    """زر إنلاين بيبعت حقل style (أخضر/أحمر/أزرق) لتيليجرام مباشرة،
    من غير ما نعتمد على إصدار المكتبة."""
    def __init__(self, *args, _style=None, _icon=None, _orig=None, **kwargs):
        super().__init__(*args, **kwargs)
        self._style = _style
        self._icon = _icon          # custom emoji id (الإيموجي المدفوع) بيظهر قبل نص الزر
        self._orig = _orig          # النص الأصلي بإيموجي عادي (للرجوع لو تيليجرام رفض الأيقونة)

    def to_dict(self):
        d = super().to_dict()
        if self._style:
            d["style"] = self._style
        if self._icon:
            d["icon_custom_emoji_id"] = self._icon
        return d

    def to_dic(self):                      # نسخ telebot القديمة
        return self.to_dict()

    def to_json(self):
        import json as _json
        return _json.dumps(self.to_dict())


def _b(text, data=None, url=None, style=None):
    """زر ملون: style = success (أخضر) / danger (أحمر) / primary (أزرق).
    الوضع الأصلي (الافتراضي): بيبعت style لتيليجرام. لو الأدمن قفله من الإعدادات
    بنحط إيموجي ملون في النص بدل كده."""
    native = bool(DB["settings"].get("native_colors", True))
    if style and not native:
        text = f"{_STYLE_EMOJI.get(style, '')} {text}".strip()
    orig_text = text
    icon = None
    if _emoji_map():
        text, icon = _split_icon(text)
    kw = {"text": text}
    if url:
        kw["url"] = url
    else:
        kw["callback_data"] = data
    if (style and native) or icon:
        return _StyledBtn(_style=(style if native else None), _icon=icon, _orig=orig_text, **kw)
    return types.InlineKeyboardButton(**kw)


# ==========================================
# 💎 الإيموجي المدفوع (Custom Emoji)
# ==========================================
# المالك يبعت للبوت: /setemoji + الإيموجيات المدفوعة اللي عايزها (مرة واحدة).
# البوت يحفظ «الإيموجي العادي ← ID» ويستبدله تلقائياً في كل الرسائل، وكأيقونة قبل نص الأزرار.
# لو تيليجرام رفض (البوت/المالك مش مؤهل)، البوت بيرجع للإيموجي العادي من غير ما يوقع.
_EMO_CACHE = {"sig": None, "rx": None, "lk": {}}
_EMO_TAG_RX = re.compile(r"(<tg-emoji.*?</tg-emoji>|<[^>]+>)", re.S)


def _emoji_map():
    return DB["settings"].get("emoji_ids") or {}


def _emo_compile():
    m = _emoji_map()
    sig = tuple(sorted(m.items()))
    if _EMO_CACHE["sig"] != sig:
        lk = {}
        for ch, eid in m.items():
            base = ch.replace("\ufe0f", "")
            for v in (ch, base, base + "\ufe0f"):
                if v:
                    lk[v] = eid
        alts = sorted(lk, key=len, reverse=True)
        rx = re.compile("|".join(re.escape(a) for a in alts)) if alts else None
        _EMO_CACHE.update(sig=sig, rx=rx, lk=lk)
    return _EMO_CACHE["rx"], _EMO_CACHE["lk"]


def emo_text(text):
    """بيلفّ الإيموجيات المسجلة بـ <tg-emoji> (من غير ما يلمس الوسوم)."""
    if not isinstance(text, str) or not _emoji_map():
        return text
    rx, lk = _emo_compile()
    if not rx:
        return text
    parts = _EMO_TAG_RX.split(text)
    for i in range(0, len(parts), 2):
        parts[i] = rx.sub(lambda m: f'<tg-emoji emoji-id="{lk[m.group(0)]}">{m.group(0)}</tg-emoji>', parts[i])
    return "".join(parts)


def _split_icon(text):
    """لو النص بيبدأ/ينتهي بإيموجي مسجل: نشيله ونرجّع (النص، ID الأيقونة)."""
    rx, lk = _emo_compile()
    if not rx:
        return text, None
    t = text.strip()
    for v in sorted(lk, key=len, reverse=True):
        if t.endswith(v) and len(t) > len(v):
            return t[: -len(v)].strip(), lk[v]
        if t.startswith(v) and len(t) > len(v):
            return t[len(v):].strip(), lk[v]
    return text, None


def _strip_icons(markup):
    try:
        for row in getattr(markup, "keyboard", None) or []:
            for b in row:
                if getattr(b, "_icon", None):
                    b.text = b._orig or b.text
                    b._icon = None
    except Exception:
        pass


def _is_emoji_error(e):
    msg = str(e).lower()
    return any(w in msg for w in ("emoji", "icon", "entit", "button", "can't parse"))


def _install_emoji_wrappers():
    o_send, o_edit = bot.send_message, bot.edit_message_text

    def send_message(chat_id, text, *a, **k):
        if _emoji_map():
            try:
                return o_send(chat_id, emo_text(text), *a, **k)
            except Exception as e:
                if not _is_emoji_error(e):
                    raise
                _strip_icons(k.get("reply_markup"))
        return o_send(chat_id, text, *a, **k)

    def edit_message_text(text, *a, **k):
        if _emoji_map():
            try:
                return o_edit(emo_text(text), *a, **k)
            except Exception as e:
                if "not modified" in str(e).lower() or not _is_emoji_error(e):
                    raise
                _strip_icons(k.get("reply_markup"))
        return o_edit(text, *a, **k)

    bot.send_message = send_message
    bot.edit_message_text = edit_message_text
    for name in ("send_photo", "send_video", "send_animation"):
        orig = getattr(bot, name)

        def wrapper(chat_id, media, *a, _orig=orig, **k):
            if _emoji_map() and k.get("caption"):
                try:
                    return _orig(chat_id, media, *a, **{**k, "caption": emo_text(k["caption"])})
                except Exception as e:
                    if not _is_emoji_error(e):
                        raise
                    _strip_icons(k.get("reply_markup"))
            return _orig(chat_id, media, *a, **k)
        setattr(bot, name, wrapper)


_install_emoji_wrappers()


def _custom_emojis_in(msg):
    """{الإيموجي العادي: custom_emoji_id} من رسالة فيها إيموجي مدفوع."""
    text = msg.text or msg.caption or ""
    ents = msg.entities or msg.caption_entities or []
    raw = text.encode("utf-16-le")
    out = {}
    for e in ents:
        if getattr(e, "type", "") == "custom_emoji" and getattr(e, "custom_emoji_id", None):
            ch = raw[e.offset * 2:(e.offset + e.length) * 2].decode("utf-16-le", "ignore")
            if ch:
                out[ch] = str(e.custom_emoji_id)
    return out


@bot.message_handler(commands=["setemoji", "emojiid"])
def cmd_setemoji(msg):
    if not is_owner(msg.chat.id):
        return
    found = _custom_emojis_in(msg)
    if not found and getattr(msg, "reply_to_message", None):
        found = _custom_emojis_in(msg.reply_to_message)
    if not found:
        bot.send_message(msg.chat.id,
                         "💎 <b>الإيموجي المدفوع</b>\n\n"
                         "ابعت <code>/setemoji</code> وجنبها الإيموجيات المدفوعة اللي عايزها (ينفع كذا واحد في رسالة واحدة).\n"
                         "البوت هيستبدل بيها الإيموجي العادي المقابل في كل الرسائل وكأيقونات للأزرار.\n\n"
                         "• <code>/emojis</code> عرض المسجل\n• <code>/clearemoji</code> مسح الكل\n\n"
                         "⚠️ تيليجرام بيسمح للبوت بالإيموجي المدفوع حسب شروطه (حساب المالك Premium أو يوزر Fragment).",
                         parse_mode="HTML")
        return
    if msg.text.split()[0].startswith("/emojiid"):
        lines = "\n".join(f"{ch} ← <code>{eid}</code>" for ch, eid in found.items())
        bot.send_message(msg.chat.id, lines, parse_mode="HTML")
        return
    with DB_LOCK:
        cur = dict(DB["settings"].get("emoji_ids") or {})
        cur.update(found)
        DB["settings"]["emoji_ids"] = cur
        save_db(DB)
    bot.send_message(msg.chat.id, f"✅ اتسجل <b>{len(found)}</b> إيموجي مدفوع: {' '.join(found)}", parse_mode="HTML")


@bot.message_handler(commands=["emojis"])
def cmd_emojis(msg):
    if not is_owner(msg.chat.id):
        return
    m = _emoji_map()
    bot.send_message(msg.chat.id, ("💎 المسجل:\n" + "\n".join(f"{ch} ← <code>{eid}</code>" for ch, eid in m.items()))
                     if m else "مفيش إيموجي مدفوع مسجل.", parse_mode="HTML")


@bot.message_handler(commands=["clearemoji"])
def cmd_clearemoji(msg):
    if not is_owner(msg.chat.id):
        return
    with DB_LOCK:
        DB["settings"]["emoji_ids"] = {}
        save_db(DB)
    bot.send_message(msg.chat.id, "🧹 اتمسح كل الإيموجي المدفوع.")


def _kb(*rows):
    k = types.InlineKeyboardMarkup()
    for r in rows:
        k.row(*r)
    return k


def _show(chat, mid, text, kb=None):
    try:
        bot.edit_message_text(text, chat, mid, reply_markup=kb,
                              parse_mode="HTML", disable_web_page_preview=True)
    except Exception as e:
        if "message is not modified" not in str(e):
            raise


def _del(chat, mid):
    try:
        bot.delete_message(chat, mid)
    except Exception:
        pass


def _back(to="adm:home"):
    return [_b("🔙 رجوع", to)]


def _credit_label(c, until=None):
    if c == "max":
        return "💎 VIP " + (f"حتى {_ts(until)}" if until else "(دائم)")
    if c is None:
        return "لا يوجد رصيد"
    return f"{c} فرصة"


# ---------------- تتبع المستخدمين ----------------
_last_save = [0]


def track_user(chat):
    """بيسجل الاسم واليوزر ووقت الانضمام/آخر ظهور. chat = message.chat."""
    try:
        k = str(chat.id)
        now = int(time.time())
        info = DB["info"].get(k) or {"joined": now}
        info.update(name=getattr(chat, "first_name", "") or "",
                    username=getattr(chat, "username", "") or "",
                    last_seen=now)
        DB["info"][k] = info
        DB["blocked"].pop(k, None)
        if now - _last_save[0] > 30:        # حفظ كل 30 ثانية بحد أقصى
            _last_save[0] = now
            save_db(DB)
    except Exception:
        pass


# ---------------- الصفحات ----------------
def ap_stats():
    now = int(time.time())
    users = [u for u in DB.get("users", []) if int(u) not in OWNER_IDS]
    credits = DB.get("credits", {})
    vip = sum(1 for v in credits.values() if v == "max")
    with_chances = sum(1 for v in credits.values() if isinstance(v, int) and v > 0)
    trials = sum(1 for v in DB.get("trial_used", {}).values() if v)
    banned = sum(1 for v in DB.get("banned", {}).values() if v)
    infos = list(DB.get("info", {}).values())
    act24 = sum(1 for i in infos if 0 <= now - int(i.get("last_seen", 0) or 0) < 86400)
    act7 = sum(1 for i in infos if 0 <= now - int(i.get("last_seen", 0) or 0) < 7 * 86400)
    today_start = int(datetime.now(_TZ).replace(hour=0, minute=0, second=0, microsecond=0).timestamp())
    n_today = sum(1 for i in infos if int(i.get("joined", 0) or 0) >= today_start)
    ok, bad = int(DB.get("success", 0) or 0), int(DB.get("failed", 0) or 0)
    rate = (ok * 100 // (ok + bad)) if (ok + bad) else 0
    text = (
        "📊 <b>الإحصائيات</b>\n\n"
        f"👥 إجمالي المستخدمين: <b>{len(users)}</b>\n"
        f"🟢 نشطين آخر 24 ساعة: <b>{act24}</b>\n"
        f"🔥 نشطين آخر 7 أيام: <b>{act7}</b>\n"
        f"🆕 جداد النهاردة: <b>{n_today}</b>\n"
        f"🚪 سابوا البوت: <b>{len(DB.get('blocked', {}))}</b>\n"
        f"🚫 محظورين: <b>{banned}</b>\n\n"
        f"💎 VIP: <b>{vip}</b>\n"
        f"🎟 معاهم فرص: <b>{with_chances}</b>\n"
        f"🎁 استخدموا المحاولة المجانية: <b>{trials}</b>\n\n"
        f"✅ عمليات ناجحة: <b>{ok}</b>\n"
        f"❌ عمليات فاشلة: <b>{bad}</b>\n"
        f"🔑 حالات فشل تسجيل الدخول: <b>{int(DB.get('login_failed', 0) or 0)}</b>\n"
        f"📈 نسبة النجاح: <b>{rate}%</b>\n"
        f"⚡ الجلسات الشغالة: <b>{RUN_GATE.active}</b> • سعة التنفيذ الفورية: <b>{SOLVE_WORKERS}</b>\n"
        f"🎟 أكواد محفوظة: <b>{len(DB.get('codes', {}))}</b>   🔗 إحالات مسجلة: "
        f"<b>{sum(int(r.get('done', 0) or 0) for r in DB.get('refs', {}).values() if isinstance(r, dict))}</b>\n\n"
        "<i>النشطين والجداد بيتحسبوا من وقت تفعيل اللوحة.</i>"
    )
    return text, _kb([_b("🔄 تحديث", "adm:stats")], _back())


def _ap_filter_ids(flt):
    ids = [u for u in reversed(DB["users"]) if int(u) not in OWNER_IDS]
    if flt == "v":
        ids = [u for u in ids if DB["credits"].get(str(u)) == "max"]
    elif flt == "b":
        ids = [u for u in ids if DB["banned"].get(str(u))]
    return ids


def _ap_ubtn(uid, flt, page):
    k = str(uid)
    icon = "🚫" if DB["banned"].get(k) else ("💎" if DB["credits"].get(k) == "max" else "🟢")
    info = DB["info"].get(k, {})
    name = (info.get("name") or info.get("username") or "بدون اسم")[:18]
    return [_b(f"{icon} {name} • {uid}", f"adm:user:{uid}:{flt}:{page}")]


def ap_users(flt, page):
    ids = _ap_filter_ids(flt)
    total = len(ids)
    pages = max(1, -(-total // AP_PAGE_SIZE))
    page = max(0, min(page, pages - 1))
    chunk = ids[page * AP_PAGE_SIZE:(page + 1) * AP_PAGE_SIZE]
    title = {"a": "👥 المستخدمين", "v": "💎 الـ VIP", "b": "🚫 المحظورين"}[flt]
    text = f"{title}\nالإجمالي: <b>{total}</b> • صفحة {page + 1}/{pages}"
    if not chunk:
        text += "\n\nمفيش نتائج."
    keys = [_ap_ubtn(u, flt, page) for u in chunk]
    nav = []
    if page > 0:
        nav.append(_b("⬅️ السابق", f"adm:users:{flt}:{page - 1}"))
    nav.append(_b(f"{page + 1}/{pages}", "adm:noop"))
    if page < pages - 1:
        nav.append(_b("التالي ➡️", f"adm:users:{flt}:{page + 1}"))
    keys.append(nav)
    keys.append([_b("👥 الكل", "adm:users:a:0"), _b("💎 VIP", "adm:users:v:0"),
                 _b("🚫 محظورين", "adm:users:b:0")])
    keys.append([_b("🔎 بحث", "adm:search")])
    keys.append(_back())
    return text, _kb(*keys)


def ap_user_card(uid, flt="a", page=0):
    k = str(uid)
    if int(uid) not in DB["users"] and k not in DB["info"]:
        return "❌ المستخدم مش موجود.", _kb(_back(f"adm:users:{flt}:{page}"))
    info = DB["info"].get(k, {})
    cr = DB["credits"].get(k)
    banned = bool(DB["banned"].get(k))
    status = "🚫 محظور" if banned else ("🚪 سابق البوت" if k in DB["blocked"] else "🟢 نشط")
    uname = f"@{_esc(info.get('username'))}" if info.get("username") else "—"
    text = (
        "👤 <b>بيانات المستخدم</b>\n\n"
        f"🆔 ID: <code>{uid}</code>\n"
        f"📛 الاسم: {_esc(info.get('name')) or '—'}\n"
        f"🔗 اليوزر: {uname}\n"
        f"📅 انضم: {_ts(info.get('joined'))}\n"
        f"🕐 آخر ظهور: {_ts(info.get('last_seen'))}\n"
        f"🎟 الرصيد: <b>{_credit_label(cr, DB['vip_until'].get(k))}</b>\n"
        f"🎁 المحاولة المجانية: <b>{DB['trial_used'].get(k, 0)}/{DB['settings'].get('free_attempts', 1)}</b>\n"
        f"الحالة: {status}"
    )
    tail = f":{flt}:{page}"
    if cr == "max":
        vip_row = [_b("إلغاء VIP", f"adm:unvip:{uid}{tail}", style="danger"),
                   _b("تجديد 30 يوم", f"adm:vip:{uid}:30{tail}", style="success")]
    else:
        vip_row = [_b("VIP دائم", f"adm:vip:{uid}:0{tail}", style="success"),
                   _b("30 يوم", f"adm:vip:{uid}:30{tail}", style="primary"),
                   _b("7 أيام", f"adm:vip:{uid}:7{tail}", style="primary")]
    ban_btn = (_b("فك الحظر", f"adm:unban:{uid}{tail}", style="success") if banned
               else _b("حظر المستخدم", f"adm:ban:{uid}{tail}", style="danger"))
    return text, _kb(
        vip_row,
        [_b("+1 فرصة", f"adm:cr:{uid}:1{tail}", style="success"),
         _b("+5", f"adm:cr:{uid}:5{tail}", style="success"),
         _b("+10", f"adm:cr:{uid}:10{tail}", style="success")],
        [_b("إعادة المحاولة المجانية", f"adm:trial:{uid}{tail}", style="primary"),
         _b("تصفير", f"adm:reset:{uid}{tail}", style="danger")],
        [ban_btn],
        [_b("✉️ مراسلة", f"adm:dm:{uid}"), _b("🔗 فتح الحساب", url=f"tg://user?id={uid}")],
        _back(f"adm:users:{flt}:{page}"))


def ap_settings():
    st = DB["settings"]
    on = lambda v: "🟢 شغال" if v else "🔴 مقفول"
    sty = lambda v: "success" if v else "danger"
    text = (
        "⚙️ <b>الإعدادات</b>\n\n"
        f"📢 قناة الاشتراك: <code>{_esc(st.get('channel') or '— مفيش قناة')}</code>\n"
        f"📢 الاشتراك الإجباري (على كل الأزرار): {on(st.get('force_sub', True))}\n"
        f"🛠 وضع الصيانة: {on(st.get('maintenance'))}\n\n"
        f"🆓 الحل المجاني للكل: {on(st.get('free_mode', True))}\n"
        f"🎁 المحاولة المجانية: {on(st.get('free_trial', True))}\n"
        f"🔢 عدد المحاولات المجانية: <b>{st.get('free_attempts', 1)}</b>\n"
        f"📚 فصول كل محاولة مجانية: <b>{st.get('free_chapters', 3)}</b>\n\n"
        f"🎨 الأزرار الملونة الأصلية: {on(st.get('native_colors', True))}\n\n"
        "<i>أي تغيير بيتطبق فورًا بدون إعادة تشغيل.</i>"
    )
    return text, _kb(
        [_b("الاشتراك الإجباري", "adm:tog:force_sub", style=sty(st.get("force_sub", False))),
         _b("الصيانة", "adm:tog:maintenance", style="danger" if st.get("maintenance") else "success")],
        [_b("🆓 الحل المجاني للكل", "adm:tog:free_mode", style=sty(st.get("free_mode", True)))],
        [_b("المحاولة المجانية", "adm:tog:free_trial", style=sty(st.get("free_trial", True)))],
        [_b("➖ فصل", "adm:num:free_chapters:-1"),
         _b(f"📚 {st.get('free_chapters', 3)} فصول", "adm:noop"),
         _b("➕ فصل", "adm:num:free_chapters:1")],
        [_b("➖ محاولة", "adm:num:free_attempts:-1"),
         _b(f"🔢 {st.get('free_attempts', 1)} محاولات", "adm:noop"),
         _b("➕ محاولة", "adm:num:free_attempts:1")],
        [_b("✏️ تغيير القناة", "adm:chan"), _b("✏️ رسالة الشراء", "adm:ask_buy")],
        [_b("الأزرار الملونة الأصلية", "adm:tog:native_colors", style=sty(st.get("native_colors", True)))],
        _back())


def ap_admins():
    adm = [a for a in DB["settings"].get("admins", []) if int(a) not in OWNER_IDS]
    text = f"🛡 <b>الأدمنز</b>\n\n👑 المالك: <b>أنت</b>\n"
    text += "\n".join(f"• <code>{a}</code>" for a in adm) or "مفيش أدمنز تانيين."
    keys = [[_b(f"حذف {a}", f"adm:adm_del:{a}", style="danger")] for a in adm]
    keys.append([_b("إضافة أدمن", "adm:adm_add", style="success")])
    keys.append(_back())
    return text, _kb(*keys)


# ---------------- الإذاعة ----------------
def _bc_targets(mode):
    out = []
    for uid in DB["users"]:
        k = str(uid)
        if DB["banned"].get(k) or k in DB["blocked"] or int(uid) in OWNER_IDS:
            continue
        cr = DB["credits"].get(k)
        if mode == "vip" and cr != "max":
            continue
        if mode == "free" and cr == "max":
            continue
        out.append(uid)
    return out


def _bc_bar(done, total):
    n = int(10 * done / total) if total else 10
    return "█" * n + "░" * (10 - n)


def _bc_text(final=False):
    done = AP_BC["sent"] + AP_BC["failed"] + AP_BC["blocked"]
    if final:
        head = "⏹ <b>الإذاعة اتوقفت</b>" if AP_BC["stop"] else "✅ <b>خلصت الإذاعة</b>"
    else:
        head = "📢 <b>الإذاعة شغالة...</b>"
    el = max(1, int(time.time() - AP_BC["t0"]))
    return (f"{head}\n\n{_bc_bar(done, AP_BC['total'])} {done}/{AP_BC['total']}\n\n"
            f"✅ وصلت: <b>{AP_BC['sent']}</b>\n🚪 سابوا البوت: <b>{AP_BC['blocked']}</b>\n"
            f"⚠️ فشلت: <b>{AP_BC['failed']}</b>\n⏱ {el} ثانية")


def _bc_send_one(uid, src_chat, src_msg):
    for _ in range(3):
        try:
            bot.copy_message(uid, src_chat, src_msg)
            return "ok"
        except telebot.apihelper.ApiTelegramException as e:
            desc = (e.description or "").lower()
            if e.error_code == 429:
                wait = 5
                try:
                    wait = e.result_json.get("parameters", {}).get("retry_after", 5)
                except Exception:
                    pass
                time.sleep(wait + 1)
                continue
            if e.error_code == 403 or "chat not found" in desc or "deactivated" in desc:
                DB["blocked"][str(uid)] = 1
                return "blocked"
            return "fail"
        except Exception:
            time.sleep(1)
    return "fail"


def ap_run_broadcast(chat, panel, src_chat, src_msg, mode):
    ids = _bc_targets(mode)
    AP_BC.update(running=True, stop=False, total=len(ids), sent=0, failed=0,
                 blocked=0, t0=time.time())
    stats_lock = threading.Lock()
    dispatch_lock = threading.Lock()
    next_index = [0]

    def worker():
        while not AP_BC["stop"]:
            # توزيع مباشر للمعرّفات بين عمال الإذاعة دون إنشاء طابور مهام.
            with dispatch_lock:
                if AP_BC["stop"] or next_index[0] >= len(ids):
                    break
                uid = ids[next_index[0]]
                next_index[0] += 1
            res = _bc_send_one(uid, src_chat, src_msg)
            with stats_lock:
                AP_BC[{"ok": "sent", "blocked": "blocked"}.get(res, "failed")] += 1
            time.sleep(AP_BC_DELAY)

    threads = [threading.Thread(target=worker, daemon=True) for _ in range(AP_BC_WORKERS)]
    for t in threads:
        t.start()
    stop_kb = _kb([_b("إيقاف", "adm:bc_stop", style="danger")])
    while any(t.is_alive() for t in threads):
        time.sleep(3)
        try:
            _show(chat, panel, _bc_text(), stop_kb)
        except Exception:
            pass
    AP_BC["running"] = False
    save_db(DB)
    try:
        _show(chat, panel, _bc_text(final=True), _kb(_back()))
    except Exception:
        pass


# ---------------- الأوامر ----------------
@bot.message_handler(commands=["admin"], chat_types=["private"])
def ap_cmd_admin(m):
    if not is_admin(m.from_user.id):
        return
    AP_STATE.pop(m.from_user.id, None)
    bot.send_message(m.chat.id, ap_home_text(), reply_markup=ap_home_kb(m.from_user.id))


@bot.message_handler(commands=["cancel"], chat_types=["private"])
def ap_cmd_cancel(m):
    if AP_STATE.pop(m.from_user.id, None):
        bot.send_message(m.chat.id, "تم الإلغاء ✅")


def _ap_ask(uid, chat, mid, action, text, data=None, back="adm:home"):
    AP_STATE[uid] = {"a": action, "chat": chat, "msg": mid, "d": data}
    _show(chat, mid, text + "\n\n<i>ابعتلي دلوقتي 👇</i>", _kb(_back(back)))


# ---------------- الأزرار ----------------
@bot.callback_query_handler(func=lambda c: c.data.startswith("adm:"))
def ap_callback(c):
    uid = c.from_user.id
    if not is_admin(uid):
        return bot.answer_callback_query(c.id, "⛔ مش مسموحلك", show_alert=True)
    p = c.data.split(":")[1:]
    act, a = p[0], p[1:]
    chat, mid = c.message.chat.id, c.message.message_id
    AP_STATE.pop(uid, None)
    if act.startswith("x"):                     # لوحة التحكم الكبيرة (للمالك)
        return ap2_dispatch(c, uid, act, a, chat, mid)
    answer, alert = "", False

    try:
        with DB_LOCK:
            if act in ("vip", "unvip", "cr", "reset", "ban", "unban", "trial"):
                target = a[0]
                tail = a[2:] if act in ("cr", "vip") else a[1:]
                flt, page = tail[0], int(tail[1])
                if act == "vip":
                    days = int(a[1])
                    DB["credits"][target] = "max"
                    if days > 0:
                        DB["vip_until"][target] = int(time.time()) + days * 86400
                    else:
                        DB["vip_until"].pop(target, None)
                    answer = "💎 تم تفعيل VIP " + (f"{days} يوم" if days else "دائم")
                elif act == "unvip":
                    DB["credits"][target] = 0
                    DB["vip_until"].pop(target, None)
                    answer = "تم إلغاء VIP"
                elif act == "trial":
                    DB["trial_used"].pop(target, None)
                    if DB["credits"].get(target) == 0:
                        DB["credits"].pop(target, None)
                    answer = "🎁 تم إعادة المحاولة المجانية"
                elif act == "reset":
                    DB["credits"][target] = 0
                    answer = "🔄 تم تصفير الفرص"
                elif act == "cr":
                    cur = DB["credits"].get(target)
                    if cur == "max":
                        answer = "الطالب VIP بالفعل"
                    else:
                        DB["credits"][target] = (cur if isinstance(cur, int) else 0) + int(a[1])
                        answer = f"✅ تمت إضافة {a[1]} فرصة"
                elif act == "ban":
                    if is_admin(int(target)):
                        answer, alert = "مينفعش تحظر أدمن", True
                    else:
                        DB["banned"][target] = True
                        answer = "🚫 تم الحظر"
                else:
                    DB["banned"].pop(target, None)
                    answer = "✅ تم فك الحظر"
                save_db(DB)
                _show(chat, mid, *ap_user_card(int(target), flt, page))
            elif act == "tog":
                if a[0] in ("force_sub", "maintenance", "free_trial", "native_colors", "free_mode"):
                    cur = DB["settings"].get(a[0], a[0] in ("free_trial", "native_colors", "free_mode"))
                    DB["settings"][a[0]] = not cur
                    save_db(DB)
                _show(chat, mid, *ap_settings())
            elif act == "num":
                key, d = a[0], int(a[1])
                if key in ("free_chapters", "free_attempts"):
                    lo, hi = (1, 20) if key == "free_chapters" else (0, 10)
                    dflt = 3 if key == "free_chapters" else 1
                    DB["settings"][key] = max(lo, min(hi, int(DB["settings"].get(key, dflt)) + d))
                    save_db(DB)
                _show(chat, mid, *ap_settings())
            elif act == "adm_del":
                if not is_owner(uid):
                    answer, alert = "⛔ للمالك فقط", True
                else:
                    DB["settings"]["admins"] = [x for x in DB["settings"].get("admins", [])
                                                if str(x) != a[0]]
                    save_db(DB)
                    _show(chat, mid, *ap_admins())

        if act == "noop":
            pass
        elif act == "home":
            _show(chat, mid, ap_home_text(), ap_home_kb(uid))
        elif act == "close":
            _del(chat, mid)
        elif act == "stats":
            _show(chat, mid, *ap_stats())
        elif act == "users":
            _show(chat, mid, *ap_users(a[0], int(a[1])))
        elif act == "user":
            _show(chat, mid, *ap_user_card(int(a[0]), a[1], int(a[2])))
        elif act == "search":
            _ap_ask(uid, chat, mid, "search", "🔎 ابعت ID أو يوزرنيم أو جزء من الاسم:",
                    back="adm:users:a:0")
        elif act == "dm":
            _ap_ask(uid, chat, mid, "dm",
                    f"✉️ ابعت الرسالة اللي هتتبعت للمستخدم <code>{a[0]}</code>:",
                    data=int(a[0]), back=f"adm:user:{a[0]}:a:0")
        elif act == "bc":
            if AP_BC["running"]:
                _show(chat, mid, _bc_text(), _kb([_b("إيقاف", "adm:bc_stop", style="danger")]))
            else:
                _ap_ask(uid, chat, mid, "broadcast",
                        "📢 <b>إذاعة</b>\nابعت الرسالة اللي عايز تذيعها (نص/صورة/فيديو/ملف...):")
        elif act == "bc_go":
            pend = AP_PENDING.pop(uid, None)
            if not pend:
                answer = "مفيش رسالة جاهزة"
                _show(chat, mid, ap_home_text(), ap_home_kb(uid))
            elif AP_BC["running"]:
                answer = "في إذاعة شغالة بالفعل"
            else:
                threading.Thread(target=ap_run_broadcast,
                                 args=(chat, mid, pend["chat"], pend["msg"], a[0]),
                                 daemon=True).start()
                answer = "بدأت الإذاعة 🚀"
        elif act == "bc_stop":
            AP_BC["stop"] = True
            answer = "جاري الإيقاف..."
        elif act == "bc_cancel":
            AP_PENDING.pop(uid, None)
            _show(chat, mid, ap_home_text(), ap_home_kb(uid))
        elif act == "set":
            _show(chat, mid, *ap_settings())
        elif act == "ask_buy":
            _ap_ask(uid, chat, mid, "buy",
                    "✏️ ابعت نص <b>رسالة الشراء</b> الجديدة (HTML مسموح).\n"
                    "تقدر تكتب <code>{chapters}</code> وهيتبدل بعدد فصول المحاولة المجانية.",
                    back="adm:set")
        elif act == "chan":
            _ap_ask(uid, chat, mid, "chan",
                    "📺 ابعت يوزر القناة الجديدة (<code>@channel</code>) أو الـ ID (<code>-100...</code>).\n"
                    "لازم البوت يكون أدمن فيها.\nابعت <code>-</code> لمسح القناة وإلغاء الاشتراك الإجباري.", back="adm:set")
        elif act in ("admins", "adm_add"):
            if not is_owner(uid):
                answer, alert = "⛔ للمالك فقط", True
            elif act == "admins":
                _show(chat, mid, *ap_admins())
            else:
                _ap_ask(uid, chat, mid, "adm_add", "🛡 ابعت ID الأدمن الجديد:", back="adm:admins")
        elif act == "backup":
            with DB_LOCK:
                save_db(DB)
                tmp = f"backup_{int(time.time())}.json"
                flush_db()
                with open(USERS_FILE, "rb") as src, open(tmp, "wb") as dst:
                    dst.write(src.read())
            with open(tmp, "rb") as f:
                bot.send_document(chat, f, caption="💾 نسخة احتياطية " + _ts(int(time.time())))
            os.remove(tmp)
            answer = "اتبعتت ✅"
    except Exception as e:
        answer, alert = "⚠️ حصل خطأ: " + str(e)[:150], True
    try:
        bot.answer_callback_query(c.id, answer, show_alert=alert)
    except Exception:
        pass


# ---------------- استقبال الإدخال النصي من الأدمن ----------------
_AP_TEXT_ACTIONS = ("search", "chan", "adm_add", "buy")


@bot.message_handler(
    func=lambda m: m.chat.type == "private" and m.from_user.id in AP_STATE and is_admin(m.from_user.id),
    content_types=AP_ALL_TYPES)
def ap_on_state(m):
    uid = m.from_user.id
    st = AP_STATE.pop(uid)
    a, chat, mid = st["a"], st["chat"], st["msg"]
    if a.startswith("x"):
        return ap2_on_state(m, st)
    if a in _AP_TEXT_ACTIONS and not m.text:
        AP_STATE[uid] = st
        return bot.reply_to(m, "⚠️ ابعت نص بس.")
    if a not in ("broadcast", "dm"):          # الإذاعة والمراسلة محتاجين الرسالة الأصلية للنسخ
        _del(m.chat.id, m.message_id)
    t = (m.text or "").strip()

    try:
        if a == "broadcast":
            AP_PENDING[uid] = {"chat": m.chat.id, "msg": m.message_id}
            n_all, n_vip, n_free = (len(_bc_targets(x)) for x in ("all", "vip", "free"))
            _show(chat, mid, "📢 <b>تأكيد الإذاعة</b>\nالرسالة اللي فوق هي اللي هتتبعت. اختار الجمهور:",
                  _kb([_b(f"للكل ({n_all})", "adm:bc_go:all", style="success")],
                      [_b(f"VIP بس ({n_vip})", "adm:bc_go:vip", style="primary"),
                       _b(f"غير VIP ({n_free})", "adm:bc_go:free", style="primary")],
                      [_b("إلغاء", "adm:bc_cancel", style="danger")]))
        elif a == "dm":
            try:
                bot.copy_message(st["d"], m.chat.id, m.message_id)
                res = "✅ الرسالة اتبعتت.\n\n"
            except Exception as e:
                res = "⚠️ فشل الإرسال: " + _esc(str(e)[:100]) + "\n\n"
            text, kb = ap_user_card(st["d"])
            _show(chat, mid, res + text, kb)
        elif a == "search":
            rows = []
            if t.lstrip("-").isdigit():
                if (int(t) in DB["users"] or t in DB["info"]) and int(t) not in OWNER_IDS:
                    rows = [int(t)]
            else:
                needle = t.lstrip("@").lower()
                for k, i in DB["info"].items():
                    if int(k) in OWNER_IDS:
                        continue
                    if needle in (i.get("username") or "").lower() or needle in (i.get("name") or "").lower():
                        rows.append(int(k))
                        if len(rows) >= 8:
                            break
            if len(rows) == 1:
                _show(chat, mid, *ap_user_card(rows[0]))
            elif rows:
                keys = [_ap_ubtn(u, "a", 0) for u in rows] + [_back("adm:users:a:0")]
                _show(chat, mid, f"🔎 نتائج البحث ({len(rows)}):", _kb(*keys))
            else:
                _show(chat, mid, "❌ مفيش نتائج.", _kb([_b("🔎 بحث تاني", "adm:search")],
                                                      _back("adm:users:a:0")))
        elif a == "chan":
            if t in ("-", "0"):                      # مسح القناة = إلغاء الاشتراك الإجباري
                with DB_LOCK:
                    DB["settings"]["channel"] = ""
                    SUB_CACHE.clear()
                    save_db(DB)
                return _show(chat, mid, *ap_settings())
            ref = t if t.startswith("@") or t.lstrip("-").isdigit() else "@" + t
            bot.get_chat(ref)                       # يتأكد إن القناة موجودة والبوت شايفها
            with DB_LOCK:
                DB["settings"]["channel"] = ref
                SUB_CACHE.clear()
                save_db(DB)
            _show(chat, mid, *ap_settings())
        elif a == "buy":
            with DB_LOCK:
                DB["settings"]["buy_text"] = getattr(m, "html_text", None) or t
                save_db(DB)
            _show(chat, mid, "✅ تم حفظ رسالة الشراء. دي المعاينة:\n\n" +
                  DB["settings"]["buy_text"].replace("{chapters}", str(DB["settings"].get("free_chapters", 3))),
                  _kb(_back("adm:set")))
        elif a == "adm_add":
            if t.isdigit():
                with DB_LOCK:
                    adm = DB["settings"].setdefault("admins", [])
                    if int(t) not in adm:
                        adm.append(int(t))
                    save_db(DB)
            _show(chat, mid, *ap_admins())
    except Exception as e:
        _show(chat, mid, "⚠️ حصل خطأ: " + _esc(str(e)[:200]), _kb(_back()))


@bot.message_handler(commands=["colors"], chat_types=["private"])
def ap_cmd_colors(m):
    if not is_owner(m.from_user.id):
        return
    arg = (m.text or "").split()[1:2]
    if not arg or arg[0] not in ("on", "off"):
        cur = "شغالة" if DB["settings"].get("native_colors", True) else "مقفولة"
        return bot.send_message(m.chat.id, f"🎨 الألوان الأصلية حاليًا: {cur}\nاستخدم: /colors on أو /colors off")
    DB["settings"]["native_colors"] = (arg[0] == "on")
    save_db(DB)
    bot.send_message(m.chat.id, "🎨 الألوان الأصلية: " + ("✅ اتفعلت" if arg[0] == "on" else "⛔ اتقفلت (إيموجي ملون بدلها)"))


# ==========================================
# 🎛 لوحة التحكم الكبيرة للمالك
#    النصوص / الأزرار والألوان / المراحل والمواد / الترحيب / المسابقة / الأسعار / الأدوات / النظام
# ==========================================
def _to_owners(text, **kw):
    """إشعار لكل المالكين (كل واحد بيوصله لوحده)."""
    for o in OWNER_IDS:
        try:
            bot.send_message(o, text, **kw)
        except Exception:
            pass


def _n_users():
    return sum(1 for u in DB["users"] if int(u) not in OWNER_IDS)


START_TIME = time.time()
ERRORS = []
AP2_PAGE = 8
_STY_ICON = {"success": "🟢", "primary": "🔵", "danger": "🔴", "": "⚪"}
_STY_NAME = {"success": "أخضر", "primary": "أزرق", "danger": "أحمر", "": "بدون لون"}
_STY_CODE = {"s": "success", "p": "primary", "d": "danger", "n": ""}


def log_error(where, err):
    ERRORS.append((int(time.time()), str(where), str(err)[:220]))
    del ERRORS[:-15]


def _nav(prefix, page, pages):
    nav = []
    if page > 0:
        nav.append(_b("⬅️", f"{prefix}:{page - 1}"))
    nav.append(_b(f"{page + 1}/{pages}", "adm:noop"))
    if page < pages - 1:
        nav.append(_b("➡️", f"{prefix}:{page + 1}"))
    return nav


def _uptime():
    s = int(time.time() - START_TIME)
    d, s = divmod(s, 86400)
    h, s = divmod(s, 3600)
    m, _ = divmod(s, 60)
    return (f"{d}ي " if d else "") + f"{h}س {m}د"


# ---------------- الرئيسية ----------------
def ap_home_kb(uid):
    if not is_owner(uid):
        return _kb(
            [_b("📊 الإحصائيات", "adm:stats", style="primary"), _b("👥 المستخدمين", "adm:users:a:0", style="success")],
            [_b("📢 إذاعة", "adm:bc", style="success"), _b("⚙️ الإعدادات", "adm:set", style="primary")],
            [_b("إغلاق", "adm:close", style="danger")])
    return _kb(
        [_b("📊 الإحصائيات", "adm:stats", style="primary"), _b("👥 المستخدمين", "adm:users:a:0", style="success")],
        [_b("📝 النصوص", "adm:xt:0", style="success"), _b("🔘 الأزرار والألوان", "adm:xb:0", style="danger")],
        [_b("📚 المراحل والمواد", "adm:xc", style="primary"), _b("🖼 الترحيب", "adm:xw", style="success")],
        [_b("💰 الأسعار والتواصل", "adm:xm", style="danger"), _b("🎉 المسابقة", "adm:xk", style="primary")],
        [_b("📢 إذاعة", "adm:bc", style="success"), _b("⚙️ الإعدادات", "adm:set", style="primary")],
        [_b("🧰 أدوات سريعة", "adm:xtool", style="danger"), _b("🖥 حالة النظام", "adm:xs", style="success")],
        [_b("🛡 الأدمنز", "adm:admins"), _b("💾 نسخة احتياطية", "adm:backup")],
        [_b("إغلاق", "adm:close", style="danger")])


def ap_home_text():
    st = DB["settings"]
    running = sum(1 for u in USERS.values() if u.get("running"))
    ok, bad = DB.get("success", 0), DB.get("failed", 0)
    rate = (ok * 100 // (ok + bad)) if (ok + bad) else 0
    flags = []
    if st.get("maintenance"):
        flags.append("🛠 صيانة")
    if st.get("force_sub", False) and st.get("channel"):
        flags.append("📢 اشتراك إجباري")
    return (f"👑 <b>لوحة تحكم Hamo</b>\n{LINE}\n"
            f"👥 المستخدمين: <b>{_n_users()}</b>   ⚡ شغال الآن: <b>{running}</b>\n"
            f"✅ ناجح: <b>{ok}</b>   ❌ فاشل: <b>{bad}</b>   📈 <b>{rate}%</b>\n"
            f"⏱ مدة التشغيل: <b>{_uptime()}</b>\n"
            + (f"⚠️ {' • '.join(flags)}\n" if flags else "")
            + f"{LINE}\nاختر القسم اللي عايز تتحكم فيه 👇")


# ---------------- 📝 النصوص ----------------
def ap2_texts(page=0):
    keys = list(TEXTS)
    pages = max(1, -(-len(keys) // AP2_PAGE))
    page = max(0, min(page, pages - 1))
    ov = DB["settings"].get("texts") or {}
    rows = [[_b(("✏️ " if k in ov else "") + TEXTS[k][0], f"adm:xtk:{k}", style="primary" if k in ov else "success")]
            for k in keys[page * AP2_PAGE:(page + 1) * AP2_PAGE]]
    rows.append(_nav("adm:xt", page, pages))
    rows.append(_back())
    text = (f"📝 <b>نصوص البوت</b>\n{LINE}\nكل رسالة المستخدم بيشوفها تقدر تغيّرها حرف بحرف.\n"
            f"✏️ = معدّلة عن الأصل • عدد النصوص: <b>{len(keys)}</b>")
    return text, _kb(*rows)


def ap2_text_card(key):
    label, default, vars_ = TEXTS[key]
    ov = DB["settings"].get("texts") or {}
    cur = ov.get(key) or default
    raw = html.escape(cur if len(cur) < 1500 else cur[:1500] + "…")
    text = f"📝 <b>{label}</b>\n{LINE}\n<b>النص الحالي (بالكود):</b>\n<pre>{raw}</pre>"
    if vars_:
        text += "\n<b>المتغيرات:</b> " + " ".join("<code>{" + v + "}</code>" for v in vars_)
    text += "\n<i>HTML مسموح: &lt;b&gt; &lt;i&gt; &lt;code&gt; &lt;u&gt;</i>"
    if key in ov:
        text += "\n✏️ <i>معدّل عن الأصل</i>"
    return text, _kb(
        [_b("✏️ تعديل", f"adm:xte:{key}", style="success"), _b("👁 معاينة", f"adm:xtp:{key}", style="primary")],
        [_b("♻️ رجوع للأصلي", f"adm:xtr:{key}", style="danger")],
        _back("adm:xt:0"))


# ---------------- 🔘 الأزرار ----------------
def ap2_btns(page=0):
    keys = list(BUTTONS)
    pages = max(1, -(-len(keys) // AP2_PAGE))
    page = max(0, min(page, pages - 1))
    rows = []
    for k in keys[page * AP2_PAGE:(page + 1) * AP2_PAGE]:
        ov = btn_override(k)
        icon = "🙈" if ov.get("h") else _STY_ICON[btn_style(k)]
        rows.append([_b(f"{icon} {btn_label(k)}", f"adm:xbk:{k}")])
    rows.append(_nav("adm:xb", page, pages))
    rows.append([_b("🎨 ألوان تلقائية متنوعة", "adm:xbauto", style="success"),
                 _b("♻️ كل الأزرار للأصل", "adm:xbreset", style="danger")])
    rows.append(_back())
    text = (f"🔘 <b>الأزرار والألوان</b>\n{LINE}\nاضغط على أي زرار تغيّر اسمه، لونه، أو تخفيه.\n"
            "🟢 أخضر  🔵 أزرق  🔴 أحمر  ⚪ بدون لون  🙈 مخفي")
    return text, _kb(*rows)


def ap2_btn_card(key):
    grp, d_label, d_style = BUTTONS[key]
    ov = btn_override(key)
    page = list(BUTTONS).index(key) // AP2_PAGE
    text = (f"🔘 <b>زرار: {html.escape(btn_label(key))}</b>\n{LINE}\n"
            f"📂 المجموعة: {BTN_GROUPS[grp]}\n"
            f"🎨 اللون: {_STY_ICON[btn_style(key)]} {_STY_NAME[btn_style(key)]}\n"
            f"👁 الحالة: {'🙈 مخفي' if ov.get('h') else '✅ ظاهر'}\n"
            f"<i>الزرار اللي تحت هو معاينة حية بنفس اللون.</i>")
    prev = _b(btn_label(key), "adm:noop", style=btn_style(key) or None)
    return text, _kb(
        [prev],
        [_b("✏️ تغيير الاسم", f"adm:xbe:{key}", style="primary")],
        [_b("🟢 أخضر", f"adm:xbc:{key}:s", style="success"), _b("🔵 أزرق", f"adm:xbc:{key}:p", style="primary"),
         _b("🔴 أحمر", f"adm:xbc:{key}:d", style="danger"), _b("⚪ بدون", f"adm:xbc:{key}:n")],
        [_b("👁 إظهار" if ov.get("h") else "🙈 إخفاء", f"adm:xbh:{key}", style="success" if ov.get("h") else "danger"),
         _b("♻️ الأصلي", f"adm:xbr:{key}")],
        _back(f"adm:xb:{page}"))


# ---------------- 📚 المراحل والمواد ----------------
def ap2_courses():
    rows = []
    lines = []
    for (g, m), c in [(k, v) for k, v in COURSES.items() if len(k) == 2]:
        on = course_enabled(g, m)
        ready = course_ready(c)
        nm = f"{GRADES[g]} • {course_name(c, m)}"
        lines.append(f"{'🟢' if on else '🔴'} {nm} — {'✅ الملف جاهز' if ready else '⚠️ الملف ناقص'}")
        rows.append([_b(f"{'🟢 شغالة' if on else '🔴 مقفولة'} | {nm}", f"adm:xct:{g}:{m}",
                        style="success" if on else "danger")])
    rows.append(_back())
    text = (f"📚 <b>المراحل والمواد</b>\n{LINE}\n" + "\n".join(lines) +
            f"\n{LINE}\nاضغط على مادة تقفلها/تفتحها (المقفولة بتختفي من قايمة المواد وبتتخطى في الحل التلقائي).")
    return text, _kb(*rows)


# ---------------- 🖼 الترحيب ----------------
def ap2_welcome():
    media = DB["settings"].get("welcome_media")
    cur = "الافتراضي (فيديو الترحيب)" if media is None else ("بدون صورة (نص فقط)" if media.get("type") == "none"
                                                      else {"photo": "صورة", "video": "فيديو", "animation": "GIF"}.get(media.get("type"), "؟"))
    text = (f"🖼 <b>الترحيب</b>\n{LINE}\nالميديا الحالية: <b>{cur}</b>\n"
            "ابعتلي صورة أو GIF أو فيديو وهتبقى هي رسالة البداية.")
    return text, _kb(
        [_b("🖼 تغيير الصورة / GIF / فيديو", "adm:xwm", style="success")],
        [_b("📝 تعديل نص الترحيب", "adm:xtk:welcome", style="primary"),
         _b("💎 نص الـ VIP", "adm:xtk:welcome_vip", style="primary")],
        [_b("🗑 بدون صورة (نص فقط)", "adm:xwx", style="danger"), _b("♻️ الافتراضي", "adm:xwr")],
        [_b("👁 معاينة", "adm:xwp", style="success")],
        _back())


# ---------------- 🎉 المسابقة ----------------
def ap2_contest():
    rows = contest_rows()
    text = (f"🎉 <b>المسابقة</b>\n{LINE}\nعدد المتسابقين: <b>{len(rows)}</b>\n\n"
            + contest_text())
    return text, _kb(
        [_b("✏️ تعديل نص الجوايز/الشروط", "adm:xtk:contest_extra", style="success")],
        [_b("🏆 تصفير الترتيب", "adm:xk2", style="danger")],
        _back())


# ---------------- 💰 الأسعار والتواصل ----------------
def ap2_money():
    st = DB["settings"]
    buy = st.get("buy_text") or "(الافتراضية)"
    text = (f"💰 <b>الأسعار والتواصل</b>\n{LINE}\n"
            f"👤 يوزر التواصل (DEV/الشراء): <b>{_esc(owner_un())}</b>\n"
            f"🎁 المحاولة المجانية: <b>{'شغالة' if st.get('free_trial', True) else 'مقفولة'}</b> "
            f"({st.get('free_attempts', 1)} محاولة × {st.get('free_chapters', 3)} فصول)\n\n"
            f"<b>رسالة الشراء الحالية:</b>\n{_esc(buy)[:900]}")
    return text, _kb(
        [_b("✏️ رسالة الشراء/الأسعار", "adm:ask_buy", style="success")],
        [_b("👤 تغيير يوزر التواصل", "adm:xme", style="primary")],
        [_b("🔘 زرار الشراء", "adm:xbk:buy_owner", style="primary"), _b("🔘 زرار اشترك", "adm:xbk:home_sub", style="primary")],
        [_b("🎁 إعدادات المحاولة المجانية", "adm:set", style="danger")],
        _back())


# ---------------- 🧰 الأدوات ----------------
def ap2_tools():
    text = (f"🧰 <b>أدوات سريعة</b>\n{LINE}\n"
            "عمليات جماعية على كل المستخدمين. كل زرار بيطلب تأكيد.")
    return text, _kb(
        [_b("🎁 فرص لكل المستخدمين", "adm:xgive", style="success")],
        [_b("🔄 تصفير المحاولات المجانية للكل", "adm:xtool2:trials", style="primary")],
        [_b("🔓 فك حظر الكل", "adm:xtool2:unban", style="primary")],
        [_b("⏹ إيقاف كل الجلسات الشغالة", "adm:xtool2:stop", style="danger")],
        [_b("🧹 مسح كاش الاشتراك", "adm:xtool2:cache")],
        _back())


# ---------------- 🖥 حالة النظام ----------------
def ap2_sys():
    running = [(k, u) for k, u in USERS.items() if u.get("running")]
    try:
        size = os.path.getsize(USERS_FILE) // 1024
    except Exception:
        size = 0
    courses = "\n".join(f"{'✅' if course_ready(c) else '⚠️'} {GRADES[k[0]]} • {course_name(c, k[1])}"
                        for k, c in COURSES.items() if len(k) == 2)
    errs = "\n".join(f"• {_ts(t)} [{_esc(w)}] <code>{_esc(e)[:90]}</code>" for t, w, e in ERRORS[-5:]) or "مفيش أخطاء ✅"
    text = (f"🖥 <b>حالة النظام</b>\n{LINE}\n"
            f"⏱ مدة التشغيل: <b>{_uptime()}</b>\n"
            f"⚡ جلسات شغالة: <b>{RUN_GATE.active}</b>\n"
            f"🚫 لا توجد مهام انتظار؛ الطلبات الزائدة تُرفض فورًا.\n"
            f"🧵 الحد الأقصى لعمليات الحل: <b>{SOLVE_WORKERS}</b> • معالجات تيليجرام: <b>{BOT_HANDLER_THREADS}</b>\n"
            f"📦 الحد الأقصى للتنفيذ المتزامن: <b>{SOLVE_WORKERS}</b>\n"
            f"💾 حجم القاعدة: <b>{size} KB</b> • 👥 {_n_users()}\n"
            f"🐍 Python {sys.version.split()[0]}\n\n"
            f"📚 <b>المواد:</b>\n{courses}\n\n"
            f"📜 <b>آخر الأخطاء:</b>\n{errs}")
    return text, _kb(
        [_b("🔄 تحديث", "adm:xs", style="primary"), _b("🗑 مسح الأخطاء", "adm:xserr", style="danger")],
        _back())


# ---------------- الموزّع ----------------
def ap2_dispatch(c, uid, act, a, chat, mid):
    answer, alert = "", False
    try:
        if not is_owner(uid):
            answer, alert = "⛔ للمالك فقط", True
        elif act == "xt":
            _show(chat, mid, *ap2_texts(int(a[0])))
        elif act == "xtk":
            assert a[0] in TEXTS
            _show(chat, mid, *ap2_text_card(a[0]))
        elif act == "xte":
            assert a[0] in TEXTS
            vars_ = TEXTS[a[0]][2]
            _ap_ask(uid, chat, mid, "xtext",
                    f"✏️ ابعت النص الجديد لـ <b>{TEXTS[a[0]][0]}</b>\n"
                    "(HTML مسموح، والمتغيرات بين أقواس: " + (" ".join("<code>{" + v + "}</code>" for v in vars_) or "مفيش") + ")",
                    data=a[0], back=f"adm:xtk:{a[0]}")
        elif act == "xtr":
            with DB_LOCK:
                (DB["settings"].get("texts") or {}).pop(a[0], None)
                save_db(DB)
            _show(chat, mid, *ap2_text_card(a[0]))
            answer = "♻️ رجع للأصلي"
        elif act == "xtp":
            cur = (DB["settings"].get("texts") or {}).get(a[0]) or TEXTS[a[0]][1]
            bot.send_message(chat, render_sample(cur), parse_mode="HTML")
            answer = "👁 اتبعتت المعاينة"
        # ---- الأزرار ----
        elif act == "xb":
            _show(chat, mid, *ap2_btns(int(a[0])))
        elif act == "xbk":
            assert a[0] in BUTTONS
            _show(chat, mid, *ap2_btn_card(a[0]))
        elif act == "xbe":
            assert a[0] in BUTTONS
            _ap_ask(uid, chat, mid, "xbtn", f"✏️ ابعت الاسم الجديد للزرار (إيموجي مسموح، بحد أقصى 40 حرف):\n"
                    f"الحالي: <b>{html.escape(btn_label(a[0]))}</b>", data=a[0], back=f"adm:xbk:{a[0]}")
        elif act in ("xbc", "xbh", "xbr"):
            assert a[0] in BUTTONS
            with DB_LOCK:
                ov = DB["settings"].setdefault("btn", {}).setdefault(a[0], {})
                if act == "xbc":
                    ov["s"] = _STY_CODE[a[1]]
                elif act == "xbh":
                    ov["h"] = not ov.get("h")
                else:
                    DB["settings"]["btn"].pop(a[0], None)
                save_db(DB)
            _show(chat, mid, *ap2_btn_card(a[0]))
        elif act == "xbauto":
            cyc = ["success", "primary", "danger"]
            with DB_LOCK:
                bt = DB["settings"].setdefault("btn", {})
                counters = {}
                for k, (grp, _l, _s) in BUTTONS.items():
                    n = counters.get(grp, 0)
                    counters[grp] = n + 1
                    if k in ("back", "home_invite", "home_help"):
                        bt.setdefault(k, {})["s"] = ""
                    else:
                        bt.setdefault(k, {})["s"] = cyc[n % 3]
                save_db(DB)
            _show(chat, mid, *ap2_btns(0))
            answer = "🎨 اتلونت الأزرار بألوان متنوعة"
        elif act == "xbreset":
            with DB_LOCK:
                DB["settings"]["btn"] = {}
                save_db(DB)
            _show(chat, mid, *ap2_btns(0))
            answer = "♻️ رجعت كل الأزرار للأصل"
        # ---- المواد ----
        elif act == "xc":
            _show(chat, mid, *ap2_courses())
        elif act == "xct":
            with DB_LOCK:
                off = DB["settings"].setdefault("course_off", [])
                k = f"{a[0]}:{a[1]}"
                if k in off:
                    off.remove(k)
                else:
                    off.append(k)
                save_db(DB)
            _show(chat, mid, *ap2_courses())
        elif act == "xsy":
            assert a[0] in SYSTEMS
            with DB_LOCK:
                off = DB["settings"].setdefault("system_off", [])
                if a[0] in off:
                    off.remove(a[0])
                else:
                    off.append(a[0])
                save_db(DB)
            _show(chat, mid, *ap2_courses())
        # ---- الترحيب ----
        elif act == "xw":
            _show(chat, mid, *ap2_welcome())
        elif act == "xwm":
            _ap_ask(uid, chat, mid, "xmedia", "🖼 ابعت <b>صورة</b> أو <b>GIF</b> أو <b>فيديو</b> للترحيب:", back="adm:xw")
        elif act in ("xwx", "xwr"):
            with DB_LOCK:
                if act == "xwx":
                    DB["settings"]["welcome_media"] = {"type": "none"}
                else:
                    DB["settings"].pop("welcome_media", None)
                save_db(DB)
            _show(chat, mid, *ap2_welcome())
        elif act == "xwp":
            send_home(chat, c.from_user.first_name)
            answer = "👁 اتبعتت المعاينة"
        # ---- المسابقة ----
        elif act == "xk":
            _show(chat, mid, *ap2_contest())
        elif act == "xk2":
            _show(chat, mid, "🏆 <b>تأكيد تصفير ترتيب المسابقة؟</b>\nكل نقاط المتسابقين هتتمسح (إحصائيات الحل الشخصية كمان).",
                  _kb([_b("✅ أيوه صفّر", "adm:xk3", style="danger"), _b("إلغاء", "adm:xk", style="success")]))
        elif act == "xk3":
            with DB_LOCK:
                DB["ustats"] = {}
                save_db(DB)
            _show(chat, mid, *ap2_contest())
            answer = "🏆 اتصفّر الترتيب"
        # ---- الأسعار والتواصل ----
        elif act == "xm":
            _show(chat, mid, *ap2_money())
        elif act == "xme":
            _ap_ask(uid, chat, mid, "xowner", "👤 ابعت يوزر التواصل الجديد (مثال: <code>@Hamo_fun</code>):", back="adm:xm")
        # ---- الأدوات ----
        elif act == "xtool":
            _show(chat, mid, *ap2_tools())
        elif act == "xgive":
            _ap_ask(uid, chat, mid, "xgive", "🎁 ابعت عدد الفرص اللي هتتضاف لكل مستخدم (رقم من 1 لـ 50):", back="adm:xtool")
        elif act == "xtool2":
            names = {"trials": "تصفير المحاولات المجانية للكل", "unban": "فك حظر الكل",
                     "stop": "إيقاف كل الجلسات الشغالة", "cache": "مسح كاش الاشتراك"}
            _show(chat, mid, f"⚠️ <b>تأكيد: {names[a[0]]}؟</b>",
                  _kb([_b("✅ تأكيد", f"adm:xtool3:{a[0]}", style="danger"), _b("إلغاء", "adm:xtool", style="success")]))
        elif act == "xtool3":
            with DB_LOCK:
                if a[0] == "trials":
                    DB["trial_used"] = {}
                    answer = "🔄 اتصفّرت المحاولات المجانية"
                elif a[0] == "unban":
                    DB["banned"] = {}
                    answer = "🔓 اتفك الحظر عن الكل"
                elif a[0] == "stop":
                    for u in USERS.values():
                        u["stop_requested"] = True
                        u["running"] = False
                    answer = "⏹ اتوقفت الجلسات"
                elif a[0] == "cache":
                    SUB_CACHE.clear()
                    answer = "🧹 اتمسح الكاش"
                save_db(DB)
            _show(chat, mid, *ap2_tools())
        # ---- النظام ----
        elif act == "xs":
            _show(chat, mid, *ap2_sys())
        elif act == "xserr":
            del ERRORS[:]
            _show(chat, mid, *ap2_sys())
        elif act == "xnum":
            if a[0] == "max_parallel":
                with DB_LOCK:
                    DB["settings"]["max_parallel"] = max(0, min(200, int(DB["settings"].get("max_parallel", 0) or 0) + int(a[1])))
                    save_db(DB)
            _show(chat, mid, *ap2_sys())
    except Exception as e:
        log_error("panel:" + act, e)
        answer, alert = "⚠️ حصل خطأ: " + str(e)[:150], True
    try:
        bot.answer_callback_query(c.id, answer, show_alert=alert)
    except Exception:
        pass


# ---------------- استقبال الإدخال (نص/ميديا) من المالك ----------------
def ap2_on_state(m, st):
    uid = m.from_user.id
    a, chat, mid, d = st["a"], st["chat"], st["msg"], st.get("d")
    t = (m.text or "").strip()
    try:
        if a == "xtext":
            if not m.text:
                AP_STATE[uid] = st
                return bot.reply_to(m, "⚠️ ابعت نص بس.")
            new = getattr(m, "html_text", None) or t
            _del(m.chat.id, m.message_id)
            try:
                bot.send_message(m.chat.id, render_sample(new), parse_mode="HTML")      # معاينة + تحقق من صحة الـ HTML
            except Exception as e:
                AP_STATE[uid] = st
                return _show(chat, mid, "⚠️ النص فيه خطأ في الـ HTML:\n<code>" + _esc(str(e)[:200]) +
                             "</code>\nابعت نص تاني 👇", _kb(_back(f"adm:xtk:{d}")))
            with DB_LOCK:
                texts = DB["settings"].setdefault("texts", {})
                if new == TEXTS[d][1]:
                    texts.pop(d, None)
                else:
                    texts[d] = new
                save_db(DB)
            _show(chat, mid, *ap2_text_card(d))
        elif a == "xbtn":
            if not m.text:
                AP_STATE[uid] = st
                return bot.reply_to(m, "⚠️ ابعت نص بس.")
            _del(m.chat.id, m.message_id)
            with DB_LOCK:
                DB["settings"].setdefault("btn", {}).setdefault(d, {})["l"] = t[:40]
                save_db(DB)
            _show(chat, mid, *ap2_btn_card(d))
        elif a == "xmedia":
            if m.content_type == "photo":
                media = {"type": "photo", "id": m.photo[-1].file_id}
            elif m.content_type == "animation":
                media = {"type": "animation", "id": m.animation.file_id}
            elif m.content_type == "video":
                media = {"type": "video", "id": m.video.file_id}
            else:
                AP_STATE[uid] = st
                return bot.reply_to(m, "⚠️ ابعت صورة أو GIF أو فيديو.")
            _del(m.chat.id, m.message_id)
            with DB_LOCK:
                DB["settings"]["welcome_media"] = media
                save_db(DB)
            _show(chat, mid, *ap2_welcome())
        elif a == "xowner":
            u = t.lstrip("@")
            if not re.fullmatch(r"[A-Za-z0-9_]{4,32}", u):
                AP_STATE[uid] = st
                return bot.reply_to(m, "⚠️ يوزر غير صالح. مثال: @Hamo_fun")
            _del(m.chat.id, m.message_id)
            with DB_LOCK:
                DB["settings"]["owner_username"] = "@" + u
                save_db(DB)
            _show(chat, mid, *ap2_money())
        elif a == "xgive":
            _del(m.chat.id, m.message_id)
            if not t.isdigit() or not (1 <= int(t) <= 50):
                AP_STATE[uid] = st
                return _show(chat, mid, "⚠️ ابعت رقم من 1 لـ 50 👇", _kb(_back("adm:xtool")))
            n = 0
            with DB_LOCK:
                for u in DB["users"]:
                    k = str(u)
                    cur = DB["credits"].get(k)
                    if cur == "max":
                        continue
                    DB["credits"][k] = (cur if isinstance(cur, int) else 0) + int(t)
                    n += 1
                save_db(DB)
            _show(chat, mid, f"🎁 اتضاف <b>{t}</b> فرصة لـ <b>{n}</b> مستخدم ✅", _kb(_back("adm:xtool")))
    except Exception as e:
        log_error("panel-input:" + str(a), e)
        _show(chat, mid, "⚠️ حصل خطأ: " + _esc(str(e)[:200]), _kb(_back()))



# ==========================================
# 🧯 تشغيل آمن للحل: أي خطأ بيتعرض بدل ما يفضل "جاري تسجيل الدخول" للأبد
# ==========================================
def _safe_run(fn, cid, message_id, *args):
    acquired = False
    try:
        acquired = RUN_GATE.acquire(
            stop=lambda: not USERS.get(cid, {}).get("running"),
        )
        if not acquired:
            try:
                bot.edit_message_text("⏹ تم إلغاء طلب الحل قبل بدء التنفيذ.", cid, message_id)
            except Exception:
                pass
            return
        fn(cid, message_id, *args)
    except Exception as e:
        err = f"{type(e).__name__}: {e}"
        print("RUN ERROR:", err)
        log_error("solve", err)
        try:
            # رسالة مفهومة للمستخدم؛ التفاصيل التقنية تبقى في سجل المالك فقط.
            bot.edit_message_text(
                "⚠️ <b>تعذر إكمال العملية حاليًا.</b>\n"
                "تم تسجيل المشكلة للمراجعة، ولم يتم تأكيد نجاح غير مكتمل.",
                cid, message_id, parse_mode="HTML"
            )
        except Exception:
            pass
        try:
            _to_owners(f"⚠️ خطأ في الحل للمستخدم <code>{cid}</code>:\n<code>{html.escape(err[:500])}</code>",
                             parse_mode="HTML")
        except Exception:
            pass
    finally:
        if acquired:
            RUN_GATE.release()
        close_run_session(cid)
        try:
            USERS[cid]["running"] = False
        except Exception:
            pass


SUBJECT_EMOJI = {"py": "🐍", "js": "🟨", "spx": "💰"}


def method_text(cid):
    st = USERS.get(cid, {})
    courses = grade_courses(st.get("grade"), st.get("system"))
    subjects = "\n".join(f"{i}. {SUBJECT_LINES[m]}" for i, (m, _c) in enumerate(courses, 1))
    return (
        "🗂 <b>حسابك على المنصة</b>\n\n"
        f"<blockquote>👤 الكود: <code>{html.escape(str(st.get('login_id', '')))}</code>\n{plan_text(cid)}</blockquote>\n\n"
        "⬇️ <b>الخطوة الأخيرة: اختار طريقة الحل</b>\n"
        "<blockquote>▶️ حل تلقائي ← البوت يحل المواد دي واحدة ورا التانية من غير ما تكتب حاجة\n"
        "📋 اختار المادة بنفسك ← لمادة واحدة أو فصول معينة</blockquote>\n\n"
        "💡 تقدر تقفل البوت وإنت بتحل، وهيجيلك إشعار لما الحل يخلص\n"
        f"<blockquote>{subjects}</blockquote>"
    )


def kb_method():
    return _kbn([BT("method_auto", "start_solve")], [BT("method_pick", "pick_subject")], [BT("back", "cancel")])


def _start_job(cid, msg_id=None, only=None, selected=None):
    """بيبدأ الحل. بيرجّع (نجح؟، نص تنبيه). نص فاضي = اتبعتت رسالة بالفعل (مثلاً شاشة الشراء)."""
    plan, lim = user_plan(cid)
    if plan == "none":
        show_buy(cid)
        return False, ""
    st = USERS.get(cid, {})
    if st.get("running") or user_worker_alive(cid):
        return False, T("busy")
    g = st.get("grade")
    courses = grade_courses(g, st.get("system")) if g else []
    if only:
        courses = [(m, c) for m, c in courses if m == only]
    if "login_id" not in st or "password" not in st or not courses:
        return False, T("data_missing")
    st["running"] = True
    st["stop_requested"] = False
    mid = msg_id
    try:
        if msg_id:
            bot.edit_message_text("⏳ جاري تجهيز عملية الحل...", cid, msg_id, reply_markup=_run_kb())
        else:
            mid = bot.send_message(cid, "⏳ جاري تجهيز عملية الحل...", reply_markup=_run_kb()).message_id
    except Exception:
        pass
    if not mid:
        st["running"] = False
        return False, "حصل عطل مؤقت؛ لم يبدأ الحل. حاول مرة أخرى."
    try:
        future = submit_solve(cid, run_all_subjects,
                              (mid, st["login_id"], st["password"], g, st.get("system"), only, selected))
    except Exception:
        st["running"] = False
        logging.exception("Could not start solve worker for user %s", cid)
        try:
            bot.edit_message_text("⚠️ حصل عطل مؤقت؛ لم يبدأ الحل. حاول مرة أخرى.", cid, mid, reply_markup=None)
        except Exception:
            pass
        return False, "حصل عطل مؤقت في تشغيل المهمة. حاول مرة أخرى."
    if future is None:
        st["running"] = False
        busy_text = "⚠️ البوت مشغول حاليًا. جرّب بعد قليل؛ لم يبدأ الحل ولم تُخصم محاولة."
        try:
            bot.edit_message_text(busy_text, cid, mid, reply_markup=None)
        except Exception:
            pass
        return False, busy_text
    return True, (T("started") if plan != "trial" else T("started_trial", chapters=lim))


def run_all_subjects(cid, message_id, login_id, password, grade, system=None, only=None, selected=None):
    """بيحل كل مواد السنة بالترتيب (رسالة تقدم منفصلة لكل مادة)."""
    items = grade_courses(grade, system)
    if only:
        items = [(m, c) for m, c in items if m == only]
    bump_run(cid)
    before = int((DB["ustats"].get(str(cid)) or {}).get("chapters", 0))
    ran = 0
    for idx, (mat, course) in enumerate(items):
        st = USERS.get(cid, {})
        if not st.get("running") or st.get("stop_requested"):
            break
        if user_plan(cid)[0] == "none":
            show_buy(cid)
            break
        name = SUBJECT_NAMES.get(mat) or course_name(course, mat)
        if idx == 0:
            mid = message_id
        else:
            try:
                mid = bot.send_message(cid, f"⏳ جاري تجهيز {name}...",
                                       reply_markup=_run_kb()).message_id
            except Exception:
                logging.exception("Could not send progress message for user %s", cid)
                break
        try:
            if course["kind"] == "spx":
                run_spx_tool(cid, mid, login_id, password, course)
            else:
                ids = qureo_chapter_ids(course, load_json(course.get("file", "")))
                if selected:
                    ids = [i for i in ids if i in set(int(x) for x in selected)]
                if not ids:
                    bot.edit_message_text(f"⚠️ مش قادرين نقرأ قائمة فصول {name} حاليًا.", cid, mid)
                    continue
                run_qureo_tool(cid, mid, login_id, password, course, name, ids)
            ran += 1
            _deliver_result(cid)
        except Exception as e:
            err = f"{type(e).__name__}: {e}"
            print("RUN ERROR:", err)
            log_error("solve", err)
            try:
                bot.edit_message_text(f"❌ <b>حصل خطأ في {html.escape(name)}:</b>\n<code>{html.escape(err[:300])}</code>",
                                      cid, mid, parse_mode="HTML", reply_markup=None)
            except Exception:
                pass
            try:
                _to_owners(f"⚠️ خطأ في الحل للمستخدم <code>{cid}</code>:\n<code>{html.escape(err[:500])}</code>",
                           parse_mode="HTML")
            except Exception:
                pass
    after = int((DB["ustats"].get(str(cid)) or {}).get("chapters", 0))
    if after > before:
        bump_run(cid, accounts=1, runs=0)
    st = USERS.get(cid, {})
    stopped = bool(st.get("stop_requested"))
    try:
        close_run_session(cid)
    except Exception:
        pass
    for _k in ("login_id", "password", "selected_chapters", "pending_mat", "last_result"):    # مسح بيانات الدخول من الذاكرة
        st.pop(_k, None)
    if ran and not stopped:
        try:
            bot.send_message(cid, "✅ <b>خلص الحل</b>\n\n"
                             + _quote("🔒 انتهى الحل واتمسحت بيانات دخولك من البوت.\n"
                                      "لحل مادة تانية فيه، ادخل بالكود وكلمة المرور من جديد."),
                             parse_mode="HTML", reply_markup=_kbn([BT("to_home", "n:home")]))
        except Exception:
            pass


# ==========================================
# 🧠 استقبال الأزرار
# ==========================================
def _ack(call, text=None, alert=False):
    try:
        bot.answer_callback_query(call.id, text, show_alert=alert) if text else bot.answer_callback_query(call.id)
    except Exception:
        pass


def _say(cid, text, kb=None):
    try:
        bot.send_message(cid, text, reply_markup=kb, parse_mode="HTML", disable_web_page_preview=True)
    except Exception as e:
        print(f"Send Error: {e}")


def _drop(call):
    try:
        bot.delete_message(call.message.chat.id, call.message.message_id)
    except Exception:
        pass


@bot.callback_query_handler(func=lambda c: not (c.data or "").startswith("adm:"))
def cb(call):
    cid = call.message.chat.id
    d = call.data or ""
    track_user(call.message.chat)
    if not user_gate(cid, call):          # حظر / صيانة / اشتراك القناة — على كل زر
        return
    if cid not in USERS:
        USERS[cid] = {"running": False}

    # زر رجوع: نمسح الرسالة الحالية ونرجّع الشاشة اللي قبلها
    if d.startswith("b:"):
        _drop(call)
        d = d[2:]

    # ---------- الرئيسية ----------
    if d == "n:home":
        _ack(call)
        send_home(cid, call.from_user.first_name, DB.get("credits", {}).get(str(cid)) == "max")

    elif d in ("n:account", "n:stats", "my_stats"):
        _ack(call)
        _say(cid, account_text(cid, call.from_user.first_name), kb_account())

    elif d == "n:contest":
        _ack(call)
        _say(cid, contest_text(), _kbn([BT("back", "b:n:home")]))

    elif d == "n:sub":
        _ack(call)
        if free_mode_on():
            _say(cid, "🎁 <b>الحل مجاني للكل دلوقتي</b>\n\nمفيش اشتراك ولا دفع — دوس «ابدأ حل حسابك» واستمتع.",
                 _kbn([BT("back", "b:n:home")]))
        else:
            show_buy(cid, exhausted=(user_plan(cid)[0] == "none"))

    elif d == "n:balance":
        _ack(call)
        _say(cid, T("balance", plan=plan_text(cid), count=invite_count(cid)), kb_account())

    elif d == "n:invite":
        _ack(call)
        link = invite_link(cid)
        share = ("https://t.me/share/url?url=" + quote(link, safe="") + "&text="
                 + quote("🎓 بوت كيريو بيحل فصولك على المنصة لوحده — ادخل من الرابط ده", safe=""))
        _say(cid, T("invite", link=link, count=invite_count(cid)),
             _kbn([BT("invite_share", url=share)], [BT("back", "b:n:home")]))

    elif d == "n:help":
        _ack(call)
        _say(cid, T("help"), _kbn([BT("back", "b:n:home")]))

    # ---------- السنة ← المواد + طلب الكود ----------
    elif d == "n:start":
        _ack(call)
        _say(cid, T("pick_system"), kb_systems())

    elif d.startswith("sy:"):
        sy = (d.split(":") + [""])[1]
        if sy not in SYSTEMS or not system_enabled(sy):
            return _ack(call)
        _ack(call)
        if not system_grades(sy):
            _say(cid, T("soon", mat=SYSTEMS[sy]), _kbn([BT("back", "b:n:start")]))
            return
        _say(cid, T("pick_grade", system=SYSTEMS[sy]), kb_grades(sy))

    elif d.startswith("g:"):
        parts = d.split(":")
        sy = parts[1] if len(parts) > 2 else ""
        g = parts[2] if len(parts) > 2 else ""
        if sy not in SYSTEMS or g not in GRADE_TITLES or g not in SYSTEM_GRADES.get(sy, []):
            return _ack(call)
        courses = grade_courses(g, sy)
        if not courses:
            _ack(call)
            _say(cid, T("soon", mat=f"{GRADE_TITLES[g]} – {SYSTEMS[sy]}"), _kbn([BT("back", f"b:n:start")]))
            return
        if user_plan(cid)[0] == "none":      # خلص رصيده؟ نوقفه قبل ما يكتب بياناته
            _ack(call)
            show_buy(cid)
            return
        if USERS.get(cid, {}).get("running") or user_worker_alive(cid):
            return _ack(call, T("busy"), True)
        _ack(call)
        USERS[cid] = {"running": False, "system": sy, "grade": g}     # بيانات دخول جديدة لكل مرة
        subjects = "\n".join(f"{i}. {SUBJECT_LINES[m]}" for i, (m, _c) in enumerate(courses, 1))
        _say(cid, T("ask_id2", grade=f"{GRADE_TITLES[g]} – {SYSTEMS[sy]}", subjects=subjects),
             _kbn([BT("cancel", "cancel")]))

    elif d == "cancel":
        old = USERS.get(cid, {})
        if old.get("running") or user_worker_alive(cid):
            return _ack(call, T("busy"), True)
        _ack(call)
        _drop(call)
        USERS[cid] = {"running": False, "stop_requested": bool(old.get("stop_requested", False))}
        send_home(cid, call.from_user.first_name, DB.get("credits", {}).get(str(cid)) == "max")

    # ---------- إيقاف عملية المستخدم ----------
    elif d == "stop_run":
        st = USERS.get(cid, {})
        if st.get("running"):
            st["stop_requested"] = True
            st["running"] = False
            _ack(call, T("stopping"))
            try:
                bot.edit_message_text(T("stopping"), cid, call.message.message_id,
                                      parse_mode="HTML", reply_markup=None)
            except Exception:
                pass
        else:
            _ack(call, "مفيش عملية شغالة حاليًا.", True)

    # ---------- بدء الحل التلقائي لكل المواد ----------
    elif d == "start_solve":
        ok, note = _start_job(cid, call.message.message_id)
        if note:
            _ack(call, note, not ok)
        else:
            _ack(call)

    elif d == "n:method":
        st = USERS.get(cid, {})
        if "login_id" not in st or "password" not in st:
            _ack(call, T("expired"), True)
            return
        _ack(call)
        _drop(call)
        _say(cid, method_text(cid), kb_method())

    elif d == "pick_subject":
        st = USERS.get(cid, {})
        courses = grade_courses(st.get("grade"), st.get("system")) if st.get("grade") else []
        if "login_id" not in st or "password" not in st or not courses:
            return _ack(call, T("data_missing"), True)
        _ack(call)
        rows = [[_b(f"{SUBJECT_NAMES[m]} {SUBJECT_EMOJI.get(m, '📘')}", f"ps:{m}", style="primary")]
                for m, _c in courses]
        rows.append([BT("back", "n:method")])
        lines = "\n".join(f"{i}. {SUBJECT_LINES[m]}" for i, (m, _c) in enumerate(courses, 1))
        _say(cid, f"📋 <b>اختار المادة</b>\n\n<blockquote>{lines}</blockquote>", _kbn(*rows))

    elif d.startswith("ps:"):
        m = (d.split(":") + [""])[1]
        st = USERS.get(cid, {})
        g, sy = st.get("grade"), st.get("system")
        course = get_course(g, "gen", m, sy) if g else None
        if (not course or "login_id" not in st or "password" not in st
                or m not in GRADE_SUBJECTS.get(g, []) or not course_enabled(g, m)):
            return _ack(call, T("data_missing"), True)
        if course.get("kind") == "qureo":
            _ack(call)
            total = len(qureo_chapter_ids(course, load_json(course.get("file", ""))))
            st["pending_mat"] = m
            ask = bot.send_message(
                cid,
                f"📚 <b>حدد الفصول المطلوبة</b>\n\n"
                f"إجمالي الفصول المتاحة: <b>{total}</b>\n"
                "اكتب أرقام الفصول أو نطاقات، مثال: <code>1-5، 8، 10-12</code>\n"
                "أو اكتب <code>الكل</code> لحل جميع الفصول.",
                parse_mode="HTML", reply_markup=_kbn([BT("cancel", "cancel")]))
            bot.register_next_step_handler(ask, step_chapter_selection)
        else:
            ok, note = _start_job(cid, call.message.message_id, only=m)
            if note:
                _ack(call, note, not ok)
            else:
                _ack(call)

    elif d.startswith("card:"):
        try:
            _p = d.split(":")
            _done, _total = max(0, int(_p[1])), max(0, int(_p[2]))
        except Exception:
            return _ack(call)
        _ack(call)
        _send_account_card(cid, _done, _total)

    else:
        _ack(call)


# ==========================================
# 🆔 استقبال الكود والباسورد
# ==========================================
def _waiting_id(msg):
    st = USERS.get(msg.chat.id)
    return bool(st) and st.get("grade") and "login_id" not in st


@bot.message_handler(func=_waiting_id, content_types=["text"])
def step_id(msg):
    cid = msg.chat.id
    if not user_gate(cid):
        return
    login_id = (msg.text or '').strip()
    try:
        bot.delete_message(cid, msg.message_id)
    except Exception:
        logging.info("Could not delete submitted login ID message for user %s", cid)
    if not login_id or len(login_id) > 128:
        bot.send_message(cid, "⚠️ الكود غير صالح أو طويل جدًا. حاول مرة أخرى.")
        return
    USERS[cid]['login_id'] = login_id
    m = bot.send_message(cid, T("ask_pass"), parse_mode="HTML")
    bot.register_next_step_handler(m, step_pass)


def step_pass(msg):
    cid = msg.chat.id
    if not user_gate(cid):
        return
    if not getattr(msg, "text", None) or msg.text.startswith("/"):
        USERS.get(cid, {}).pop("login_id", None)
        bot.send_message(cid, T("cancelled"), parse_mode="HTML")
        return
    pw = msg.text.strip()
    try: bot.delete_message(cid, msg.message_id)
    except Exception: logging.info("Could not delete submitted password message for user %s", cid)
    if not pw or len(pw) > 256:
        USERS.get(cid, {}).pop('login_id', None)
        bot.send_message(cid, "⚠️ كلمة السر غير صالحة أو طويلة جدًا. ابدأ من جديد.")
        return
    if cid not in USERS or 'grade' not in USERS[cid]:
        bot.send_message(cid, T("expired"), parse_mode="HTML")
        return
    USERS[cid]['password'] = pw

    plan, _x = user_plan(cid)
    if plan == "none":
        show_buy(cid)
        return

    note = ("\n\n" + T("trial_note", chapters=_x)) if plan == "trial" else ""
    bot.send_message(cid, method_text(cid) + note, reply_markup=kb_method(), parse_mode="HTML")


def step_chapter_selection(msg):
    cid = msg.chat.id
    if not user_gate(cid):
        return
    if (getattr(msg, "text", "") or "").startswith("/"):
        bot.send_message(cid, T("cancelled"), parse_mode="HTML")
        return
    st = USERS.get(cid, {})
    m, g, sy = st.get("pending_mat"), st.get("grade"), st.get("system")
    course = get_course(g, "gen", m, sy) if (g and m) else None
    if not course or course.get("kind") != "qureo" or "login_id" not in st or "password" not in st:
        bot.send_message(cid, T("expired"), parse_mode="HTML")
        return
    ids = qureo_chapter_ids(course, load_json(course.get("file", "")))
    try:
        positions = parse_chapter_selection(getattr(msg, "text", ""), len(ids))
    except ValueError as exc:
        ask = bot.send_message(cid, f"⚠️ {html.escape(str(exc))}\n\nحاول مرة تانية:", parse_mode="HTML")
        bot.register_next_step_handler(ask, step_chapter_selection)
        return
    ok, note = _start_job(cid, None, only=m, selected=[ids[pos - 1] for pos in positions])
    if note and not ok:
        bot.send_message(cid, note, parse_mode="HTML")


# ==========================================
# 🚀 تشغيل البوت
# ==========================================
if __name__ == "__main__":
    print(f"👑 Hamo Bot started | handlers={HANDLER_MODE} | solve_workers={SOLVE_WORKERS} | solve_queue=disabled | progress_interval={PROGRESS_EDIT_INTERVAL}s | fast_json={bool(_fast_json)}")
    try:
        me = bot.get_me()
        print(f"✅ متصل كـ @{me.username} | owners={len(OWNER_IDS)} | direct_http=true")
        if DB["settings"].get("linked_bot") != me.id:      # أول تشغيل بالتوكن ده → تأكيد للمالك مرة واحدة بس
            _to_owners(f"✅ <b>البوت اتربط بنجاح</b>\n🤖 @{me.username}\n👑 المالك: {owner_un()}", parse_mode="HTML")
            with DB_LOCK:
                DB["settings"]["linked_bot"] = me.id
                save_db(DB)
    except Exception as e:
        logging.error("Telegram connection check failed; verify BOT_TOKEN and network configuration")
    while True:
        try:
            bot.infinity_polling(timeout=45, long_polling_timeout=45, skip_pending=True)
        except Exception:
            logging.exception("Polling disconnected; retrying in 5 seconds")
            time.sleep(5)