"""Qureo login and chapter-solving client using the reviewed public API flow."""

from __future__ import annotations

import threading
from collections.abc import Callable
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .data import AnswerBank

PORTAL = "https://me-portal.qureo.education"
API = "https://me-tp.qureo.education"
COURSES = {
    "javascript_g1": {
        "content_id": "javascript_ar",
        "label": "JavaScript (أولى ثانوي)",
    },
    "javascript": {"content_id": "javascript_ar", "label": "JavaScript"},
    "python": {"content_id": "python_short_ar", "label": "Python"},
}


class QureoAPI:
    def __init__(self, student_id: str, password: str, timeout: int = 25):
        self.student_id = student_id
        self.password = password
        self.timeout = max(timeout, 60)
        self.session = requests.Session()
        # Match the reviewed Max session: do not silently inherit a machine
        # proxy, and retry transient GET failures without replaying PUTs.
        self.session.trust_env = False
        retry_options = {
            "total": 3,
            "connect": 3,
            "read": 1,
            "status": 2,
            "backoff_factor": 0.7,
            "status_forcelist": (429, 502, 503, 504),
            "raise_on_status": False,
        }
        try:
            retry = Retry(
                allowed_methods=frozenset(("GET", "HEAD", "OPTIONS")),
                **retry_options,
            )
        except TypeError:
            retry = Retry(
                method_whitelist=frozenset(("GET", "HEAD", "OPTIONS")),
                **retry_options,
            )
        adapter = HTTPAdapter(
            max_retries=retry, pool_connections=10, pool_maxsize=20
        )
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)
        self.session.headers.update(
            {
                "accept": "application/json, text/plain, */*",
                "content-type": "application/json",
                "origin": API,
                "referer": f"{API}/",
                "authority": "me-tp.qureo.education",
                "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/139.0.0.0 Safari/537.36",
            }
        )

    def login(self) -> tuple[bool, str]:
        headers = {"origin": PORTAL, "referer": f"{PORTAL}/"}
        try:
            response = self.session.post(
                f"{PORTAL}/oauth2/password-login",
                json={"student_id": self.student_id, "password": self.password},
                headers=headers,
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            return False, f"تعذر الاتصال بمنصة Qureo ({type(exc).__name__})."
        token = self.session.cookies.get("egy_student_access_token")
        if response.status_code == 200 and token:
            self.session.headers["authorization"] = f"Bearer {token}"
            return True, ""
        if response.status_code in (401, 403):
            return False, "بيانات الدخول إلى Qureo غير صحيحة أو الحساب غير مخوّل."
        return False, f"تعذر تسجيل الدخول إلى Qureo (HTTP {response.status_code})."

    def _request(self, method: str, path: str, **kwargs: Any) -> requests.Response:
        return self.session.request(
            method, f"{API}{path}", timeout=self.timeout, **kwargs
        )

    def _status(self, chapter_id: str, content_id: str) -> tuple[int, bool]:
        self.session.cookies.set(
            "student_selected_content_id", content_id, domain="me-tp.qureo.education"
        )
        self.session.cookies.set(
            "_cf_s_path",
            f"/contents/chapter/{chapter_id}",
            domain="me-tp.qureo.education",
        )
        try:
            response = self._request(
                "GET", f"/api/study/students/chapters/{chapter_id}"
            )
            if response.status_code == 200:
                data = response.json()
                return int(data.get("best_correct_count") or 0), data.get(
                    "completed_at"
                ) is not None
        except (requests.RequestException, ValueError, TypeError):
            pass
        return 0, False

    def _complete_lectures(self, chapter_id: str, content_id: str) -> bool:
        self.session.cookies.set(
            "student_selected_content_id", content_id, domain="me-tp.qureo.education"
        )
        self.session.cookies.set(
            "_cf_s_path",
            f"/contents/chapter/{chapter_id}",
            domain="me-tp.qureo.education",
        )
        try:
            response = self._request("GET", f"/api/study/chapters/{chapter_id}")
            lectures = (
                response.json().get("lectures", [])
                if response.status_code == 200
                else []
            )
            if not lectures:
                fallback = self._request(
                    "GET", f"/api/study/students/chapters/{chapter_id}/lectures"
                )
                if fallback.status_code == 200:
                    payload = fallback.json()
                    lectures = payload if isinstance(payload, list) else []
            if not lectures:
                return False
            for lecture in lectures:
                lecture_id = lecture.get("id")
                if lecture_id is None:
                    continue
                self._request(
                    "PUT", f"/api/study/students/lectures/{lecture_id}", json={}
                )
                complete = self._request(
                    "PUT",
                    f"/api/study/students/lectures/{lecture_id}/complete",
                    json={},
                )
                if complete.status_code not in (200, 204):
                    return False
            return True
        except (requests.RequestException, ValueError, TypeError):
            return False

    @staticmethod
    def _entry_answer(entry: Any) -> Any:
        if isinstance(entry, dict):
            return entry.get("answer")
        if isinstance(entry, (tuple, list)) and len(entry) > 1:
            return entry[1]
        return entry

    @staticmethod
    def _extract_questions(payload: Any) -> list[dict[str, Any]] | None:
        if isinstance(payload, list):
            questions = [
                item
                for item in payload
                if isinstance(item, dict)
                and any(key in item for key in ("question", "choices", "descriptions"))
            ]
            return questions or None
        if isinstance(payload, dict):
            for key in (
                "questions",
                "review_questions",
                "test_questions",
                "reviewQuestions",
                "testQuestions",
                "res",
                "list",
            ):
                questions = QureoAPI._extract_questions(payload.get(key))
                if questions:
                    return questions
            for key in ("data", "result"):
                questions = QureoAPI._extract_questions(payload.get(key))
                if questions:
                    return questions
        return None

    def _get_chapter_questions(
        self, chapter_id: str, test_type: str
    ) -> tuple[list[dict[str, Any]] | None, str, str, str]:
        other_type = "test" if test_type == "review" else "review"
        candidates = [
            (test_type, f"/api/study/chapters/{chapter_id}/{test_type}"),
            (test_type, f"/api/study/students/chapters/{chapter_id}/{test_type}"),
            (other_type, f"/api/study/chapters/{chapter_id}/{other_type}"),
            (other_type, f"/api/study/students/chapters/{chapter_id}/{other_type}"),
        ]
        attempted: list[tuple[str, int | str]] = []
        for activity_type, path in candidates:
            try:
                response = self._request("GET", path)
            except requests.RequestException as exc:
                attempted.append((path, type(exc).__name__))
                continue
            attempted.append((path, response.status_code))
            if response.status_code != 200:
                continue
            try:
                questions = self._extract_questions(response.json())
            except ValueError:
                questions = None
            if questions:
                return questions, activity_type, "", ""

        status_summary = "; ".join(
            f"{path.rsplit('/', 1)[-1]}={status}" for path, status in attempted
        )
        primary_attempts = attempted[:2]
        state = (
            "locked"
            if len(primary_attempts) == 2
            and all(status == 403 for _, status in primary_attempts)
            else "http_error"
        )
        detail = status_summary[:240] or "no Qureo endpoint response"
        return None, test_type, state, detail

    def _solve_chapter(
        self,
        chapter_id: str,
        content_id: str,
        course: str,
        bank: AnswerBank,
        cancel: threading.Event,
    ) -> dict[str, Any]:
        self.session.cookies.set(
            "student_selected_content_id", content_id, domain="me-tp.qureo.education"
        )
        self.session.cookies.set(
            "_cf_s_path",
            f"/contents/chapter/{chapter_id}",
            domain="me-tp.qureo.education",
        )
        chapter_answers = bank.qureo_answers(course, chapter_id)
        if course == "javascript_g1":
            chapter_meta = bank.javascript_first_grade.get(str(chapter_id), {})
        elif course == "javascript":
            chapter_meta = bank.javascript.get(str(chapter_id), {})
        else:
            chapter_meta = bank.python.get(str(chapter_id), {})
        test_type = chapter_meta.get("test_type", "test")
        if test_type not in ("test", "review"):
            test_type = "test"
        question_kind = "review-questions" if test_type == "review" else "test-questions"
        fallback_question_kind = (
            "test-questions" if test_type == "review" else "review-questions"
        )
        expected_total = len(chapter_answers)
        # This status is fetched from this QureoAPI instance's live student
        # session. Do not use a bank-size threshold or another user's progress
        # to decide whether this account has already completed the chapter.
        before_count, already_done = self._status(chapter_id, content_id)
        if already_done:
            return {
                "state": "already_done",
                "solved": min(before_count, expected_total),
                "total": expected_total,
                "verified": True,
            }

        self._complete_lectures(chapter_id, content_id)
        # Start the chapter's actual activity (review or test) before fetching it.
        # Qureo-main does this first; requesting /test for a review chapter can
        # return HTTP 403 and be incorrectly reported as a locked chapter.
        self._request(
            "PUT",
            f"/api/study/students/chapters/{chapter_id}/{test_type}",
            json={},
        )
        questions, actual_type, error_state, detail = self._get_chapter_questions(
            chapter_id, test_type
        )
        if not questions:
            return {
                "state": error_state,
                "solved": 0,
                "total": 0,
                "detail": detail,
            }
        question_kind = (
            "review-questions" if actual_type == "review" else "test-questions"
        )
        fallback_question_kind = (
            "test-questions" if actual_type == "review" else "review-questions"
        )

        submitted = 0
        missing = 0
        for item in questions:
            if cancel.is_set():
                return {
                    "state": "stopped",
                    "solved": submitted,
                    "total": len(questions),
                }
            question = item.get("question") or {}
            qid = str(question.get("id", ""))
            qtype = question.get("type")
            answer = self._entry_answer(chapter_answers.get(qid))
            if answer is None:
                missing += 1
                continue
            try:
                if qtype == "description":
                    route = (
                        f"/api/study/students/{question_kind}/{qid}/answer/description"
                    )
                    payload = {"answer_code": str(answer)}
                elif qtype == "choice":
                    route = (
                        f"/api/study/students/{question_kind}/{qid}/answer/choice"
                    )
                    payload = {"choice_id": int(answer)}
                else:
                    missing += 1
                    continue
                answer_response = self._request("PUT", route, json=payload)
            except (requests.RequestException, TypeError, ValueError):
                continue
            if answer_response.status_code in (200, 204):
                submitted += 1
                continue
            # Fall back to the alternate Qureo question endpoint only after the
            # chapter's declared activity endpoint rejects the known answer.
            fallback_route = route.replace(question_kind, fallback_question_kind)
            try:
                fallback = self._request("PUT", fallback_route, json=payload)
                if fallback.status_code in (200, 204):
                    submitted += 1
            except requests.RequestException:
                continue

        best, completed = self._status(chapter_id, content_id)
        verified = completed and best >= len(questions)
        if verified:
            state = "completed"
        elif cancel.is_set():
            state = "stopped"
        elif missing:
            state = "partial"
        else:
            state = "unverified"
        return {
            "state": state,
            "solved": min(len(questions), max(best, submitted)),
            "total": len(questions),
            "missing": missing,
            "verified": verified,
        }

    def run_course(
        self,
        course: str,
        bank: AnswerBank,
        cancel: threading.Event,
        progress: Callable[[str], None] | None = None,
    ) -> dict[str, Any]:
        spec = COURSES[course]
        content_id = spec["content_id"]
        if course == "javascript_g1":
            source = bank.javascript_first_grade
        elif course == "javascript":
            source = bank.javascript
        else:
            source = bank.python
        chapter_ids = sorted(source.keys(), key=lambda key: int(key))
        stats = {
            "course": course,
            "chapters_total": len(chapter_ids),
            "chapters_done": 0,
            "chapters_partial": 0,
            "chapters_locked": 0,
            "questions_solved": 0,
            "questions_total": 0,
            "stopped": False,
            "failure_chapter": None,
            "failure_state": None,
            "failure_detail": None,
        }
        for index, chapter_id in enumerate(chapter_ids, 1):
            if cancel.is_set():
                stats["stopped"] = True
                break
            result = self._solve_chapter(chapter_id, content_id, course, bank, cancel)
            stats["questions_solved"] += int(result.get("solved", 0))
            stats["questions_total"] += int(result.get("total", 0))
            if result["state"] in ("completed", "already_done"):
                stats["chapters_done"] += 1
            elif result["state"] == "stopped":
                stats["stopped"] = True
                break
            else:
                if result["state"] == "locked":
                    stats["chapters_locked"] += 1
                else:
                    stats["chapters_partial"] += 1
                stats["failure_chapter"] = chapter_id
                stats["failure_state"] = result["state"]
                stats["failure_detail"] = result.get("detail")
                if progress:
                    detail = result.get("detail")
                    suffix = f" ({detail})" if detail else ""
                    progress(
                        f"{spec['label']}: فصل {index}/{len(chapter_ids)} — "
                        f"{result['state']}{suffix}؛ أوقفت المحاولة هنا"
                    )
                # Qureo unlocks chapters in order. Continuing after the first
                # failure only creates misleading 403/locked messages later.
                break
            if progress:
                progress(
                    f"{spec['label']}: فصل {index}/{len(chapter_ids)} — {result['state']}"
                )
        return stats
