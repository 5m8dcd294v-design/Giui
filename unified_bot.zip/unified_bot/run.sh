#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[[ -f .env ]] || { echo 'Missing unified_bot/.env; copy .env.example to .env and fill BOT_TOKEN and OWNER_ID.'; exit 1; }
cd ..
python3 -m unified_bot.main
