from __future__ import annotations

import os
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:
    def load_dotenv(*args, **kwargs):
        return False

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
load_dotenv(ROOT / ".env")


class Settings:
    bot_token = os.getenv("BOT_TOKEN", "").strip()
    request_timeout = float(os.getenv("REQUEST_TIMEOUT", "30"))
    site_proxy = os.getenv("SITE_PROXY", "").strip() or None
    qureo_base = os.getenv("QUREO_BASE", "https://me-tp.qureo.education").rstrip("/")
    qureo_portal = os.getenv("QUREO_PORTAL", "https://me-portal.qureo.education").rstrip("/")
    spx_base = os.getenv("SPX_BASE", "https://egy.app.spx-learning-square.com").rstrip("/")
    spx_subject = int(os.getenv("SPX_SUBJECT", "7"))


DATA_DIR.mkdir(parents=True, exist_ok=True)
