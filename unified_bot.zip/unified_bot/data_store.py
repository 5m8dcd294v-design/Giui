from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import DATA_DIR


def _load(name: str) -> dict[str, Any]:
    path = DATA_DIR / name
    with path.open(encoding="utf-8") as fh:
        return json.load(fh)


class QuestionBanks:
    def __init__(self) -> None:
        self.javascript = _load("javascript.json").get("chapters", {})
        self.python = _load("python.json").get("chapters", {})
        self.financial_levels = _load("financial.json").get("levels", {})

    def qureo_answer(self, course: str, question_id: str) -> Any:
        chapters = self.javascript if course == "javascript" else self.python
        for chapter in chapters.values():
            item = chapter.get("questions", {}).get(str(question_id), {})
            if item:
                return item.get("answer")
        return None

    def financial_answer(self, question_text: str) -> str | None:
        normalized = " ".join((question_text or "").split()).strip()
        for level in self.financial_levels.values():
            for item in level.get("questions", []):
                if " ".join(str(item.get("question", "")).split()).strip() == normalized:
                    return item.get("answer")
        return None
