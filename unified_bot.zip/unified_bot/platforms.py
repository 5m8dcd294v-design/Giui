from __future__ import annotations

import html
import logging
import time
from collections.abc import Callable
from typing import Any

import requests

from .config import Settings
from .data_store import QuestionBanks

log = logging.getLogger(__name__)
Progress = Callable[[str], None]


class APIError(RuntimeError):
    pass


def _session() -> requests.Session:
    s = requests.Session()
    s.trust_env = False
    if Settings.site_proxy:
        s.proxies.update({"http": Settings.site_proxy, "https": Settings.site_proxy})
    s.headers.update({"User-Agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/139 Safari/537.36"})
    return s


class QureoSolver:
    COURSE_IDS = {"javascript": "javascript_ar", "python": "python_short_ar"}
    START_IDS = {"javascript": 90001, "python": 511001}
    TOTALS = {"javascript": 54, "python": 25}

    def __init__(self, username: str, password: str, banks: QuestionBanks):
        self.username, self.password, self.banks = username, password, banks
        self.s = _session()
        self.token: str | None = None

    def login(self) -> bool:
        response = self.s.post(
            f"{Settings.qureo_portal}/oauth2/password-login",
            json={"student_id": self.username, "password": self.password},
            timeout=Settings.request_timeout,
        )
        self.token = self.s.cookies.get("egy_student_access_token")
        if not self.token:
            log.warning("Qureo login failed: status=%s", response.status_code)
            return False
        self.s.headers["authorization"] = f"Bearer {self.token}"
        return True

    @staticmethod
    def _indent_js(code: str) -> str:
        lines = []
        for line in (code or "").splitlines():
            stripped = line.strip()
            if stripped and not line.startswith("  "):
                lines.append("  " + stripped)
            else:
                lines.append(line)
        return "\n".join(lines)

    def solve_course(self, course: str, progress: Progress, limit: int | None = None) -> tuple[int, int]:
        course_id = self.COURSE_IDS[course]
        self.s.cookies.set("student_selected_content_id", course_id, domain="me-tp.qureo.education")
        solved = failed = 0
        start = self.START_IDS[course]
        total = limit or self.TOTALS[course]
        for offset in range(total):
            chapter_id = start + offset
            progress(f"{course.title()}: chapter {offset + 1}/{total}")
            try:
                ok, count, total = self._solve_chapter(course, chapter_id)
                solved += count
                failed += 0 if ok else 1
            except requests.RequestException as exc:
                log.exception("Qureo chapter request failed")
                failed += 1
                progress(f"Connection error in chapter {chapter_id}: {html.escape(str(exc)[:100])}")
            time.sleep(0.05)
        return solved, failed

    def course_status(self, course: str, limit: int | None = None) -> dict[str, Any]:
        total = limit or self.TOTALS[course]
        start = self.START_IDS[course]
        completed: list[int] = []
        pending: list[int] = []
        for offset in range(total):
            chapter_id = start + offset
            response = self.s.get(
                f"{Settings.qureo_base}/api/study/students/chapters/{chapter_id}",
                timeout=Settings.request_timeout,
            )
            data = response.json() if response.status_code == 200 else {}
            if data.get("completed_at") is not None and int(data.get("best_correct_count", 0)) > 0:
                completed.append(offset + 1)
            else:
                pending.append(offset + 1)
        return {"total": total, "completed": completed, "pending": pending}

    def _solve_chapter(self, course: str, chapter_id: int) -> tuple[bool, int, int]:
        base = Settings.qureo_base
        current = self.s.get(f"{base}/api/study/students/chapters/{chapter_id}", timeout=Settings.request_timeout)
        current_data = current.json() if current.status_code == 200 else {}
        if current_data.get("completed_at") is not None and int(current_data.get("best_correct_count", 0)) > 0:
            best = int(current_data.get("best_correct_count", 0))
            return True, best, best
        response = self.s.get(f"{base}/api/study/chapters/{chapter_id}/test", timeout=Settings.request_timeout)
        if response.status_code != 200:
            return False, 0, 0
        questions = response.json()
        self.s.put(f"{base}/api/study/students/chapters/{chapter_id}/test", json={}, timeout=Settings.request_timeout)
        answers = 0
        for item in questions:
            q = item.get("question", {})
            qid = str(q.get("id", ""))
            answer = self.banks.qureo_answer(course, qid)
            if answer is None:
                choices = item.get("choices", [])
                answer = choices[0].get("id") if choices else None
            if answer is None:
                continue
            if q.get("type") == "description":
                endpoint = f"{base}/api/study/students/test-questions/{qid}/answer/description"
                payload = {"answer_code": self._indent_js(str(answer)) if course == "javascript" else str(answer)}
            else:
                endpoint = f"{base}/api/study/students/test-questions/{qid}/answer/choice"
                payload = {"choice_id": int(answer)}
            result = self.s.put(endpoint, json=payload, timeout=Settings.request_timeout)
            if result.status_code not in (200, 400) and q.get("type") == "choice":
                for choice in item.get("choices", []):
                    result = self.s.put(endpoint, json={"choice_id": int(choice["id"])}, timeout=Settings.request_timeout)
                    if result.status_code == 200:
                        break
            if result.status_code in (200, 400):
                answers += 1
        status = self.s.get(f"{base}/api/study/students/chapters/{chapter_id}", timeout=Settings.request_timeout)
        data = status.json() if status.status_code == 200 else {}
        best = int(data.get("best_correct_count", 0))
        completed = data.get("completed_at") is not None
        return completed and best >= len(questions), answers, len(questions)


class FinancialSolver:
    def __init__(self, username: str, password: str, banks: QuestionBanks):
        self.username, self.password, self.banks = username, password, banks
        self.s = _session()
        self.token: str | None = None
        self.subject = Settings.spx_subject

    def login(self) -> bool:
        response = self.s.post(
            f"{Settings.spx_base}/api/v1/auth/login",
            json={"login_id": self.username, "password": self.password},
            timeout=Settings.request_timeout,
        )
        if response.status_code != 200:
            return False
        body = response.json()
        self.token = body.get("token") or (body.get("data") or {}).get("token")
        if not self.token:
            self.token = self.s.cookies.get("learning_token")
        if not self.token:
            return False
        self.s.headers["authorization"] = f"Bearer {self.token}"
        return True

    def _get(self, path: str) -> dict[str, Any] | None:
        r = self.s.get(f"{Settings.spx_base}{path}", timeout=Settings.request_timeout)
        return r.json() if r.status_code == 200 else None

    def _post(self, path: str, payload: dict[str, Any] | None = None) -> requests.Response:
        return self.s.post(f"{Settings.spx_base}{path}", json=payload or {}, timeout=Settings.request_timeout)

    def solve_all(self, progress: Progress) -> tuple[int, int]:
        curriculum = self._get(f"/api/v1/subjects/{self.subject}/curriculum") or {}
        solved = failed = 0
        for unit in curriculum.get("data", []):
            for item in unit.get("items", []):
                if item.get("is_completed"):
                    continue
                title = item.get("title", "financial item")
                progress(f"Financial culture: {title[:45]}")
                kind, item_id = item.get("item_type"), item.get("id")
                try:
                    if kind == "chapter":
                        result = self.solve_chapter(item_id)
                    elif kind == "review":
                        result = self._post(f"/api/v1/reviews/{item_id}/complete").status_code == 200
                    elif kind == "test":
                        result = self.solve_test(item_id)
                    else:
                        continue
                    solved += 1 if result else 0
                    failed += 0 if result else 1
                except requests.RequestException:
                    failed += 1
        return solved, failed

    def solve_chapter(self, chapter_id: int) -> bool:
        payload = self._get(f"/api/v1/chapters/{chapter_id}/blocks") or {}
        data = payload.get("data", {})
        cleared = set(data.get("chapter", {}).get("cleared_block_ids", []))
        questions = [b for b in data.get("blocks", []) if b.get("type") == "question"]
        good = 0
        for q in questions:
            if q.get("id") in cleared:
                good += 1
                continue
            for option in q.get("options", []):
                r = self._post(f"/api/v1/chapters/{chapter_id}/answer", {"block_id": q["id"], "selected_option_id": option["id"], "hint_used": 0})
                if r.status_code == 200 and (r.json().get("data", {}).get("is_correct") or r.json().get("data", {}).get("correct_option_id")):
                    good += 1
                    break
        self._post(f"/api/v1/chapters/{chapter_id}/complete")
        return good == len(questions)

    def solve_test(self, test_id: int) -> bool:
        started = self._post(f"/api/v1/tests/{test_id}/start")
        if started.status_code != 200:
            return False
        data = started.json().get("data", {})
        questions = data.get("questions", {})
        options = data.get("options", {})
        pairs = []
        for test_question in data.get("test_questions", []):
            qid = str(test_question.get("question_id"))
            text = questions.get(qid, {}).get("question_text", "")
            opts = options.get(qid, [])
            answer = self.banks.financial_answer(text)
            selected = next((o["id"] for o in opts if " ".join(str(o.get("text", "")).split()) == " ".join(str(answer or "").split())), None)
            selected = selected or (opts[0]["id"] if opts else None)
            if selected:
                pairs.append((test_question["id"], selected))
        for tqid, selected in pairs:
            self.s.put(f"{Settings.spx_base}/api/v1/tests/{test_id}/questions/{tqid}/answer", json={"selected_option_id": selected}, timeout=Settings.request_timeout)
        self._post(f"/api/v1/tests/{test_id}/submit")
        history = self._get(f"/api/v1/tests/{test_id}/history") or {}
        return any(e.get("status") == "completed" and e.get("passed") for e in history.get("data", []))
