from __future__ import annotations

import asyncio
import logging
import os
from dataclasses import dataclass
from pathlib import Path

from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

try:
    from .config import Settings, DATA_DIR
    from .data_store import QuestionBanks
    from .platforms import FinancialSolver, QureoSolver
    from .storage import Storage
except ImportError:
    from config import Settings, DATA_DIR
    from data_store import QuestionBanks
    from platforms import FinancialSolver, QureoSolver
    from storage import Storage

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)
router = Router()
storage = Storage(DATA_DIR / "bot.sqlite3")
banks = QuestionBanks()
OWNER_ID = int(os.getenv("OWNER_ID", "0"))


class Flow(StatesGroup):
    grade = State()
    subjects = State()
    username = State()
    password = State()
    redeem = State()
    admin_code = State()
    admin_toggle = State()


@dataclass
class Session:
    grade: str | None = None
    subjects: list[str] | None = None
    username: str | None = None
    password: str | None = None
    running: bool = False


sessions: dict[int, Session] = {}


def sess(uid: int) -> Session:
    return sessions.setdefault(uid, Session())


def kb(rows: list[list[tuple[str, str]]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t, callback_data=d) for t, d in row] for row in rows])


def grade_kb():
    return kb([[('🔵 أولى ثانوي — JavaScript (42 فصل)', 'grade:1')], [('🟢 ثانية ثانوي', 'grade:2')]])


def subject_kb():
    return kb([
        [('🔵 JavaScript + 🟢 Python', 'subjects:code')],
        [('🟠 الثقافة المالية', 'subjects:finance')],
        [('🟣 الكل — JavaScript + Python + ثقافة', 'subjects:all')],
        [('🔙 تغيير الصف', 'start:grades')],
    ])


def after_login_kb(uid: int):
    s = sess(uid)
    buttons = []
    if s.grade == '1': buttons.append([('⚡ حل JavaScript — 42 فصل', 'solve:js1')])
    elif s.subjects:
        labels = {'javascript': 'JavaScript — 54 فصل', 'python': 'Python — 25 فصل', 'financial': 'الثقافة المالية'}
        for sub in s.subjects:
            buttons.append([(f'🚀 حل {labels[sub]}', f'solve:{sub}')])
    buttons += [[('📊 عرض الفصول المكتملة والمتبقية', 'status')], [('🔄 اختيار الصف/المواد', 'start:grades')], [('🔑 تجديد الاشتراك', 'redeem')]]
    return kb(buttons)


def is_owner(uid: int) -> bool:
    return uid == OWNER_ID and OWNER_ID != 0


def allowed(uid: int) -> bool:
    return is_owner(uid) or storage.active(uid)


def welcome() -> str:
    return ('👋 أهلاً بك في بوت الحل السريع\n\n'
            'اختر الصف الدراسي أولاً، وبعدها ستختار المواد المتاحة للصف الثاني.')


@router.message(CommandStart())
async def start(message: Message, state: FSMContext):
    uid = message.from_user.id
    storage.register(uid, message.from_user.username or '')
    sessions[uid] = Session()
    await state.clear(); await state.set_state(Flow.grade)
    await message.answer(welcome(), reply_markup=grade_kb())


@router.callback_query(F.data == 'start:grades')
async def choose_grades(call: CallbackQuery, state: FSMContext):
    sessions[call.from_user.id] = Session(); await state.clear(); await state.set_state(Flow.grade)
    await call.message.edit_text(welcome(), reply_markup=grade_kb()); await call.answer()


@router.callback_query(F.data.startswith('grade:'))
async def choose_grade(call: CallbackQuery, state: FSMContext):
    uid = call.from_user.id; grade = call.data.split(':')[1]; s = sess(uid); s.grade = grade
    if grade == '1':
        s.subjects = ['javascript']
        await state.set_state(Flow.username)
        await call.message.edit_text('✅ اخترت أولى ثانوي — JavaScript.\n\nأرسل كود الطالب:', reply_markup=kb([[('❌ إلغاء', 'cancel')]]))
    else:
        await state.set_state(Flow.subjects)
        await call.message.edit_text('✅ اخترت ثانية ثانوي.\n\nاختر ما تريد حله:', reply_markup=subject_kb())
    await call.answer()


@router.callback_query(F.data.startswith('subjects:'))
async def choose_subjects(call: CallbackQuery, state: FSMContext):
    value = call.data.split(':')[1]
    s = sess(call.from_user.id)
    s.subjects = {'code': ['javascript', 'python'], 'finance': ['financial'], 'all': ['javascript', 'python', 'financial']}[value]
    await state.set_state(Flow.username)
    await call.message.edit_text('✅ تم اختيار المواد.\n\nأرسل كود الطالب في المنصة:', reply_markup=kb([[('❌ إلغاء', 'cancel')]])); await call.answer()


@router.message(Flow.username)
async def receive_username(message: Message, state: FSMContext):
    sess(message.from_user.id).username = (message.text or '').strip()
    await state.set_state(Flow.password)
    await message.answer('🔐 أرسل كلمة المرور. سيتم حذف رسالتك فوراً لحماية بياناتك.')


@router.message(Flow.password)
async def receive_password(message: Message, state: FSMContext):
    uid = message.from_user.id; s = sess(uid); s.password = (message.text or '').strip()
    try: await message.delete()
    except Exception: pass
    if not allowed(uid):
        await state.clear(); await message.answer('🔒 يلزم تفعيل اشتراك أولاً. استخدم /redeem ثم أرسل كود الاشتراك.')
        return
    status = await message.answer('🔄 جارٍ التحقق من الحساب وتجهيز الحل...')
    solver = QureoSolver(s.username, s.password, banks)
    # Financial uses a separate backend; verify Qureo only when a programming track is selected.
    needs_qureo = any(x in ('javascript', 'python') for x in (s.subjects or []))
    if needs_qureo and not await asyncio.to_thread(solver.login):
        await status.edit_text('❌ فشل تسجيل الدخول إلى Qureo. راجع الكود وكلمة المرور ثم أعد المحاولة بـ /start.')
        await state.clear(); return
    await state.clear()
    await status.edit_text('✅ تم التحقق من البيانات. اختر عملية الحل:', reply_markup=after_login_kb(uid))


@router.callback_query(F.data == 'redeem')
async def redeem_button(call: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.redeem); await call.message.answer('🎟 أرسل كود الاشتراك:'); await call.answer()


@router.message(Command('status'))
async def status_command(message: Message):
    await send_status(message, message.from_user.id)


async def send_status(message: Message, uid: int):
    if not allowed(uid):
        return await message.answer('🔒 فعّل اشتراكك أولاً باستخدام /redeem.')
    s = sess(uid)
    if not s.username or not s.password:
        return await message.answer('ابدأ من /start وسجّل حسابك أولاً.')
    q = QureoSolver(s.username, s.password, banks)
    if not any(x in ('javascript', 'python') for x in (s.subjects or [])):
        return await message.answer('📊 الثقافة المالية تُفحص مباشرة أثناء بدء حلها؛ استخدم زر البدء لقراءة حالتها من المنصة.')
    if not await asyncio.to_thread(q.login):
        return await message.answer('❌ تعذر تسجيل الدخول لقراءة حالة الفصول.')
    reports = []
    for course in s.subjects or []:
        if course not in ('javascript', 'python'):
            continue
        limit = 42 if s.grade == '1' and course == 'javascript' else None
        report = await asyncio.to_thread(q.course_status, course, limit)
        pending = report['pending']
        reports.append(f"{course.title()}: مكتمل {len(report['completed'])}/{report['total']} — أول فصل متبقٍ: {pending[0] if pending else 'لا يوجد'}")
    await message.answer('📊 حالة حسابك:\n' + '\n'.join(reports))


@router.callback_query(F.data == 'status')
async def status_button(call: CallbackQuery):
    await call.answer()
    await send_status(call.message, call.from_user.id)


@router.message(Command('redeem'))
async def redeem_command(message: Message, state: FSMContext):
    await state.set_state(Flow.redeem); await message.answer('🎟 أرسل كود الاشتراك:')


@router.message(Flow.redeem)
async def redeem_code(message: Message, state: FSMContext):
    ok, text = storage.redeem(message.from_user.id, message.text or '')
    await state.clear(); await message.answer(('✅ تم تفعيل الاشتراك حتى ' + text) if ok else ('❌ ' + text))


@router.callback_query(F.data.startswith('solve:'))
async def solve(call: CallbackQuery):
    uid = call.from_user.id
    if not allowed(uid): await call.answer('🔒 فعّل اشتراكك أولاً بـ /redeem', show_alert=True); return
    s = sess(uid)
    if s.running: await call.answer('⏳ توجد عملية حل جارية بالفعل.', show_alert=True); return
    subject = call.data.split(':', 1)[1]
    if subject == 'js1': subjects, grade = ['javascript'], '1'
    else: subjects, grade = [subject], s.grade or '2'
    s.running = True; await call.answer('🚀 بدأ الحل السريع')
    msg = await call.message.answer('⏳ جاري بدء العملية...')
    try:
        if 'javascript' in subjects or 'python' in subjects:
            q = QureoSolver(s.username or '', s.password or '', banks)
            if not await asyncio.to_thread(q.login): raise RuntimeError('فشل تسجيل الدخول إلى Qureo')
            for sub in subjects:
                if sub == 'javascript':
                    # Grade 1 has 42 chapters; grade 2 uses the complete 54 chapter bank.
                    limit = 42 if grade == '1' else None
                else:
                    limit = None
                solved, failed = await asyncio.to_thread(q.solve_course, sub, lambda t: log.info('uid=%s %s', uid, t), limit)
                await msg.edit_text(f'✅ انتهى {sub.title()}\nإجابات مرسلة: {solved}\nفصول تحتاج مراجعة: {failed}')
        if 'financial' in subjects:
            f = FinancialSolver(s.username or '', s.password or '', banks)
            if not await asyncio.to_thread(f.login): raise RuntimeError('فشل تسجيل الدخول إلى منصة الثقافة المالية')
            solved, failed = await asyncio.to_thread(f.solve_all, lambda t: log.info('uid=%s %s', uid, t))
            await msg.edit_text(f'✅ انتهت الثقافة المالية\nعناصر منجزة: {solved}\nعناصر تحتاج مراجعة: {failed}')
        await msg.answer('🎉 انتهت العملية. يمكنك إعادة الحل أو اختيار مادة أخرى.', reply_markup=after_login_kb(uid))
    except Exception as exc:
        log.exception('solve failed')
        await msg.edit_text(f'⚠️ توقفت العملية بسبب اتصال/بيانات غير متاحة: {str(exc)[:180]}')
    finally:
        s.running = False


@router.message(Command('admin'))
async def admin(message: Message):
    if not is_owner(message.from_user.id): return await message.answer('⛔ هذا الأمر للمالك فقط.')
    await message.answer('👑 لوحة المالك\nاختر الإجراء:', reply_markup=kb([[('➕ إنشاء كود', 'admin:create')], [('📋 عرض الأكواد', 'admin:list')]]))


@router.callback_query(F.data == 'admin:create')
async def admin_create(call: CallbackQuery, state: FSMContext):
    if not is_owner(call.from_user.id): return
    await state.set_state(Flow.admin_code); await call.message.answer('أرسل المدة وعدد الاستخدامات بهذا الشكل: `30 1`', parse_mode='Markdown'); await call.answer()


@router.message(Flow.admin_code)
async def admin_create_code(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id): return
    try: days, uses = map(int, (message.text or '').split())
    except ValueError: return await message.answer('الصيغة: `30 1`', parse_mode='Markdown')
    if days <= 0 or uses <= 0: return await message.answer('يجب أن تكون القيم أكبر من صفر.')
    code = storage.create_code(days, uses); await state.clear(); await message.answer(f'✅ تم إنشاء الكود:\n`{code}`\nالمدة: {days} يوم\nالاستخدامات: {uses}', parse_mode='Markdown')


@router.callback_query(F.data == 'admin:list')
async def admin_list(call: CallbackQuery):
    if not is_owner(call.from_user.id): return
    rows = []
    for r in storage.codes():
        label = ('🔴' if not r['active'] else '🟢') + f" {r['code']} ({r['uses']}/{r['max_uses']})"
        rows.append([(label, f"admin:toggle:{r['code']}")])
    await call.message.edit_text('📋 الأكواد — اضغط على أي كود لتعطيله/تفعيله:', reply_markup=kb(rows or [[('لا توجد أكواد', 'noop')]])); await call.answer()


@router.callback_query(F.data.startswith('admin:toggle:'))
async def admin_toggle(call: CallbackQuery):
    if not is_owner(call.from_user.id): return
    code = call.data.rsplit(':', 1)[1]; storage.toggle_code(code); await call.answer('✅ تم تغيير حالة الكود'); await admin_list(call)


@router.callback_query(F.data == 'cancel')
async def cancel(call: CallbackQuery, state: FSMContext):
    await state.clear(); await call.message.answer('تم الإلغاء. استخدم /start للبدء من جديد.'); await call.answer()


async def main():
    if not Settings.bot_token: raise RuntimeError('BOT_TOKEN غير موجود في .env')
    bot = Bot(Settings.bot_token)
    dp = Dispatcher(); dp.include_router(router)
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == '__main__':
    asyncio.run(main())
