from __future__ import annotations

import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path


class Storage:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS users (telegram_id INTEGER PRIMARY KEY, username TEXT, created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS codes (code TEXT PRIMARY KEY, days INTEGER NOT NULL, max_uses INTEGER NOT NULL, uses INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS redemptions (code TEXT NOT NULL, telegram_id INTEGER NOT NULL, redeemed_at TEXT NOT NULL, PRIMARY KEY(code, telegram_id));
            CREATE TABLE IF NOT EXISTS subscriptions (telegram_id INTEGER PRIMARY KEY, expires_at TEXT NOT NULL);
            ''')

    def connect(self):
        db = sqlite3.connect(self.path)
        db.row_factory = sqlite3.Row
        return db

    def register(self, telegram_id: int, username: str = '') -> None:
        with self.connect() as db:
            db.execute('INSERT OR IGNORE INTO users VALUES (?, ?, ?)', (telegram_id, username, self.now()))
            db.execute('UPDATE users SET username=? WHERE telegram_id=?', (username, telegram_id))

    @staticmethod
    def now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def create_code(self, days: int, max_uses: int) -> str:
        code = secrets.token_urlsafe(7).upper().replace('-', '').replace('_', '')
        with self.connect() as db:
            db.execute('INSERT INTO codes VALUES (?, ?, ?, 0, 1, ?)', (code, days, max_uses, self.now()))
        return code

    def redeem(self, telegram_id: int, code: str) -> tuple[bool, str]:
        code = code.strip().upper()
        with self.connect() as db:
            row = db.execute('SELECT * FROM codes WHERE code=?', (code,)).fetchone()
            if not row or not row['active']:
                return False, 'الكود غير موجود أو تم تعطيله.'
            if row['uses'] >= row['max_uses']:
                return False, 'الكود استنفد عدد مرات الاستخدام.'
            if db.execute('SELECT 1 FROM redemptions WHERE code=? AND telegram_id=?', (code, telegram_id)).fetchone():
                return False, 'لقد استخدمت هذا الكود من قبل.'
            current = db.execute('SELECT expires_at FROM subscriptions WHERE telegram_id=?', (telegram_id,)).fetchone()
            start = datetime.fromisoformat(current['expires_at']) if current else datetime.now(timezone.utc)
            if start < datetime.now(timezone.utc):
                start = datetime.now(timezone.utc)
            expiry = start + timedelta(days=row['days'])
            db.execute('UPDATE codes SET uses=uses+1 WHERE code=?', (code,))
            db.execute('INSERT OR REPLACE INTO redemptions VALUES (?, ?, ?)', (code, telegram_id, self.now()))
            db.execute('INSERT OR REPLACE INTO subscriptions VALUES (?, ?)', (telegram_id, expiry.isoformat()))
            return True, expiry.strftime('%Y-%m-%d')

    def active(self, telegram_id: int) -> bool:
        with self.connect() as db:
            row = db.execute('SELECT expires_at FROM subscriptions WHERE telegram_id=?', (telegram_id,)).fetchone()
        return bool(row and datetime.fromisoformat(row['expires_at']) > datetime.now(timezone.utc))

    def codes(self):
        with self.connect() as db:
            return db.execute('SELECT * FROM codes ORDER BY created_at DESC').fetchall()

    def toggle_code(self, code: str) -> bool:
        with self.connect() as db:
            row = db.execute('SELECT active FROM codes WHERE code=?', (code,)).fetchone()
            if not row:
                return False
            db.execute('UPDATE codes SET active=? WHERE code=?', (0 if row['active'] else 1, code))
            return True
