"""Clean unified Qureo/SPX Telegram solver bot."""
