import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from subscriptions import SubscriptionStore


class SubscriptionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = SubscriptionStore(Path(self.temp.name) / "test.sqlite3")

    def tearDown(self):
        self.temp.cleanup()

    def test_code_is_one_use_and_subscription_can_be_revoked(self):
        created = self.store.create_codes(created_by=9, duration_days=30, count=1)[0]
        code = created["code"]
        self.assertFalse(self.store.status(123)["active"])
        self.assertTrue(self.store.redeem(123, code)["ok"])
        self.assertTrue(self.store.status(123)["active"])
        self.assertEqual(self.store.redeem(456, code)["reason"], "used")
        self.assertTrue(self.store.revoke_code(created["id"])["ok"])
        self.assertFalse(self.store.status(123)["active"])

    def test_stacked_code_keeps_access_when_first_code_is_revoked(self):
        first, second = self.store.create_codes(9, 7, 2)
        self.assertTrue(self.store.redeem(123, first["code"])["ok"])
        self.assertTrue(self.store.redeem(123, second["code"])["ok"])
        self.assertTrue(self.store.revoke_code(first["id"])["ok"])
        self.assertTrue(self.store.status(123)["active"])
        self.assertEqual(self.store.revoke_user(123), 1)
        self.assertFalse(self.store.status(123)["active"])

    def test_invalid_code_and_creation_bounds(self):
        self.assertEqual(self.store.redeem(1, "no-such-code")["reason"], "invalid")
        with self.assertRaises(ValueError):
            self.store.create_codes(9, 0, 1)
        with self.assertRaises(ValueError):
            self.store.create_codes(9, 30, 31)

    def test_only_one_concurrent_redemption_succeeds(self):
        code = self.store.create_codes(9, 30, 1)[0]["code"]
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(
                pool.map(lambda uid: self.store.redeem(uid, code), range(100, 108))
            )
        self.assertEqual(sum(1 for result in results if result["ok"]), 1)


if __name__ == "__main__":
    unittest.main()
