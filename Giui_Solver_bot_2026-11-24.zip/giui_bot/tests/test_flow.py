import unittest

from solver.flow import courses_for_selection, platforms_for_courses


class FlowTests(unittest.TestCase):
    def test_grade_one_is_javascript_only(self):
        self.assertEqual(courses_for_selection(1, "programming"), ["javascript_g1"])
        self.assertEqual(
            platforms_for_courses(courses_for_selection(1, "programming")), ["qureo"]
        )

    def test_grade_two_programming(self):
        courses = courses_for_selection(2, "programming")
        self.assertEqual(courses, ["javascript", "python"])
        self.assertEqual(platforms_for_courses(courses), ["qureo"])

    def test_grade_two_finance_and_all(self):
        finance = courses_for_selection(2, "finance")
        all_courses = courses_for_selection(2, "all")
        self.assertEqual(finance, ["finance"])
        self.assertEqual(platforms_for_courses(finance), ["spx"])
        self.assertEqual(all_courses, ["javascript", "python", "finance"])
        self.assertEqual(platforms_for_courses(all_courses), ["qureo", "spx"])

    def test_rejects_impossible_track(self):
        with self.assertRaises(ValueError):
            courses_for_selection(1, "finance")


if __name__ == "__main__":
    unittest.main()
