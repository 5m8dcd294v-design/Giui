import unittest

from solver.data import AnswerBank, match_option, normalize_text


class AnswerBankTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bank = AnswerBank()

    def test_answer_bank_counts_and_course_ids(self):
        self.assertEqual(len(self.bank.javascript), 54)
        self.assertEqual(len(self.bank.javascript_first_grade), 42)
        self.assertEqual(len(self.bank.python), 25)
        self.assertEqual(
            sum(len(ch.get("answers", {})) for ch in self.bank.javascript.values()), 345
        )
        self.assertEqual(
            sum(
                len(ch.get("answers", {}))
                for ch in self.bank.javascript_first_grade.values()
            ),
            276,
        )
        self.assertEqual(
            sum(len(ch.get("questions", {})) for ch in self.bank.python.values()), 153
        )
        self.assertGreater(len(self.bank.finance_pairs), 500)

    def test_qureo_answer_lookups(self):
        self.assertTrue(self.bank.qureo_answers("javascript", "90001"))
        self.assertTrue(self.bank.qureo_answers("javascript_g1", "90042"))
        self.assertFalse(self.bank.qureo_answers("javascript_g1", "90043"))
        self.assertTrue(self.bank.qureo_answers("python", "511001"))

    def test_arabic_normalization_ignores_diacritics_and_punctuation(self):
        self.assertEqual(normalize_text("إدارةُ المالِ!"), normalize_text("ادارة المال"))

    def test_finance_answer_exact_match_and_common_spacing(self):
        question, expected = self.bank.finance_pairs[0]
        self.assertEqual(self.bank.finance_answer(question), expected)
        self.assertEqual(self.bank.finance_answer(question + "؟"), expected)

    def test_option_match_is_conservative(self):
        options = [
            {"id": 11, "text": "الإجابة الصحيحة"},
            {"id": 12, "text": "إجابة مختلفة"},
        ]
        self.assertEqual(match_option(options, "الإجابة الصحيحة"), 11)
        self.assertEqual(match_option(options, 12), 12)
        self.assertIsNone(match_option(options, "اختيار غير موجود إطلاقًا"))


if __name__ == "__main__":
    unittest.main()
