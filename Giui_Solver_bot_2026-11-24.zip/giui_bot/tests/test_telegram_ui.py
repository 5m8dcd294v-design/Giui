import os
import tempfile
import unittest

os.environ["BOT_TOKEN"] = "123456:offline-test-token"
os.environ["OWNER_ID"] = "123456789"
os.environ["DATABASE_PATH"] = str(
    tempfile.gettempdir() + f"/giui-test-ui-{os.getpid()}.sqlite3"
)

from bot import grade2_keyboard, grade_keyboard


class TelegramUITests(unittest.TestCase):
    def test_colored_grade_buttons_serialize_with_emoji_fallbacks(self):
        markup = grade_keyboard().to_dict()
        buttons = [button for row in markup["inline_keyboard"] for button in row]
        self.assertEqual(buttons[0]["callback_data"], "grade_1")
        self.assertEqual(buttons[0]["style"], "primary")
        self.assertIn("🟦", buttons[0]["text"])

    def test_grade_two_has_all_three_tracks(self):
        markup = grade2_keyboard().to_dict()
        data = {
            button["callback_data"]
            for row in markup["inline_keyboard"]
            for button in row
        }
        self.assertTrue(
            {"track_programming", "track_finance", "track_all"}.issubset(data)
        )


if __name__ == "__main__":
    unittest.main()
