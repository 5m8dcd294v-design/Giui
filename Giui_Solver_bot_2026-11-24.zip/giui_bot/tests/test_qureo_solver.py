import threading
import unittest
from unittest.mock import patch

from solver.qureo_api import QureoAPI


class Response:
    def __init__(self, status=200, body=None):
        self.status_code = status
        self._body = body or {}

    def json(self):
        return self._body


class FakeBank:
    javascript = {
        "90001": {
            "answers": {"101": {"answer": "console.log('ok')"}, "102": {"answer": 77}}
        }
    }
    python = {}

    def qureo_answers(self, course, chapter_id):
        return self.javascript.get(str(chapter_id), {}).get("answers", {})


class QureoSolverTests(unittest.TestCase):
    def setUp(self):
        self.client = QureoAPI("student", "secret")
        self.client._complete_lectures = lambda chapter_id, content_id: True

    def test_known_answers_are_submitted_and_platform_completion_is_checked(self):
        questions = [
            {"question": {"id": 101, "type": "description"}},
            {"question": {"id": 102, "type": "choice"}},
        ]

        def request(method, path, **kwargs):
            if path.endswith("/test") and method == "GET":
                return Response(200, questions)
            return Response(200, {})

        self.client._request = request
        with patch.object(self.client, "_status", side_effect=[(0, False), (2, True)]):
            result = self.client._solve_chapter(
                "90001", "javascript_ar", "javascript", FakeBank(), threading.Event()
            )
        self.assertEqual(result["state"], "completed")
        self.assertEqual(result["solved"], 2)
        self.assertEqual(result["total"], 2)

    def test_missing_answer_is_not_guessed_or_marked_complete(self):
        questions = [
            {
                "question": {"id": 999, "type": "choice"},
                "choices": [{"id": 1}, {"id": 2}],
            }
        ]
        calls = []

        def request(method, path, **kwargs):
            calls.append((method, path))
            if path.endswith("/test") and method == "GET":
                return Response(200, questions)
            return Response(200, {})

        self.client._request = request
        with patch.object(self.client, "_status", side_effect=[(0, False), (0, False)]):
            result = self.client._solve_chapter(
                "90001", "javascript_ar", "javascript", FakeBank(), threading.Event()
            )
        self.assertEqual(result["state"], "partial")
        self.assertFalse(any("/answer/choice" in path for _, path in calls))
        self.assertTrue(
            any(path.endswith("/test") and method == "PUT" for method, path in calls)
        )


if __name__ == "__main__":
    unittest.main()
