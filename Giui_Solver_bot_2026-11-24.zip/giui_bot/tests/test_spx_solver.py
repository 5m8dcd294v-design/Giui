import threading
import unittest

from solver.spx_api import SPXAPI


class Response:
    def __init__(self, status=200, body=None):
        self.status_code = status
        self._body = body or {}

    def json(self):
        return self._body


class FakeBank:
    def __init__(self, answer):
        self.answer = answer

    def finance_answer(self, question):
        return self.answer


class SPXSolverTests(unittest.TestCase):
    def setUp(self):
        self.client = SPXAPI("student", "secret")
        self.blocks = {
            "data": {
                "blocks": [
                    {
                        "id": 7,
                        "type": "question",
                        "question_text": "سؤال تجريبي؟",
                        "options": [
                            {"id": 11, "text": "الإجابة"},
                            {"id": 12, "text": "غيرها"},
                        ],
                    }
                ],
                "chapter": {"cleared_block_ids": []},
            }
        }

    def test_known_finance_answer_selects_matching_option_and_completes(self):
        calls = []

        def request(method, path, **kwargs):
            calls.append((method, path, kwargs.get("json")))
            if path.endswith("/blocks"):
                return Response(200, self.blocks)
            if path.endswith("/answer"):
                return Response(200, {"data": {"is_correct": True}})
            if path.endswith("/complete"):
                return Response(200, {"data": {}})
            return Response(404)

        self.client._request = request
        result = self.client.solve_chapter(1, FakeBank("الإجابة"), threading.Event())
        submitted = [entry for entry in calls if entry[1].endswith("/answer")]
        self.assertEqual(submitted[0][2]["selected_option_id"], 11)
        self.assertTrue(result["ok"])

    def test_no_bank_match_does_not_guess_or_complete(self):
        calls = []

        def request(method, path, **kwargs):
            calls.append((method, path))
            if path.endswith("/blocks"):
                return Response(200, self.blocks)
            return Response(200, {"data": {}})

        self.client._request = request
        result = self.client.solve_chapter(1, FakeBank(None), threading.Event())
        self.assertFalse(result["ok"])
        self.assertEqual(result["state"], "partial")
        self.assertFalse(
            any(
                path.endswith("/answer") or path.endswith("/complete")
                for _, path in calls
            )
        )

    def test_spx_test_is_not_submitted_with_an_unmatched_question(self):
        calls = []

        def request(method, path, **kwargs):
            calls.append((method, path))
            return Response(
                200,
                {
                    "data": {
                        "questions": {
                            "1": {"question_text": "سؤال معروف"},
                            "2": {"question_text": "سؤال بلا إجابة"},
                        },
                        "options": {
                            "1": [{"id": 11, "text": "معلوم"}],
                            "2": [{"id": 22, "text": "خيار"}],
                        },
                        "test_questions": [
                            {"id": 101, "question_id": 1},
                            {"id": 102, "question_id": 2},
                        ],
                    }
                },
            )

        self.client._request = request
        result = self.client.solve_test(5, FakeBank("معلوم"), threading.Event())
        self.assertEqual(result["state"], "partial")
        self.assertEqual(result["unmatched"], 1)
        self.assertFalse(any(path.endswith("/submit") for _, path in calls))


if __name__ == "__main__":
    unittest.main()
