"""SPX financial-culture API client with conservative answer matching."""

from __future__ import annotations

import threading
from typing import Any, Callable

import requests

from .data import AnswerBank, match_option

BASE = "https://egy.app.spx-learning-square.com"
SUBJECT_ID = 7


class SPXAPI:
    def __init__(self, login_id: str, password: str, timeout: int = 25):
        self.login_id = login_id
        self.password = password
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update(
            {
                "accept": "application/json, text/plain, */*",
                "content-type": "application/json",
                "origin": BASE,
                "referer": f"{BASE}/subjects/{SUBJECT_ID}/curriculum",
                "user-agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36",
            }
        )

    def _request(self, method: str, path: str, **kwargs: Any) -> requests.Response:
        return self.session.request(
            method, f"{BASE}{path}", timeout=self.timeout, **kwargs
        )

    def login(self) -> tuple[bool, str]:
        try:
            response = self._request(
                "POST",
                "/api/v1/auth/login",
                json={"login_id": self.login_id, "password": self.password},
            )
        except requests.RequestException as exc:
            return False, f"تعذر الاتصال بمنصة الثقافة المالية ({type(exc).__name__})."
        if response.status_code != 200:
            if response.status_code in (401, 403):
                return (
                    False,
                    "بيانات الدخول إلى منصة الثقافة المالية غير صحيحة أو الحساب غير مخوّل.",
                )
            return (
                False,
                f"تعذر تسجيل الدخول إلى منصة الثقافة المالية (HTTP {response.status_code}).",
            )
        try:
            body = response.json()
        except ValueError:
            return False, "المنصة أرجعت ردًا غير مفهوم أثناء تسجيل الدخول."
        token = body.get("token") or (body.get("data") or {}).get("token")
        if not token:
            token = self.session.cookies.get("learning_token")
        if not token:
            return False, "تم الاتصال، لكن المنصة لم تُرجع رمز جلسة صالحًا."
        self.session.headers["authorization"] = f"Bearer {token}"
        return True, ""

    @staticmethod
    def _data(response: requests.Response) -> Any:
        try:
            body = response.json()
            return body.get("data") if isinstance(body, dict) else None
        except ValueError:
            return None

    def _curriculum(self) -> list[dict[str, Any]]:
        response = self._request("GET", f"/api/v1/subjects/{SUBJECT_ID}/curriculum")
        if response.status_code != 200:
            raise RuntimeError(f"curriculum_http_{response.status_code}")
        data = self._data(response)
        if not isinstance(data, list):
            raise RuntimeError("curriculum_unavailable")
        return data

    @staticmethod
    def _question_text(question: dict[str, Any]) -> str:
        for key in ("question_text", "text", "title", "content", "question"):
            value = question.get(key)
            if isinstance(value, str):
                return value
        return ""

    @staticmethod
    def _is_correct(response: requests.Response) -> bool:
        if response.status_code not in (200, 201, 204):
            return False
        if response.status_code == 204:
            return True
        try:
            body = response.json()
            data = body.get("data", {}) if isinstance(body, dict) else {}
            if isinstance(data, dict) and "is_correct" in data:
                return bool(data["is_correct"])
            if isinstance(body, dict) and "is_correct" in body:
                return bool(body["is_correct"])
        except ValueError:
            pass
        return False

    def solve_chapter(
        self, chapter_id: Any, bank: AnswerBank, cancel: threading.Event
    ) -> dict[str, Any]:
        try:
            response = self._request("GET", f"/api/v1/chapters/{chapter_id}/blocks")
        except requests.RequestException as exc:
            return {
                "ok": False,
                "state": "network_error",
                "solved": 0,
                "total": 0,
                "detail": type(exc).__name__,
            }
        data = self._data(response)
        if response.status_code != 200 or not isinstance(data, dict):
            return {
                "ok": False,
                "state": "http_error",
                "solved": 0,
                "total": 0,
                "detail": str(response.status_code),
            }
        blocks = data.get("blocks", [])
        cleared = {
            str(value)
            for value in (data.get("chapter", {}) or {}).get("cleared_block_ids", [])
        }
        questions = [block for block in blocks if block.get("type") == "question"]
        solved = 0
        unmatched = 0
        for question in questions:
            if cancel.is_set():
                return {
                    "ok": False,
                    "state": "stopped",
                    "solved": solved,
                    "total": len(questions),
                }
            if str(question.get("id")) in cleared:
                solved += 1
                continue
            answer = bank.finance_answer(self._question_text(question))
            options = question.get("options", [])
            selected_id = match_option(options, answer) if answer is not None else None
            if selected_id is None:
                unmatched += 1
                continue
            try:
                answer_response = self._request(
                    "POST",
                    f"/api/v1/chapters/{chapter_id}/answer",
                    json={
                        "block_id": question.get("id"),
                        "selected_option_id": selected_id,
                        "hint_used": 0,
                    },
                )
            except requests.RequestException:
                continue
            if self._is_correct(answer_response):
                solved += 1
                continue
            # Use the platform's explicit correction when present; do not guess.
            try:
                body = answer_response.json()
                result = body.get("data", {}) if isinstance(body, dict) else {}
                correct_id = (
                    result.get("correct_option_id")
                    if isinstance(result, dict)
                    else None
                )
                if correct_id is not None:
                    retry = self._request(
                        "POST",
                        f"/api/v1/chapters/{chapter_id}/answer",
                        json={
                            "block_id": question.get("id"),
                            "selected_option_id": correct_id,
                            "hint_used": 0,
                        },
                    )
                    if self._is_correct(retry):
                        solved += 1
            except (requests.RequestException, ValueError):
                continue

        if questions and solved == len(questions):
            try:
                complete = self._request(
                    "POST", f"/api/v1/chapters/{chapter_id}/complete"
                )
                ok = complete.status_code in (200, 201, 204)
            except requests.RequestException:
                ok = False
        else:
            ok = False
        state = (
            "completed"
            if ok
            else ("partial" if unmatched or solved < len(questions) else "unverified")
        )
        return {
            "ok": ok,
            "state": state,
            "solved": solved,
            "total": len(questions),
            "unmatched": unmatched,
        }

    def solve_review(self, review_id: Any) -> dict[str, Any]:
        try:
            response = self._request("POST", f"/api/v1/reviews/{review_id}/complete")
            ok = response.status_code in (200, 201, 204)
            return {
                "ok": ok,
                "state": "completed" if ok else "failed",
                "solved": int(ok),
                "total": 1,
            }
        except requests.RequestException:
            return {"ok": False, "state": "network_error", "solved": 0, "total": 1}

    def solve_test(
        self, test_id: Any, bank: AnswerBank, cancel: threading.Event
    ) -> dict[str, Any]:
        try:
            response = self._request("POST", f"/api/v1/tests/{test_id}/start")
        except requests.RequestException:
            return {"ok": False, "state": "network_error", "solved": 0, "total": 0}
        data = self._data(response)
        if response.status_code != 200 or not isinstance(data, dict):
            return {"ok": False, "state": "start_failed", "solved": 0, "total": 0}
        questions_map = data.get("questions", {})
        options_map = data.get("options", {})
        test_questions = data.get("test_questions", [])
        answers: list[tuple[Any, Any]] = []
        for test_question in test_questions:
            if cancel.is_set():
                return {
                    "ok": False,
                    "state": "stopped",
                    "solved": 0,
                    "total": len(test_questions),
                }
            question_id = str(test_question.get("question_id", ""))
            question_info = questions_map.get(question_id, {})
            question_text = self._question_text(question_info)
            options = options_map.get(question_id, [])
            answer_text = bank.finance_answer(question_text) if question_text else None
            selected_id = (
                match_option(options, answer_text) if answer_text is not None else None
            )
            if selected_id is not None:
                answers.append((test_question.get("id"), selected_id))
        if not test_questions or len(answers) != len(test_questions):
            return {
                "ok": False,
                "state": "partial",
                "solved": len(answers),
                "total": len(test_questions),
                "unmatched": len(test_questions) - len(answers),
            }
        accepted = 0
        for test_question_id, option_id in answers:
            if cancel.is_set():
                return {
                    "ok": False,
                    "state": "stopped",
                    "solved": accepted,
                    "total": len(test_questions),
                }
            try:
                result = self._request(
                    "PUT",
                    f"/api/v1/tests/{test_id}/questions/{test_question_id}/answer",
                    json={"selected_option_id": option_id},
                )
                if result.status_code in (200, 201, 204):
                    accepted += 1
            except requests.RequestException:
                continue
        try:
            submit = self._request("POST", f"/api/v1/tests/{test_id}/submit")
            if submit.status_code not in (200, 201, 204):
                return {
                    "ok": False,
                    "state": "submit_failed",
                    "solved": accepted,
                    "total": len(test_questions),
                }
            history_response = self._request("GET", f"/api/v1/tests/{test_id}/history")
        except requests.RequestException:
            return {
                "ok": False,
                "state": "unverified",
                "solved": accepted,
                "total": len(test_questions),
            }
        history = (
            self._data(history_response)
            if history_response.status_code == 200
            else None
        )
        if isinstance(history, list):
            for attempt in history:
                if attempt.get("status") == "completed":
                    passed = attempt.get("passed") is True
                    score = int(attempt.get("correct_count") or 0)
                    return {
                        "ok": passed,
                        "state": "completed" if passed else "not_passed",
                        "solved": score,
                        "total": len(test_questions),
                    }
        return {
            "ok": False,
            "state": "unverified",
            "solved": accepted,
            "total": len(test_questions),
        }

    def run(
        self,
        bank: AnswerBank,
        cancel: threading.Event,
        progress: Callable[[str], None] | None = None,
    ) -> dict[str, Any]:
        try:
            units = self._curriculum()
        except (requests.RequestException, RuntimeError) as exc:
            return {
                "items_total": 0,
                "items_done": 0,
                "items_partial": 0,
                "questions_solved": 0,
                "questions_total": 0,
                "error": str(exc),
            }
        items = [item for unit in units for item in unit.get("items", [])]
        stats = {
            "items_total": len(items),
            "items_done": 0,
            "items_partial": 0,
            "questions_solved": 0,
            "questions_total": 0,
            "stopped": False,
        }
        for index, item in enumerate(items, 1):
            if cancel.is_set():
                stats["stopped"] = True
                break
            if item.get("is_completed"):
                stats["items_done"] += 1
                continue
            item_type = item.get("item_type")
            item_id = item.get("id")
            if item_type == "chapter":
                result = self.solve_chapter(item_id, bank, cancel)
            elif item_type == "review":
                result = self.solve_review(item_id)
            elif item_type == "test":
                result = self.solve_test(item_id, bank, cancel)
            else:
                stats["items_partial"] += 1
                continue
            stats["questions_solved"] += int(result.get("solved", 0))
            stats["questions_total"] += int(result.get("total", 0))
            if result.get("ok"):
                stats["items_done"] += 1
            else:
                stats["items_partial"] += 1
            if progress:
                title = str(item.get("title") or item_type or "عنصر")[:40]
                progress(
                    f"الثقافة المالية: {index}/{len(items)} — {title} — {result.get('state', 'غير مكتمل')}"
                )
        return stats
