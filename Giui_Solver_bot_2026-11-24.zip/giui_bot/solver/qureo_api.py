"""Qureo login and chapter-solving client using the reviewed public API flow."""

from __future__ import annotations

import threading
from typing import Any, Callable

import requests

from .data import AnswerBank

PORTAL = "https://me-portal.qureo.education"
API = "https://me-tp.qureo.education"
COURSES = {
    "javascript_g1": {
        "content_id": "javascript_ar",
        "label": "JavaScript (أولى ثانوي)",
    },
    "javascript": {"content_id": "javascript_ar", "label": "JavaScript"},
    "python": {"content_id": "python_short_ar", "label": "Python"},
}


class QureoAPI:
    def __init__(self, student_id: str, password: str, timeout: int = 25):
        self.student_id = student_id
        self.password = password
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update(
            {
                "accept": "application/json, text/plain, */*",
                "content-type": "application/json",
                "origin": API,
                "referer": f"{API}/",
                "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36",
            }
        )

    def login(self) -> tuple[bool, str]:
        headers = {"origin": PORTAL, "referer": f"{PORTAL}/"}
        try:
            response = self.session.post(
                f"{PORTAL}/oauth2/password-login",
                json={"student_id": self.student_id, "password": self.password},
                headers=headers,
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            return False, f"تعذر الاتصال بمنصة Qureo ({type(exc).__name__})."
        token = self.session.cookies.get("egy_student_access_token")
        if response.status_code == 200 and token:
            self.session.headers["authorization"] = f"Bearer {token}"
            return True, ""
        if response.status_code in (401, 403):
            return False, "بيانات الدخول إلى Qureo غير صحيحة أو الحساب غير مخوّل."
        return False, f"تعذر تسجيل الدخول إلى Qureo (HTTP {response.status_code})."

    def _request(self, method: str, path: str, **kwargs: Any) -> requests.Response:
        return self.session.request(
            method, f"{API}{path}", timeout=self.timeout, **kwargs
        )

    def _status(self, chapter_id: str, content_id: str) -> tuple[int, bool]:
        self.session.cookies.set(
            "student_selected_content_id", content_id, domain="me-tp.qureo.education"
        )
        self.session.cookies.set(
            "_cf_s_path",
            f"/contents/chapter/{chapter_id}",
            domain="me-tp.qureo.education",
        )
        try:
            response = self._request(
                "GET", f"/api/study/students/chapters/{chapter_id}"
            )
            if response.status_code == 200:
                data = response.json()
                return int(data.get("best_correct_count") or 0), data.get(
                    "completed_at"
                ) is not None
        except (requests.RequestException, ValueError, TypeError):
            pass
        return 0, False

    def _complete_lectures(self, chapter_id: str, content_id: str) -> bool:
        self.session.cookies.set(
            "student_selected_content_id", content_id, domain="me-tp.qureo.education"
        )
        self.session.cookies.set(
            "_cf_s_path",
            f"/contents/chapter/{chapter_id}",
            domain="me-tp.qureo.education",
        )
        try:
            response = self._request("GET", f"/api/study/chapters/{chapter_id}")
            if response.status_code != 200:
                return False
            lectures = response.json().get("lectures", [])
            for lecture in lectures:
                lecture_id = lecture.get("id")
                if lecture_id is None:
                    continue
                self._request(
                    "PUT", f"/api/study/students/lectures/{lecture_id}", json={}
                )
                complete = self._request(
                    "PUT",
                    f"/api/study/students/lectures/{lecture_id}/complete",
                    json={},
                )
                if complete.status_code not in (200, 204):
                    return False
            return True
        except (requests.RequestException, ValueError, TypeError):
            return False

    @staticmethod
    def _entry_answer(entry: Any) -> Any:
        if isinstance(entry, dict):
            return entry.get("answer")
        if isinstance(entry, (tuple, list)) and len(entry) > 1:
            return entry[1]
        return entry

    def _solve_chapter(
        self,
        chapter_id: str,
        content_id: str,
        course: str,
        bank: AnswerBank,
        cancel: threading.Event,
    ) -> dict[str, Any]:
        self.session.cookies.set(
            "student_selected_content_id", content_id, domain="me-tp.qureo.education"
        )
        self.session.cookies.set(
            "_cf_s_path",
            f"/contents/chapter/{chapter_id}",
            domain="me-tp.qureo.education",
        )
        chapter_answers = bank.qureo_answers(course, chapter_id)
        expected_total = len(chapter_answers)
        before_count, already_done = self._status(chapter_id, content_id)
        if already_done and before_count >= expected_total:
            return {
                "state": "already_done",
                "solved": expected_total,
                "total": expected_total,
                "verified": True,
            }

        self._complete_lectures(chapter_id, content_id)
        try:
            response = self._request("GET", f"/api/study/chapters/{chapter_id}/test")
        except requests.RequestException as exc:
            return {
                "state": "network_error",
                "solved": 0,
                "total": 0,
                "detail": type(exc).__name__,
            }
        if response.status_code == 403:
            return {"state": "locked", "solved": 0, "total": 0}
        if response.status_code != 200:
            return {
                "state": "http_error",
                "solved": 0,
                "total": 0,
                "detail": str(response.status_code),
            }
        try:
            questions = response.json()
        except ValueError:
            return {"state": "invalid_response", "solved": 0, "total": 0}
        if not isinstance(questions, list):
            return {"state": "invalid_response", "solved": 0, "total": 0}

        self._request("PUT", f"/api/study/students/chapters/{chapter_id}/test", json={})
        submitted = 0
        missing = 0
        for item in questions:
            if cancel.is_set():
                return {
                    "state": "stopped",
                    "solved": submitted,
                    "total": len(questions),
                }
            question = item.get("question") or {}
            qid = str(question.get("id", ""))
            qtype = question.get("type")
            answer = self._entry_answer(chapter_answers.get(qid))
            if answer is None:
                missing += 1
                continue
            try:
                if qtype == "description":
                    route = (
                        f"/api/study/students/test-questions/{qid}/answer/description"
                    )
                    payload = {"answer_code": str(answer)}
                elif qtype == "choice":
                    route = f"/api/study/students/test-questions/{qid}/answer/choice"
                    payload = {"choice_id": int(answer)}
                else:
                    missing += 1
                    continue
                answer_response = self._request("PUT", route, json=payload)
            except (requests.RequestException, TypeError, ValueError):
                continue
            if answer_response.status_code in (200, 204):
                submitted += 1
                continue
            # Some chapters expose the answer under the review endpoint. Use this
            # only after the regular test endpoint rejects the known answer.
            review_route = route.replace("test-questions", "review-questions")
            try:
                fallback = self._request("PUT", review_route, json=payload)
                if fallback.status_code in (200, 204):
                    submitted += 1
            except requests.RequestException:
                continue

        best, completed = self._status(chapter_id, content_id)
        verified = completed and best >= len(questions)
        if verified:
            state = "completed"
        elif cancel.is_set():
            state = "stopped"
        elif missing:
            state = "partial"
        else:
            state = "unverified"
        return {
            "state": state,
            "solved": min(len(questions), max(best, submitted)),
            "total": len(questions),
            "missing": missing,
            "verified": verified,
        }

    def run_course(
        self,
        course: str,
        bank: AnswerBank,
        cancel: threading.Event,
        progress: Callable[[str], None] | None = None,
    ) -> dict[str, Any]:
        spec = COURSES[course]
        content_id = spec["content_id"]
        if course == "javascript_g1":
            source = bank.javascript_first_grade
        elif course == "javascript":
            source = bank.javascript
        else:
            source = bank.python
        chapter_ids = sorted(source.keys(), key=lambda key: int(key))
        stats = {
            "course": course,
            "chapters_total": len(chapter_ids),
            "chapters_done": 0,
            "chapters_partial": 0,
            "chapters_locked": 0,
            "questions_solved": 0,
            "questions_total": 0,
            "stopped": False,
        }
        for index, chapter_id in enumerate(chapter_ids, 1):
            if cancel.is_set():
                stats["stopped"] = True
                break
            result = self._solve_chapter(chapter_id, content_id, course, bank, cancel)
            stats["questions_solved"] += int(result.get("solved", 0))
            stats["questions_total"] += int(result.get("total", 0))
            if result["state"] in ("completed", "already_done"):
                stats["chapters_done"] += 1
            elif result["state"] == "locked":
                stats["chapters_locked"] += 1
            elif result["state"] == "stopped":
                stats["stopped"] = True
                break
            else:
                stats["chapters_partial"] += 1
            if progress:
                progress(
                    f"{spec['label']}: فصل {index}/{len(chapter_ids)} — {result['state']}"
                )
        return stats
