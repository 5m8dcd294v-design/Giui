"""Canonical answer-bank loading and conservative text matching."""

from __future__ import annotations

import json
import re
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Iterable

DATA_DIR = Path(__file__).resolve().parents[1] / "data"


def load_json(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object in {path}")
    return value


def normalize_text(value: Any) -> str:
    """Normalize Arabic/English text while preserving letters and digits."""
    if value is None:
        return ""
    text = unicodedata.normalize("NFKC", str(value)).casefold()
    text = re.sub(r"[\u064b-\u065f\u0670\u0640]", "", text)
    text = text.translate(
        str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ى": "ي", "ؤ": "و", "ئ": "ي"})
    )
    return "".join(char for char in text if char.isalnum())


def _iter_finance_questions(payload: dict[str, Any]) -> Iterable[tuple[str, str]]:
    for level in payload.get("levels", {}).values():
        for item in level.get("questions", []):
            question = item.get("question")
            answer = item.get("answer")
            if question and answer:
                yield str(question), str(answer)


class AnswerBank:
    def __init__(
        self,
        python_path: str | Path | None = None,
        javascript_path: str | Path | None = None,
        javascript_first_grade_path: str | Path | None = None,
        finance_path: str | Path | None = None,
    ):
        python_path = python_path or DATA_DIR / "python_answers.json"
        javascript_path = javascript_path or DATA_DIR / "javascript_answers.json"
        javascript_first_grade_path = (
            javascript_first_grade_path
            or DATA_DIR / "javascript_first_grade_answers.json"
        )
        finance_path = finance_path or DATA_DIR / "financial_culture_answers.json"
        self.python = load_json(python_path).get("chapters", {})
        self.javascript = load_json(javascript_path).get("chapters", {})
        self.javascript_first_grade = load_json(javascript_first_grade_path).get(
            "chapters", {}
        )
        finance_payload = load_json(finance_path)
        self.finance_pairs = list(_iter_finance_questions(finance_payload))
        self.finance_exact: dict[str, str] = {}
        for question, answer in self.finance_pairs:
            self.finance_exact.setdefault(normalize_text(question), answer)

    def qureo_answers(self, course: str, chapter_id: str | int) -> dict[str, Any]:
        if course == "javascript_g1":
            source = self.javascript_first_grade
        elif course == "javascript":
            source = self.javascript
        else:
            source = self.python
        chapter = source.get(str(chapter_id), {})
        return chapter.get("answers") or chapter.get("questions") or {}

    def finance_answer(self, question: str, threshold: float = 0.90) -> str | None:
        key = normalize_text(question)
        if not key:
            return None
        exact = self.finance_exact.get(key)
        if exact:
            return exact
        best_answer, best_score = None, 0.0
        for known_question, answer in self.finance_pairs:
            candidate = normalize_text(known_question)
            if not candidate:
                continue
            score = SequenceMatcher(None, key, candidate, autojunk=False).ratio()
            if score > best_score:
                best_answer, best_score = answer, score
        return best_answer if best_score >= threshold else None


def option_text(option: dict[str, Any]) -> str:
    for key in ("text", "option_text", "content", "title", "name", "label", "value"):
        value = option.get(key)
        if value is not None and not isinstance(value, (dict, list)):
            return str(value)
    return ""


def match_option(
    options: list[dict[str, Any]], answer: str | int | None, threshold: float = 0.88
) -> Any | None:
    """Return the option ID only for a defensible text match; never guess option 1."""
    if answer is None:
        return None
    if isinstance(answer, int) or (isinstance(answer, str) and answer.isdigit()):
        answer_id = int(answer)
        for option in options:
            try:
                if int(option.get("id")) == answer_id:
                    return option.get("id")
            except (TypeError, ValueError):
                continue
    key = normalize_text(answer)
    if not key:
        return None
    normalized = [(option, normalize_text(option_text(option))) for option in options]
    for option, text in normalized:
        if text and (text == key or key in text or text in key):
            return option.get("id")
    best_option, best_score = None, 0.0
    for option, text in normalized:
        if not text:
            continue
        score = SequenceMatcher(None, key, text, autojunk=False).ratio()
        if score > best_score:
            best_option, best_score = option, score
    return best_option.get("id") if best_option and best_score >= threshold else None
