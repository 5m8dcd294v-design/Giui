"""Pure grade, track, and platform planning used by the Telegram FSM."""

from __future__ import annotations

TRACKS = {
    (1, "programming"): ("javascript_g1",),
    (2, "programming"): ("javascript", "python"),
    (2, "finance"): ("finance",),
    (2, "all"): ("javascript", "python", "finance"),
}


def courses_for_selection(grade: int, track: str) -> list[str]:
    try:
        return list(TRACKS[(int(grade), track)])
    except (KeyError, ValueError):
        raise ValueError("Invalid grade/track combination") from None


def platforms_for_courses(courses: list[str] | tuple[str, ...]) -> list[str]:
    result = []
    if any(course in ("javascript", "javascript_g1", "python") for course in courses):
        result.append("qureo")
    if "finance" in courses:
        result.append("spx")
    return result
