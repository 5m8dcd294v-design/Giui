"""Solver modules for Qureo and SPX."""
