"""Environment-based configuration; no secrets belong in source files."""

from __future__ import annotations

import os
from pathlib import Path


def load_config() -> dict[str, object]:
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        raise RuntimeError(
            "BOT_TOKEN is required. Copy .env.example to .env and add a new token from BotFather."
        )
    try:
        owner_id = int(os.getenv("OWNER_ID", "0").strip() or "0")
    except ValueError as exc:
        raise RuntimeError("OWNER_ID must be a numeric Telegram user ID.") from exc
    raw_ids = os.getenv("ALLOWED_USER_IDS", "").strip()
    allowlist = {
        int(value.strip()) for value in raw_ids.split(",") if value.strip().isdigit()
    }
    database_path = os.getenv("DATABASE_PATH", "").strip() or str(
        Path(__file__).resolve().parent / "data" / "subscriptions.sqlite3"
    )
    return {
        "bot_token": token,
        "owner_id": owner_id,
        "allowed_user_ids": allowlist,
        "max_parallel_jobs": max(1, min(8, int(os.getenv("MAX_PARALLEL_JOBS", "3")))),
        "session_ttl_minutes": max(5, int(os.getenv("SESSION_TTL_MINUTES", "20"))),
        "database_path": database_path,
    }
