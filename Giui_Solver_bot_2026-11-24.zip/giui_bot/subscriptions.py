"""SQLite subscription ledger with single-use hashed redeem codes."""

from __future__ import annotations

import hashlib
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="seconds")


def _parse(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def normalize_code(code: str) -> str:
    return "".join(char for char in code.upper() if char.isalnum())


def code_hash(code: str) -> str:
    return hashlib.sha256(normalize_code(code).encode("utf-8")).hexdigest()


class _ClosingConnection(sqlite3.Connection):
    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> Any:
        try:
            return super().__exit__(exc_type, exc, traceback)
        finally:
            self.close()


class SubscriptionStore:
    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(
            self.db_path, timeout=20, isolation_level=None, factory=_ClosingConnection
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 20000")
        return connection

    def _init_db(self) -> None:
        with self._connect() as db:
            db.execute("PRAGMA journal_mode = WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS codes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    code_hash TEXT NOT NULL UNIQUE,
                    code_hint TEXT NOT NULL,
                    duration_days INTEGER NOT NULL,
                    created_by INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    redeemed_by INTEGER,
                    redeemed_at TEXT,
                    revoked_at TEXT
                );
                CREATE TABLE IF NOT EXISTS subscription_grants (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    code_id INTEGER NOT NULL UNIQUE REFERENCES codes(id),
                    granted_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    revoked_at TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_grants_user ON subscription_grants(user_id, expires_at);
                CREATE INDEX IF NOT EXISTS idx_codes_created ON codes(created_at DESC);
            """)

    @staticmethod
    def _make_code() -> tuple[str, str, str]:
        alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        groups = ["".join(secrets.choice(alphabet) for _ in range(4)) for _ in range(3)]
        raw = "GIUI" + "".join(groups)
        visible = "GIUI-" + "-".join(groups)
        hint = f"GIUI-{groups[0]}-****-****"
        return visible, code_hash(raw), hint

    def create_codes(
        self, created_by: int, duration_days: int, count: int
    ) -> list[dict[str, Any]]:
        if not 1 <= int(duration_days) <= 3650:
            raise ValueError("duration_days must be between 1 and 3650")
        if not 1 <= int(count) <= 30:
            raise ValueError("count must be between 1 and 30")
        created: list[dict[str, Any]] = []
        now = _stamp(_now())
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            for _ in range(int(count)):
                while True:
                    visible, hashed, hint = self._make_code()
                    try:
                        cursor = db.execute(
                            "INSERT INTO codes(code_hash, code_hint, duration_days, created_by, created_at) VALUES(?,?,?,?,?)",
                            (hashed, hint, int(duration_days), int(created_by), now),
                        )
                        created.append(
                            {
                                "id": cursor.lastrowid,
                                "code": visible,
                                "hint": hint,
                                "duration_days": int(duration_days),
                            }
                        )
                        break
                    except sqlite3.IntegrityError:
                        continue
            db.commit()
        return created

    def redeem(self, user_id: int, code: str) -> dict[str, Any]:
        hashed = code_hash(code)
        now = _now()
        now_text = _stamp(now)
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute(
                "SELECT * FROM codes WHERE code_hash=?", (hashed,)
            ).fetchone()
            if not row:
                db.rollback()
                return {"ok": False, "reason": "invalid"}
            if row["revoked_at"]:
                db.rollback()
                return {"ok": False, "reason": "revoked"}
            if row["redeemed_by"] is not None:
                db.rollback()
                return {"ok": False, "reason": "used"}
            current = db.execute(
                "SELECT MAX(expires_at) AS expires_at FROM subscription_grants "
                "WHERE user_id=? AND revoked_at IS NULL",
                (int(user_id),),
            ).fetchone()["expires_at"]
            current_dt = _parse(current)
            start = max(now, current_dt) if current_dt else now
            expires = start + timedelta(days=int(row["duration_days"]))
            db.execute(
                "UPDATE codes SET redeemed_by=?, redeemed_at=? WHERE id=?",
                (int(user_id), now_text, int(row["id"])),
            )
            db.execute(
                "INSERT INTO subscription_grants(user_id, code_id, granted_at, expires_at) VALUES(?,?,?,?)",
                (int(user_id), int(row["id"]), now_text, _stamp(expires)),
            )
            db.commit()
            return {
                "ok": True,
                "expires_at": _stamp(expires),
                "duration_days": int(row["duration_days"]),
            }

    def status(self, user_id: int) -> dict[str, Any]:
        with self._connect() as db:
            row = db.execute(
                "SELECT MAX(expires_at) AS expires_at FROM subscription_grants "
                "WHERE user_id=? AND revoked_at IS NULL",
                (int(user_id),),
            ).fetchone()
        expires = _parse(row["expires_at"] if row else None)
        active = bool(expires and expires > _now())
        return {"active": active, "expires_at": _stamp(expires) if expires else None}

    def latest_codes(self, limit: int = 15) -> list[dict[str, Any]]:
        with self._connect() as db:
            rows = db.execute(
                "SELECT c.id, c.code_hint, c.duration_days, c.created_at, c.redeemed_by, "
                "c.redeemed_at, c.revoked_at, g.expires_at "
                "FROM codes c LEFT JOIN subscription_grants g ON g.code_id=c.id "
                "ORDER BY c.id DESC LIMIT ?",
                (max(1, min(50, int(limit))),),
            ).fetchall()
        result = []
        for row in rows:
            expires = _parse(row["expires_at"])
            if row["revoked_at"]:
                status = "revoked"
            elif row["redeemed_by"] is None:
                status = "unused"
            elif expires and expires > _now():
                status = "active"
            else:
                status = "expired"
            result.append({**dict(row), "status": status})
        return result

    def revoke_code(self, code_id: int) -> dict[str, Any]:
        now = _stamp(_now())
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute(
                "SELECT id, revoked_at, redeemed_by FROM codes WHERE id=?",
                (int(code_id),),
            ).fetchone()
            if not row:
                db.rollback()
                return {"ok": False, "reason": "not_found"}
            if row["revoked_at"]:
                db.rollback()
                return {"ok": False, "reason": "already_revoked"}
            db.execute("UPDATE codes SET revoked_at=? WHERE id=?", (now, int(code_id)))
            db.execute(
                "UPDATE subscription_grants SET revoked_at=? WHERE code_id=? AND revoked_at IS NULL",
                (now, int(code_id)),
            )
            db.commit()
            return {"ok": True, "redeemed_by": row["redeemed_by"]}

    def active_subscribers(self, limit: int = 30) -> list[dict[str, Any]]:
        with self._connect() as db:
            rows = db.execute(
                "SELECT user_id, MAX(expires_at) AS expires_at FROM subscription_grants "
                "WHERE revoked_at IS NULL GROUP BY user_id ORDER BY expires_at DESC LIMIT ?",
                (max(1, min(100, int(limit))),),
            ).fetchall()
        now = _now()
        return [dict(row) for row in rows if (_parse(row["expires_at"]) or now) > now]

    def revoke_user(self, user_id: int) -> int:
        now = _stamp(_now())
        with self._connect() as db:
            cursor = db.execute(
                "UPDATE subscription_grants SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL",
                (now, int(user_id)),
            )
            return cursor.rowcount
