"""Arabic Telegram UI for combined Qureo and SPX solving."""

from __future__ import annotations

import html
import threading
import time
from typing import Any

import telebot
from telebot import types

from config import load_config
from solver.data import AnswerBank
from solver.flow import courses_for_selection, platforms_for_courses
from solver.qureo_api import QureoAPI
from solver.spx_api import SPXAPI
from subscriptions import SubscriptionStore

CONFIG = load_config()
BOT = telebot.TeleBot(
    CONFIG["bot_token"], parse_mode="HTML", threaded=True, num_threads=8
)
ALLOWED_USERS: set[int] = CONFIG["allowed_user_ids"]  # type: ignore[assignment]
OWNER_ID = int(CONFIG["owner_id"])
SUBSCRIPTIONS = SubscriptionStore(str(CONFIG["database_path"]))
SESSIONS: dict[int, dict[str, Any]] = {}
SESSIONS_LOCK = threading.RLock()
JOB_SLOTS = threading.BoundedSemaphore(int(CONFIG["max_parallel_jobs"]))


class StyledButton(types.InlineKeyboardButton):
    """Carry Telegram's button style field while retaining emoji fallbacks."""

    def __init__(self, *args: Any, _style: str | None = None, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self._style = _style

    def to_dict(self) -> dict[str, Any]:
        result = super().to_dict()
        if self._style:
            result["style"] = self._style
        return result

    def to_dic(self) -> dict[str, Any]:
        return self.to_dict()

    def to_json(self) -> str:
        import json

        return json.dumps(self.to_dict(), ensure_ascii=False)


def button(text: str, data: str, style: str = "primary") -> StyledButton:
    return StyledButton(text=text, callback_data=data, _style=style)


def private_chat(message: Any) -> bool:
    return getattr(message.chat, "type", "") == "private"


def authorized(user_id: int) -> bool:
    return is_owner(user_id) or not ALLOWED_USERS or user_id in ALLOWED_USERS


def get_session(user_id: int) -> dict[str, Any]:
    with SESSIONS_LOCK:
        state = SESSIONS.setdefault(
            user_id, {"running": False, "last_activity": time.monotonic()}
        )
        state["last_activity"] = time.monotonic()
        return state


def wipe_credentials(state: dict[str, Any]) -> None:
    for key in ("qureo_id", "qureo_password", "spx_id", "spx_password"):
        state.pop(key, None)


def fresh_state(user_id: int) -> dict[str, Any]:
    with SESSIONS_LOCK:
        old = SESSIONS.get(user_id)
        if old and old.get("running"):
            return old
        state = {"running": False, "last_activity": time.monotonic()}
        SESSIONS[user_id] = state
        return state


def keyboard(rows: list[list[StyledButton]]) -> types.InlineKeyboardMarkup:
    markup = types.InlineKeyboardMarkup()
    for row in rows:
        markup.row(*row)
    return markup


def grade_keyboard() -> types.InlineKeyboardMarkup:
    return keyboard(
        [
            [button("🟦 أولى ثانوي", "grade_1", "primary")],
            [button("🟩 تانية ثانوي", "grade_2", "success")],
            [button("ℹ️ المساعدة", "help", "primary")],
        ]
    )


def grade2_keyboard() -> types.InlineKeyboardMarkup:
    return keyboard(
        [
            [button("💻 JavaScript + Python", "track_programming", "primary")],
            [button("💰 الثقافة المالية", "track_finance", "success")],
            [button("🚀 الكل", "track_all", "success")],
            [button("↩️ رجوع", "back_grades", "primary")],
        ]
    )


def confirm_keyboard() -> types.InlineKeyboardMarkup:
    return keyboard(
        [
            [button("▶️ ابدأ الحل", "run", "success")],
            [button("🛑 إلغاء", "cancel", "danger")],
        ]
    )


def stop_keyboard() -> types.InlineKeyboardMarkup:
    return keyboard([[button("⏹️ إيقاف الحل", "stop", "danger")]])


def is_owner(user_id: int) -> bool:
    return OWNER_ID > 0 and user_id == OWNER_ID


def has_access(user_id: int) -> bool:
    return is_owner(user_id) or SUBSCRIPTIONS.status(user_id)["active"]


def admin_keyboard() -> types.InlineKeyboardMarkup:
    return keyboard(
        [
            [button("➕ إنشاء أكواد", "admin_create", "success")],
            [button("📋 الأكواد الأخيرة / تعطيل", "admin_list", "primary")],
            [button("👥 المشتركين / إلغاء", "admin_users", "primary")],
        ]
    )


def duration_keyboard() -> types.InlineKeyboardMarkup:
    return keyboard(
        [
            [
                button("7 أيام", "admin_days:7", "primary"),
                button("30 يوم", "admin_days:30", "success"),
            ],
            [
                button("90 يوم", "admin_days:90", "success"),
                button("365 يوم", "admin_days:365", "success"),
            ],
            [button("مدة مخصصة", "admin_days:custom", "primary")],
            [button("↩️ لوحة الإدارة", "admin_home", "primary")],
        ]
    )


def redeem_result(chat_id: int, user_id: int, code: str) -> None:
    result = SUBSCRIPTIONS.redeem(user_id, code)
    if result["ok"]:
        expiry = result["expires_at"].replace("T", " ").replace("+00:00", " UTC")
        BOT.send_message(
            chat_id,
            f"✅ تم تفعيل الاشتراك لمدة {result['duration_days']} يوم.\nينتهي: <code>{expiry}</code>\nابعت /start للبدء.",
        )
    else:
        messages = {
            "invalid": "الكود غير صحيح.",
            "revoked": "الكود ملغي من المالك.",
            "used": "الكود مستخدم من قبل.",
        }
        BOT.send_message(
            chat_id, f"❌ {messages.get(result['reason'], 'تعذر تفعيل الكود.')}"
        )


def show_admin_codes(chat_id: int) -> None:
    codes = SUBSCRIPTIONS.latest_codes(12)
    if not codes:
        BOT.send_message(
            chat_id, "لسه مفيش أكواد متسجلة.", reply_markup=admin_keyboard()
        )
        return
    labels = {
        "unused": "غير مستخدم",
        "active": "مفعّل",
        "expired": "منتهي",
        "revoked": "ملغي",
    }
    lines = ["<b>آخر الأكواد</b> (الكود الكامل يظهر مرة واحدة عند إنشائه):"]
    rows = []
    for item in codes:
        lines.append(
            f"• <code>{html.escape(item['code_hint'])}</code> — {item['duration_days']} يوم — {labels[item['status']]}"
        )
        if item["status"] in ("unused", "active"):
            rows.append(
                [
                    button(
                        f"⛔ تعطيل {item['code_hint']}",
                        f"admin_revoke:{item['id']}",
                        "danger",
                    )
                ]
            )
    rows.append([button("↩️ لوحة الإدارة", "admin_home", "primary")])
    BOT.send_message(chat_id, "\n".join(lines), reply_markup=keyboard(rows))


def show_admin_users(chat_id: int) -> None:
    users = SUBSCRIPTIONS.active_subscribers(25)
    if not users:
        BOT.send_message(
            chat_id, "مافيش اشتراكات نشطة حاليًا.", reply_markup=admin_keyboard()
        )
        return
    lines = ["<b>المشتركون النشطون</b>:"]
    rows = []
    for item in users:
        expiry = item["expires_at"].replace("T", " ").replace("+00:00", " UTC")
        lines.append(f"• <code>{item['user_id']}</code> — حتى <code>{expiry}</code>")
        rows.append(
            [
                button(
                    f"⛔ إلغاء {item['user_id']}",
                    f"admin_user_revoke:{item['user_id']}",
                    "danger",
                )
            ]
        )
    rows.append([button("↩️ لوحة الإدارة", "admin_home", "primary")])
    BOT.send_message(chat_id, "\n".join(lines), reply_markup=keyboard(rows))


def send_start(chat_id: int) -> None:
    BOT.send_message(
        chat_id,
        "<b>أهلًا بيك في Giui Solver</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "اختار الصف الدراسي، وبعدها المادة أو المسار.\n"
        "🔐 بيانات الدخول بتتطلب في الخاص، وبتفضل مؤقتًا في ذاكرة التشغيل فقط؛ "
        "مش بتتخزن في ملفات أو قاعدة بيانات.\n\n"
        "<i>ملاحظة: إتمام الحل يعتمد على استجابة المنصة وتوفر إجابة مطابقة في بنك البيانات.</i>",
        reply_markup=grade_keyboard(),
    )


def _required_platforms(state: dict[str, Any]) -> list[str]:
    return platforms_for_courses(state.get("courses", []))


def ask_platform_id(chat_id: int, state: dict[str, Any]) -> None:
    queue = state.get("credential_queue", [])
    index = int(state.get("credential_index", 0))
    if index >= len(queue):
        send_confirmation(chat_id, state)
        return
    platform = queue[index]
    state["credential_platform"] = platform
    state["step"] = f"{platform}_id"
    name = "Qureo" if platform == "qureo" else "الثقافة المالية"
    BOT.send_message(
        chat_id,
        f"اكتب <b>كود الدخول</b> الخاص بـ {name}.\n"
        "ما تبعتش كلمة السر هنا لحد تاني؛ البوت هيطلبها برسالة خاصة بعدها.",
    )


def send_confirmation(chat_id: int, state: dict[str, Any]) -> None:
    state["step"] = "confirm"
    grade = "أولى ثانوي" if state.get("grade") == 1 else "تانية ثانوي"
    labels = {
        "javascript_g1": "JavaScript أولى (42 فصلًا)",
        "javascript": "JavaScript تانية (54 فصلًا)",
        "python": "Python (25 فصلًا)",
        "finance": "الثقافة المالية",
    }
    selected = " + ".join(
        labels.get(course, course) for course in state.get("courses", [])
    )
    BOT.send_message(
        chat_id,
        f"<b>مراجعة الاختيار</b>\nالصف: <b>{grade}</b>\nالمسار: <b>{html.escape(selected)}</b>\n\n"
        "هبدأ المحاولة دلوقتي. تقدر توقفها من الزر أثناء التشغيل. بيانات الدخول هتتمسح من حالة البوت بعد انتهاء المحاولة.",
        reply_markup=confirm_keyboard(),
    )


def _progress_editor(chat_id: int, message_id: int):
    last_sent = {"time": 0.0, "text": ""}
    lock = threading.Lock()

    def update(text: str) -> None:
        now = time.monotonic()
        with lock:
            if text == last_sent["text"] or now - last_sent["time"] < 2.0:
                return
            last_sent["time"] = now
            last_sent["text"] = text
        try:
            BOT.edit_message_text(
                f"<b>⏳ جاري الحل</b>\n━━━━━━━━━━━━━━━━━━\n{html.escape(text)}\n\n"
                "التقدم بيتحدّث أثناء التنفيذ؛ استخدم زر الإيقاف لو حبيت.",
                chat_id,
                message_id,
                reply_markup=stop_keyboard(),
            )
        except Exception:
            pass

    return update


def _summary_text(results: list[tuple[str, Any]], stopped: bool) -> str:
    lines = ["<b>انتهت المحاولة</b>", "━━━━━━━━━━━━━━━━━━"]
    if not results:
        lines.append("مافيش نتيجة متاحة؛ راجع رسالة الخطأ أو جرّب لاحقًا.")
    for label, result in results:
        if isinstance(result, str):
            lines.append(f"❌ <b>{html.escape(label)}:</b> {html.escape(result)}")
            continue
        if label in ("JavaScript", "Python"):
            lines.append(
                f"{'✅' if result.get('chapters_done') == result.get('chapters_total') and not result.get('chapters_partial') else '⚠️'} "
                f"<b>{label}:</b> فصول مكتملة {result.get('chapters_done', 0)}/{result.get('chapters_total', 0)}، "
                f"إجابات مقبولة/مؤكدة {result.get('questions_solved', 0)}/{result.get('questions_total', 0)}"
            )
            if result.get("chapters_partial") or result.get("chapters_locked"):
                lines.append(
                    f"  فصول جزئية: {result.get('chapters_partial', 0)}، مقفولة: {result.get('chapters_locked', 0)}"
                )
        else:
            lines.append(
                f"{'✅' if result.get('items_partial', 0) == 0 else '⚠️'} <b>{label}:</b> "
                f"عناصر مكتملة {result.get('items_done', 0)}/{result.get('items_total', 0)}، "
                f"إجابات {result.get('questions_solved', 0)}/{result.get('questions_total', 0)}"
            )
            if result.get("error"):
                lines.append(
                    f"  تعذر تحميل المنهج: {html.escape(str(result['error']))}"
                )
    if stopped:
        lines.append("\n⏹️ تم إيقاف التشغيل بناءً على طلبك.")
    lines.append(
        "\nلو في فصول جزئية، راجع الحساب على المنصة؛ البوت ما بيحسبهاش مكتملة من غير تأكيد."
    )
    return "\n".join(lines)


def run_job(
    user_id: int,
    chat_id: int,
    status_message_id: int,
    courses: list[str],
    credentials: dict[str, str],
    cancel: threading.Event,
) -> None:
    results: list[tuple[str, Any]] = []
    progress = _progress_editor(chat_id, status_message_id)
    try:
        with JOB_SLOTS:
            bank = AnswerBank()
            qureo_courses = [
                course
                for course in courses
                if course in ("javascript_g1", "javascript", "python")
            ]
            if qureo_courses:
                client = QureoAPI(
                    credentials.get("qureo_id", ""),
                    credentials.get("qureo_password", ""),
                )
                progress("تسجيل الدخول إلى Qureo…")
                ok, error = client.login()
                if not ok:
                    for course in qureo_courses:
                        results.append(
                            ("Python" if course == "python" else "JavaScript", error)
                        )
                else:
                    for course in qureo_courses:
                        if cancel.is_set():
                            break
                        label = "Python" if course == "python" else "JavaScript"
                        results.append(
                            (label, client.run_course(course, bank, cancel, progress))
                        )
            if "finance" in courses and not cancel.is_set():
                client = SPXAPI(
                    credentials.get("spx_id", ""), credentials.get("spx_password", "")
                )
                progress("تسجيل الدخول إلى منصة الثقافة المالية…")
                ok, error = client.login()
                if not ok:
                    results.append(("الثقافة المالية", error))
                else:
                    results.append(
                        ("الثقافة المالية", client.run(bank, cancel, progress))
                    )
    except Exception as exc:
        results.append(("خطأ داخلي", f"{type(exc).__name__}: تعذر إكمال المهمة."))
    finally:
        with SESSIONS_LOCK:
            state = SESSIONS.get(user_id)
            if state:
                state["running"] = False
                state["step"] = "done"
                state["last_activity"] = time.monotonic()
                wipe_credentials(state)
        try:
            BOT.edit_message_text(
                _summary_text(results, cancel.is_set()),
                chat_id,
                status_message_id,
                reply_markup=grade_keyboard(),
            )
        except Exception:
            BOT.send_message(
                chat_id,
                _summary_text(results, cancel.is_set()),
                reply_markup=grade_keyboard(),
            )


def _start_credentials(
    state: dict[str, Any], courses: list[str], grade: int
) -> list[str]:
    state.clear()
    state.update(
        {
            "running": False,
            "grade": grade,
            "courses": courses,
            "credential_queue": [],
            "credential_index": 0,
            "last_activity": time.monotonic(),
        }
    )
    state["credential_queue"] = _required_platforms(state)
    return state["credential_queue"]


@BOT.message_handler(commands=["start"])
def on_start(message: Any) -> None:
    if not private_chat(message):
        BOT.reply_to(message, "استخدم البوت في محادثة خاصة لحماية بيانات الدخول.")
        return
    uid = message.from_user.id
    if not authorized(uid):
        BOT.reply_to(message, "البوت غير مفعّل لحسابك.")
        return
    if not has_access(uid):
        BOT.send_message(
            message.chat.id,
            "🔐 لازم تفعّل اشتراك الأول. ابعت <code>/redeem كودك</code>، "
            "أو <code>/status</code> لمراجعة الحالة.",
        )
        return
    state = get_session(uid)
    if state.get("running"):
        BOT.send_message(
            message.chat.id,
            "في محاولة شغالة بالفعل. تقدر توقفها من زر الإيقاف.",
            reply_markup=stop_keyboard(),
        )
        return
    fresh_state(uid)
    send_start(message.chat.id)


@BOT.message_handler(commands=["help"])
def on_help(message: Any) -> None:
    if private_chat(message) and authorized(message.from_user.id):
        BOT.send_message(
            message.chat.id,
            "أولى ثانوي: JavaScript (42 فصلًا). تانية ثانوي: JavaScript (54 فصلًا) وPython (25 فصلًا)، "
            "أو الثقافة المالية أو الكل. "
            "والثقافة المالية على SPX. استخدم /stop لإيقاف التشغيل و/start لإعادة الاختيار.\n"
            "بيانات الدخول مؤقتة في الذاكرة فقط وتُحذف من حالة البوت بعد انتهاء التشغيل.\n"
            "للاشتراك: <code>/redeem كودك</code> — للحالة: /status — للإدارة: /admin للمالك فقط.",
        )


@BOT.message_handler(commands=["id"])
def on_id(message: Any) -> None:
    if private_chat(message):
        BOT.reply_to(message, f"Telegram user ID: <code>{message.from_user.id}</code>")


@BOT.message_handler(commands=["status"])
def on_subscription_status(message: Any) -> None:
    if not private_chat(message) or not authorized(message.from_user.id):
        return
    if is_owner(message.from_user.id):
        BOT.reply_to(message, "حساب المالك مستثنى من الاشتراك.")
        return
    status = SUBSCRIPTIONS.status(message.from_user.id)
    if status["active"]:
        expiry = status["expires_at"].replace("T", " ").replace("+00:00", " UTC")
        BOT.reply_to(message, f"✅ اشتراكك نشط حتى <code>{expiry}</code>.")
    else:
        BOT.reply_to(message, "❌ مفيش اشتراك نشط. استخدم <code>/redeem كودك</code>.")


@BOT.message_handler(commands=["redeem"])
def on_redeem(message: Any) -> None:
    if not private_chat(message):
        BOT.reply_to(message, "استخدم /redeem في المحادثة الخاصة.")
        return
    if not authorized(message.from_user.id):
        BOT.reply_to(message, "البوت غير مفعّل لحسابك.")
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) == 2:
        try:
            BOT.delete_message(message.chat.id, message.message_id)
        except Exception:
            pass
        redeem_result(message.chat.id, message.from_user.id, parts[1])
    else:
        state = get_session(message.from_user.id)
        state["step"] = "redeem_code"
        BOT.reply_to(
            message,
            "ابعت كود الاشتراك في الرسالة التالية. تقدر تستخدم /cancel للإلغاء.",
        )


@BOT.message_handler(commands=["admin"])
def on_admin(message: Any) -> None:
    if not private_chat(message):
        BOT.reply_to(message, "لوحة الإدارة متاحة للمالك في الخاص فقط.")
        return
    if not is_owner(message.from_user.id):
        BOT.reply_to(message, "الأمر ده للمالك فقط.")
        return
    BOT.send_message(
        message.chat.id, "<b>لوحة إدارة الاشتراكات</b>", reply_markup=admin_keyboard()
    )


@BOT.message_handler(commands=["stop", "cancel"])
def on_stop(message: Any) -> None:
    if not private_chat(message) or not authorized(message.from_user.id):
        return
    state = get_session(message.from_user.id)
    event = state.get("cancel_event")
    if state.get("running") and event:
        event.set()
        BOT.reply_to(message, "استلمت طلب الإيقاف. هوقف عند أقرب نقطة آمنة.")
    else:
        wipe_credentials(state)
        state.clear()
        state.update({"running": False, "last_activity": time.monotonic()})
        BOT.reply_to(
            message, "اتلغت الخطوات الحالية. ابعت /start لو عايز تبدأ من جديد."
        )


@BOT.callback_query_handler(func=lambda call: True)
def on_callback(call: Any) -> None:
    if not call.message or call.message.chat.type != "private":
        BOT.answer_callback_query(call.id, "افتح البوت في الخاص.", show_alert=True)
        return
    uid, chat_id, data = call.from_user.id, call.message.chat.id, call.data
    if not authorized(uid):
        BOT.answer_callback_query(call.id, "البوت غير مفعّل لحسابك.", show_alert=True)
        return
    BOT.answer_callback_query(call.id)
    state = get_session(uid)
    if state.get("running") and data != "stop":
        BOT.send_message(
            chat_id,
            "في محاولة شغالة بالفعل. أوقفها قبل ما تبدأ اختيارًا جديدًا.",
            reply_markup=stop_keyboard(),
        )
        return
    if data.startswith("admin_"):
        if not is_owner(uid):
            BOT.send_message(chat_id, "لوحة الإدارة للمالك فقط.")
            return
        if data == "admin_home":
            BOT.send_message(
                chat_id, "<b>لوحة إدارة الاشتراكات</b>", reply_markup=admin_keyboard()
            )
        elif data == "admin_create":
            state["step"] = "admin_choose_days"
            BOT.send_message(
                chat_id, "اختار مدة الأكواد الجديدة:", reply_markup=duration_keyboard()
            )
        elif data.startswith("admin_days:"):
            choice = data.split(":", 1)[1]
            if choice == "custom":
                state["step"] = "admin_custom_days"
                BOT.send_message(chat_id, "ابعت عدد الأيام (من 1 إلى 3650).")
            else:
                state["admin_duration"] = int(choice)
                state["step"] = "admin_count"
                BOT.send_message(
                    chat_id, f"مدة الكود {choice} يوم. ابعت عدد الأكواد (من 1 إلى 30)."
                )
        elif data == "admin_list":
            show_admin_codes(chat_id)
        elif data == "admin_users":
            show_admin_users(chat_id)
        elif data.startswith("admin_revoke:"):
            try:
                code_id = int(data.split(":", 1)[1])
                result = SUBSCRIPTIONS.revoke_code(code_id)
                BOT.send_message(
                    chat_id,
                    "✅ تم تعطيل الكود، وأُلغي الاشتراك المرتبط به إن كان مستخدمًا."
                    if result["ok"]
                    else "الكود غير موجود أو ملغي بالفعل.",
                    reply_markup=admin_keyboard(),
                )
            except ValueError:
                BOT.send_message(chat_id, "معرّف الكود غير صالح.")
        elif data.startswith("admin_user_revoke:"):
            try:
                user_id = int(data.split(":", 1)[1])
                count = SUBSCRIPTIONS.revoke_user(user_id)
                BOT.send_message(
                    chat_id,
                    f"✅ تم إلغاء {count} منحة اشتراك للمستخدم <code>{user_id}</code>.",
                    reply_markup=admin_keyboard(),
                )
            except ValueError:
                BOT.send_message(chat_id, "معرّف المستخدم غير صالح.")
    elif data == "help":
        BOT.send_message(
            chat_id,
            "أولى ثانوي: JavaScript (42 فصلًا). تانية ثانوي: JavaScript (54) + Python (25)، "
            "أو الثقافة المالية، أو الكل.",
        )
    elif data == "back_grades":
        send_start(chat_id)
    elif data in ("grade_1", "grade_2"):
        if not has_access(uid):
            BOT.send_message(
                chat_id, "فعّل اشتراكك أولًا باستخدام <code>/redeem كودك</code>."
            )
            return
        grade = 1 if data == "grade_1" else 2
        if grade == 1:
            _start_credentials(state, ["javascript_g1"], grade)
            ask_platform_id(chat_id, state)
        else:
            state.clear()
            state.update(
                {"running": False, "grade": 2, "last_activity": time.monotonic()}
            )
            BOT.send_message(
                chat_id, "اختار المسار المطلوب:", reply_markup=grade2_keyboard()
            )
    elif data in ("track_programming", "track_finance", "track_all"):
        if not has_access(uid):
            BOT.send_message(
                chat_id, "فعّل اشتراكك أولًا باستخدام <code>/redeem كودك</code>."
            )
            return
        track_name = data.removeprefix("track_")
        state = fresh_state(uid)
        queue = _start_credentials(state, courses_for_selection(2, track_name), 2)
        ask_platform_id(chat_id, state) if queue else send_confirmation(chat_id, state)
    elif data == "run":
        if not has_access(uid):
            BOT.send_message(
                chat_id, "الاشتراك غير نشط. استخدم <code>/redeem كودك</code>."
            )
            return
        if state.get("running"):
            BOT.send_message(
                chat_id, "المحاولة شغالة بالفعل.", reply_markup=stop_keyboard()
            )
            return
        if state.get("step") != "confirm":
            BOT.send_message(chat_id, "ابدأ من /start واختار الصف والمسار الأول.")
            return
        state["running"] = True
        state["cancel_event"] = threading.Event()
        courses = list(state.get("courses", []))
        credentials = {
            key: str(state.get(key, ""))
            for key in ("qureo_id", "qureo_password", "spx_id", "spx_password")
        }
        status = BOT.send_message(
            chat_id, "⏳ جاري تجهيز المحاولة…", reply_markup=stop_keyboard()
        )
        thread = threading.Thread(
            target=run_job,
            args=(
                uid,
                chat_id,
                status.message_id,
                courses,
                credentials,
                state["cancel_event"],
            ),
            daemon=True,
        )
        thread.start()
    elif data == "stop":
        event = state.get("cancel_event")
        if event:
            event.set()
        BOT.send_message(chat_id, "⏹️ طلب الإيقاف وصل؛ التنفيذ هيقف عند أقرب نقطة آمنة.")
    elif data == "cancel":
        if state.get("running"):
            BOT.send_message(chat_id, "المحاولة بدأت بالفعل؛ استخدم زر الإيقاف.")
            return
        wipe_credentials(state)
        state.clear()
        state.update({"running": False, "last_activity": time.monotonic()})
        BOT.send_message(chat_id, "تم الإلغاء. ابعت /start لو حابب تبدأ من جديد.")


@BOT.message_handler(content_types=["text"])
def on_text(message: Any) -> None:
    if not private_chat(message) or not authorized(message.from_user.id):
        return
    state = get_session(message.from_user.id)
    step = state.get("step")
    text = (message.text or "").strip()
    if step == "redeem_code":
        state.pop("step", None)
        try:
            BOT.delete_message(message.chat.id, message.message_id)
        except Exception:
            pass
        redeem_result(message.chat.id, message.from_user.id, text)
        return
    if step in ("admin_custom_days", "admin_count"):
        if not is_owner(message.from_user.id):
            state.pop("step", None)
            return
        if not text.isdigit():
            BOT.reply_to(message, "اكتب رقم صحيح من غير رموز.")
            return
        value = int(text)
        if step == "admin_custom_days":
            if not 1 <= value <= 3650:
                BOT.reply_to(message, "المدة لازم تكون من يوم إلى 3650 يوم.")
                return
            state["admin_duration"] = value
            state["step"] = "admin_count"
            BOT.reply_to(message, f"تمام، المدة {value} يوم. ابعت عدد الأكواد (1–30).")
            return
        if not 1 <= value <= 30:
            BOT.reply_to(message, "عدد الأكواد لازم يكون من 1 إلى 30.")
            return
        duration = int(state.get("admin_duration", 0))
        if not 1 <= duration <= 3650:
            state.pop("step", None)
            BOT.reply_to(message, "اختار مدة من لوحة الإدارة الأول عن طريق /admin.")
            return
        created = SUBSCRIPTIONS.create_codes(message.from_user.id, duration, value)
        state.pop("step", None)
        state.pop("admin_duration", None)
        code_lines = "\n".join(f"<code>{item['code']}</code>" for item in created)
        BOT.send_message(
            message.chat.id,
            f"✅ أنشأت {len(created)} كود، مدة كل واحد {duration} يوم.\n"
            "انسخهم واحفظهم؛ الأكواد الكاملة مش بتتخزن وبتظهر هنا مرة واحدة فقط.\n\n"
            f"{code_lines}",
            reply_markup=admin_keyboard(),
        )
        return
    if step == "admin_choose_days":
        BOT.reply_to(message, "اختار المدة من أزرار لوحة الإدارة.")
        return
    if step not in ("qureo_id", "qureo_password", "spx_id", "spx_password"):
        return
    platform = "qureo" if step.startswith("qureo") else "spx"
    suffix = step.rsplit("_", 1)[-1]
    if not text:
        BOT.reply_to(message, "الرسالة فاضية؛ جرّب تاني.")
        return
    if suffix == "id":
        state[f"{platform}_id"] = text[:120]
        state["step"] = f"{platform}_password"
        platform_name = "Qureo" if platform == "qureo" else "الثقافة المالية"
        BOT.send_message(
            message.chat.id,
            f"اكتب كلمة مرور {platform_name}. هحاول أمسح رسالة كلمة المرور بعد استلامها.",
        )
        return
    try:
        BOT.delete_message(message.chat.id, message.message_id)
    except Exception:
        pass
    state[f"{platform}_password"] = text[:256]
    state["credential_index"] = int(state.get("credential_index", 0)) + 1
    ask_platform_id(message.chat.id, state)


def _expire_idle_sessions() -> None:
    ttl = int(CONFIG["session_ttl_minutes"]) * 60
    while True:
        time.sleep(60)
        now = time.monotonic()
        with SESSIONS_LOCK:
            for uid, state in list(SESSIONS.items()):
                if state.get("running") or now - state.get("last_activity", now) < ttl:
                    continue
                wipe_credentials(state)
                SESSIONS.pop(uid, None)


def main() -> None:
    threading.Thread(target=_expire_idle_sessions, daemon=True).start()
    print("Giui Solver bot started; secrets are read from the environment.")
    BOT.infinity_polling(skip_pending=True, timeout=30, long_polling_timeout=30)


if __name__ == "__main__":
    main()
